% 2023/03/07
% 仿真平台运行的控制Class，这是一个核心Class
% 所有的仿真模块都挂靠在该Class的Method中运行
%%
classdef simController < handle % 句柄类
%% 是否启用调试模式
    properties
        ifDebug      
    end
%% 构造时输入参数
    properties (Access = public) 
        Config  % 平台的输入配置参数     
    end
%% 常量配置    
    properties (Access = public) 
    %-----------------------------------------------------------------------------------------------------
        numOfUsrs_inves             % 考察区域内的用户数量
    %-----------------------------------------------------------------------------------------------------
        numOfUsrs_all               % 考虑warpAround时总用户数量
    %-----------------------------------------------------------------------------------------------------
        numOfUsrs_selected          % 考虑warpAround时removeSomeSat()后的用户数量    
    %-----------------------------------------------------------------------------------------------------
        numOfMethods_BeamGenerate   % 导入的波位生成方法数量
    %-----------------------------------------------------------------------------------------------------
        numOfMethods_BeamHopping    % 导入的波位跳跃调度方法数量
    %-----------------------------------------------------------------------------------------------------
        vOfray          % (double) 光速(m/s)
    %-----------------------------------------------------------------------------------------------------    
        rOfearth        % (double) 地球半径(m)
    %-----------------------------------------------------------------------------------------------------        
        slotInSubF      % 每子帧的时隙数
    %-----------------------------------------------------------------------------------------------------            
        timeInSlot      % 每时隙的时长(s)
    %-----------------------------------------------------------------------------------------------------
        slotInShot      % 每快照的时隙数
    %-----------------------------------------------------------------------------------------------------
        subFInShot      % 每快照的子帧数
    %-----------------------------------------------------------------------------------------------------
        subFInSche      % 每跳波束调度的子帧数
    %-----------------------------------------------------------------------------------------------------
        scheInShot      % 每快照的跳波束调度数
    %-----------------------------------------------------------------------------------------------------
        aglOfServb      % 业务波束3dB张角(rad)
    %-----------------------------------------------------------------------------------------------------
        SatPosition     % 矩阵，格式为"卫星数量×仿真总步数×2"
                        % 这是一个由STK导出的、内置于平台的卫星坐标数据矩阵根据输入配置确定的规则映射而来的矩阵
                        % 第一维表示卫星的编号，第二维表示时间序列，第三维表示经纬坐标
                        % SatPosition(k,s,1)表示编号k卫星在第s个仿真步长时的经度坐标
                        % SatPosition(k,s,2)表示编号k卫星在第s个仿真步长时的纬度坐标
    %-----------------------------------------------------------------------------------------------------                    
        wrapRange       % 来自self.findWrap()
                        % 矩阵，格式为"2×2"
                        % 储存对考察区域进行wrapAround扩大后的区域
                        % [高纬边起始经度，高纬边结束经度
                        %  起始纬度，结束纬度]
    %-----------------------------------------------------------------------------------------------------
        DiscrArea       % 来自self.DiscrInvesArea()，储存将区域离散化后，各离散三角形中心的坐标
                        % 矩阵，格式为"区域总行数×区域总列数×2"
                        % 第一维表示区域中行号，第二维表示区域中列号，第三维表示经纬坐标
                        % DiscrArea(i,j,1)表示第i行第j列三角形的经度
                        % DiscrArea(i,j,2)表示第i行第j列三角形的纬度
                        % 区域左上角三角形是尖向上的三角形
    %-----------------------------------------------------------------------------------------------------
        SeqDiscrInNonWrap   % 来自self.getDiscrInNonWrap()，在WarpAround情况下存储核心考察区离散三角形的编号
                            % 向量，长度为"考察区域三角形总数”
                            % SeqDiscrInNonWrap(k)表示考察区域编号k三角形在包含WrapAround的大区域的对应编号
    %-----------------------------------------------------------------------------------------------------                         
        NofRawsInNonWrap    % 来自self.getDiscrInNonWrap()
                            % 表示核心考察区域的总行数
    %-----------------------------------------------------------------------------------------------------                         
        NofColsInNonWrap    % 来自self.getDiscrInNonWrap()
                            % 表示核心考察区域的总列数
    %-----------------------------------------------------------------------------------------------------                    
        SeqDiscrArea    % 来自self.DiscrInvesArea()，储存将（wrapAround扩大后）区域离散化后，各离散三角形中心的坐标
                        % 矩阵，格式为"三角形总数×2"
                        % 第一维表示三角形的编号(按列编号)，第二维表示经纬坐标
                        % SeqDiscrArea(k,1)表示编号k三角形的中心经度坐标
                        % SeqDiscrArea(k,2)表示编号k三角形的中心纬度坐标 
    %-----------------------------------------------------------------------------------------------------
        CoordiTri       % 来自self.getTriCoord()，储存将考察区域离散化后，各离散三角形顶点的坐标
                        % 矩阵，格式为"三角形总数×各三角形顶点数3×顶点经纬坐标2"
                        % 第一维表示三角形的编号(按列编号)，第二维表示顶点编号，第三维表示经纬坐标
                        % CoordiTri(k,n,1)表示编号k三角形的n号顶点的经度坐标
                        % CoordiTri(k,n,2)表示编号k三角形的n号顶点的纬度坐标
                        %      1号顶点           2号顶点    3号顶点
                        % 2号顶点    3号顶点          1号顶点   
    %-----------------------------------------------------------------------------------------------------
        signalOfArea    % 来自self.getSignal()，储存当前区域的信令波位中心坐标
                        % 矩阵，格式为"信令波位数量×4"
                        % signalOfArea(i,1)是信令波位中心的经度
                        % signalOfArea(i,2)是信令波位中心的纬度
                        % signalOfArea(i,3)是信令波位中心三角形在Seq的编号
                        % signalOfArea(i,4)是信令波位的全球原始编号
    %-----------------------------------------------------------------------------------------------------                    
        SignalOfDiscrArea    % 来自self.getSignal()，储存三角形到信令波位的映射关系
                             % 矩阵，格式为“区域总行数×区域总列数×2”
                             % SignalOfDiscrArea(i, j, 1)表示DiscrArea中第i行第j列三角形所属的信令波位在signalOfArea的编号
                             % SignalOfDiscrArea(i, j, 2)表示DiscrArea中第i行第j列三角形所属的信令波位在全球原始编号
    %-----------------------------------------------------------------------------------------------------                        
        VisibleSat      % 来自self.calcuVisibleSat()
                        % NumOfSat × NumOfShot × 2矩阵，可见卫星 
                        % VisibleSat(k, j, 1:2)表示编号k卫星在第j步长的经纬坐标，不可见卫星编号下坐标写(500, 500)                     
    %-----------------------------------------------------------------------------------------------------
        UsrsPosition    % 来自self.run()或self.getUsrsPositionInPossion()
                        % 矩阵，格式为"全部用户数量×3"
                        % 如果是wrapAround，矩阵的前self.numOfUsrs_inves行是考察区域内的用户，一共有self.numOfUsrs_all行
                        % 如果非wrapAround，矩阵一共有self.numOfUsrs_inves行
                        % UsrsPosition(k, 1)表示k号用户的经度
                        % UsrsPosition(k, 2)表示k号用户的纬度
                        % UsrsPosition(k, 3)表示k号用户在SeqDiscrArea中的编号
    %-----------------------------------------------------------------------------------------------------
        InvesUsrsPosition   % 来自self.getUsrsPositionInPossion()
                            % 矩阵，格式为"考察区域用户数量×3"
    %-----------------------------------------------------------------------------------------------------
        SelectedUsrsPosition    % 来自self.run()
                                % 矩阵，格式为"removeSomeSat后激活用户数量×3"
    %-----------------------------------------------------------------------------------------------------
        OrderOfSelectedUsrs     % 向量，长度为numOfUsrs_selected
                                % 储存removeSat后的用户序列
    %-----------------------------------------------------------------------------------------------------
        Pt_dBm_BS;             % 基站发射功率，单位dBm

    end
%% 过程变量 
    properties (Access = public) 
    %-----------------------------------------------------------------------------------------------------    
        UsrsObj   % 用户的类实例,实例数组，来自self.run()
    %-----------------------------------------------------------------------------------------------------         
        ServSatOfDiscrAreaCur   % 来自self.calcuSatServArea()
                                % 当前step考察区域中各三角形的归属卫星编号，即储存卫星的服务范围
                                % 矩阵，格式为"DiscrArea行数×DiscrArea列数"
                                % ServSatOfDiscrAreaCur(i, j)表示第i行第j列三角形的归属卫星编号
    %-----------------------------------------------------------------------------------------------------             
        OrderOfServSatCur     % 当前step提供服务的卫星编号
    %-----------------------------------------------------------------------------------------------------
        SatObj   % 卫星的类实例
    %-----------------------------------------------------------------------------------------------------    
        Usr2SatCur      % 来自self.calcuSatServArea()  
                        % 向量，长度为self.numOfUsrs_all
                        % Usr2SatCur(k)表示编号k用户的归属卫星编号
    %-----------------------------------------------------------------------------------------------------
        UsrsTraffic % 矩阵，格式为“NumOfAllUsrs × (scheInShot+1)”
                    % UsrsTraffic(k, 1)为初始随机业务量
                    % UsrsTraffic(k, 2)~UsrsTraffic(k,scheInShot+1)为每次调度周期开始时的新增业务量
    %-----------------------------------------------------------------------------------------------------
        UsrsTransPort   % 矩阵，格式为“NumOfAllUsrs × scheInShot”
                        % UsrsTransPort(idxOfMethod, k, p)为编号k用户在第p个调度周期的传输业务量 
    %-----------------------------------------------------------------------------------------------------
        SigBeamMapptoSat    % 储存signalOfArea信令波位序号与SatObj卫星序号的映射
                            % 格式为“NumOfSignalBeam × NumOfSat”
                            % SigBeamMapptoSat(i,j)=1表示signalOfArea中第i个信令波位属于OrderOfServSatCur中第j个卫星
    %-----------------------------------------------------------------------------------------------------
        UsrMapptoSig        % 储存numOfUsrs_selected用户序号与signalOfArea信令波位序号的映射
    %-----------------------------------------------------------------------------------------------------
        NeighborAdjaMatrix  % 服务卫星的邻接矩阵
    %-----------------------------------------------------------------------------------------------------    
        BS_invArea  %基站覆盖区域经纬范围坐标存储
    %----------------------------------------------------------------------------------------------------
        BS_array  %按行列存储的基站数组
    end
%% 公有方法    
    methods (Access = public)
        %% Construct函数签名与构造
        function self = simController( ...
                                Config, ...
                                numOfMethods_BeamGenerate, ...
                                numOfMethods_BeamHopping, ...
                                ifDebug ...
                            ) % 构造函数
            if nargin == 0
            %% 无输入参数时
                error('Input must be in existence！')  % 抛出错误提示
            elseif nargin > 0
            %% 有输入参数时
                %% 是否启用调试
                self.ifDebug = ifDebug;
                %% 导入输入配置参数
                self.Config = Config;
                self.numOfMethods_BeamGenerate = numOfMethods_BeamGenerate;
                self.numOfMethods_BeamHopping = numOfMethods_BeamHopping;
                %% 确定常量
                self.vOfray = 3e8; % m/s
                self.rOfearth = 6371.393e3; % m
                path = pwd;
                %星网用5400
                name = '\5400.mat';
                % 毕设用1800
%                 name = '\1800.mat';
                load([path, name],'LLAresult');   % 数据LLAresult的格式是"卫星总数量×仿真总步数×经纬度"
                TofCircle = round(2*pi*sqrt(((self.rOfearth+Config.height)^3)/(6.67259e-11*5.965e24)));
                if Config.time == 0   % 如果仿真持续总时间这一项参数设为0
                    self.SatPosition = LLAresult(:, 1:Config.step:TofCircle+Config.step+1, :);  % 星网508kmLEO轨道周期是5682.7s，周期约等于5683s  
                else
                    self.SatPosition = LLAresult(:, 1:Config.step:Config.time+1, :);    % 仿真的时间段实际上是0:step:TotalTime(s)
                end
                if self.ifDebug == true
                    fprintf('内置STK卫星数据已导入！\n');
                end                           
            end 
        end 
        %% Methods签名
        DataObj = run(self) % 运行仿真主程序
        findWrap(self); % WrapAround
        DiscrInvesArea(self) % 获得离散三角形中心点坐标  
        getTriCoord(self) % 获得离散三角形顶点坐标
        getDiscrInNonWrap(self) % 获得考察区域编号与包含WrapAround的大区域编号的映射
        getSignal(self) % 获取信令波位
        calcuVisibleSat(self) % 计算当前区域的所有可见卫星
        getUsrsPositionInPossion(self) % 计算泊松点过程撒点时的用户位置
        calcuSatServArea(self, OrderOfVisibleSat, IdxOfStep, MC_idx) % 计算考察区域内可见卫星服务范围并判断用户所属
        getNeighborSat(self, IdxOfStep, MC_idx)
        getSignalOfSat(self, IdxOfStep, MC_idx)
        removeSomeSat(self, IdxOfStep, MC_idx)
        DataObj = calcuInterference(self, DataObj, IdxOfStep, MC_idx)
        getBeamPoint(self, slotIdx,MethodIdx)
        delSatObj(self)
        generateBS(self)  % 生成基站位置数组
        DataObj = calcuSatGroundInterference(self, DataObj, IdxOfStep, MC_idx) % 计算星地同频干扰
        ID = findClosestBS(self,usrspos) % 寻找距离所选用户坐标最近的基站位置索引

        DataObj = calcuInterferenceForDiffBand(self, DataObj, IdxOfStep, MC_idx)%每个用户占用不同频带时候的干扰计算
    end    
end
