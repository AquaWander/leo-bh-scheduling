% function generateBHST(self, IdxOfStep, NumOfShot)
% %GENERATEBHST BHST生成
%     for k = 1 : self.interface.numOfMethods_BeamGenerate
%         for idxOfSat = 1 : length(self.interface.OrderOfServSatCur)
%             eval(['self.interface.tmpSat(idxOfSat).NumOfBeamFoot = ', ...
%                 'self.interface.tmpSat_',num2str(k-1),'(idxOfSat).NumOfBeamFoot;']); 
%             eval(['self.interface.tmpSat(idxOfSat).beamfoot = ', ...
%                 'self.interface.tmpSat_',num2str(k-1),'(idxOfSat).beamfoot;']);          
%         end
%         for p = 1 : self.interface.numOfMethods_BeamHopping
%             eval(['methods.BHST_Method',num2str(p-1),'(self.interface)']);
% 
%             % 星间BHST调整(时间相撞时，由用户密度低的卫星进行调整)
%             if self.interface.Config.ifAdjustBHST == 1
%                 self.adjustBHST();
%                 if self.interface.ifDebug == 1
%                     fprintf('第%d快照星间BHST调整已完成\n', IdxOfStep); 
%                 end
%             end
% 
%             for idxOfSat = 1 : length(self.interface.OrderOfServSatCur)
%                 eval(['self.interface.tmpSat_',num2str(k-1),'(idxOfSat).BHST_',num2str(p-1),' = ', ...
%                     'self.interface.tmpSat(idxOfSat).BHST;']);  
%             end
%             self.interface.UsrsTransPort(p, :, :) = self.interface.tmp_UsrsTransPort;
%             self.interface.tmp_UsrsTransPort = zeros(self.interface.NumOfSelectedUsrs, self.interface.ScheInShot);
%         end
%     end
% end

function generateBHST(self, IdxOfStep, NumOfShot)
%GENERATEBHST BHST生成
% 修改版: 支持SA机制开关
%
% 配置选项 (在Config中设置):
%   - enable_SA: true/false (是否启用SA机制，默认true)
%   - L_tabu_mode: 'adaptive'/'fixed' (禁忌长度模式，默认'adaptive')
%   - fixed_L_tabu: 整数 (固定禁忌长度，默认20)

    % 获取SA配置
    enable_SA = true;  % 默认启用SA
    L_tabu_mode = 'adaptive';  % 默认自适应
    fixed_L_tabu = 20;  % 默认固定长度
    
    % 从Config中读取配置（如果存在）
    if isfield(self.interface, 'Config')
        if isfield(self.interface.Config, 'enable_SA')
            enable_SA = self.interface.Config.enable_SA;
        end
        if isfield(self.interface.Config, 'L_tabu_mode')
            L_tabu_mode = self.interface.Config.L_tabu_mode;
        end
        if isfield(self.interface.Config, 'fixed_L_tabu')
            fixed_L_tabu = self.interface.Config.fixed_L_tabu;
        end
    end
    
    for k = 1 : self.interface.numOfMethods_BeamGenerate
        for idxOfSat = 1 : length(self.interface.OrderOfServSatCur)
            eval(['self.interface.tmpSat(idxOfSat).NumOfBeamFoot = ', ...
                'self.interface.tmpSat_',num2str(k-1),'(idxOfSat).NumOfBeamFoot;']); 
            eval(['self.interface.tmpSat(idxOfSat).beamfoot = ', ...
                'self.interface.tmpSat_',num2str(k-1),'(idxOfSat).beamfoot;']);          
        end
        p = 1;
        
        % 根据配置选择算法版本
        if enable_SA
            % 使用带SA机制的禁忌搜索
            methods.BHST_MY_SA(self.interface, enable_SA, L_tabu_mode, fixed_L_tabu);
        else
            % 使用原始禁忌搜索（无SA）
            methods.BHST_MY(self.interface);
        end
        
        % 备选算法（注释掉）
        % methods.BHST_greedy(self.interface);  % 贪心
        % methods.BHST_greedyAndDist(self.interface);  % 贪心+隔离

        for idxOfSat = 1 : length(self.interface.OrderOfServSatCur)
            eval(['self.interface.tmpSat_',num2str(k-1),'(idxOfSat).BHST_',num2str(p-1),' = ', ...
                'self.interface.tmpSat(idxOfSat).BHST;']);  
        end
        self.interface.UsrsTransPort(p, :, :) = self.interface.tmp_UsrsTransPort;
        self.interface.tmp_UsrsTransPort = zeros(self.interface.NumOfSelectedUsrs, self.interface.ScheInShot);
    end
end
