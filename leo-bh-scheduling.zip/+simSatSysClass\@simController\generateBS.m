function generateBS(self)
Range = self.Config.rangeOfInves;
%e.g.RangeOfInvesArea =[110, 120;33, 48];第一行是经度，第二行是纬度

%invArea为考察区域，第一行为经度，第二行为纬度。
% LongSpan = Range(1,2) - Range(1,1);
% LatSpan = Range(2,2) - Range(2,1);
% invArea = zeros(2,2);
% invArea(1,1) = randi(LongSpan-4) + Range(1,1);
% invArea(1,2) = invArea(1,1) + 4;
% invArea(2,1) = randi(LatSpan-4) + Range(2,1);
% invArea(2,2) = invArea(2,1) + 4;
invArea = Range;
if abs(invArea(2,1)) < abs(invArea(2,2))
    t = invArea(2,2);
    invArea(2,2) = invArea(2,1);
    invArea(2,1) = t;
end
D = 0.8;%基站间距离0.8km
h = D/2*sqrt(3);%两行基站间垂直距离
row = ceil(abs(invArea(2,1)-invArea(2,2))*110/h) ;%参考经纬范围内，基站的行数
distRow = calcuDist(invArea(1,1),invArea(1,2),invArea(2,1),invArea(2,1));%整个矩形区域的横长
col = ceil(distRow/(D*1000));%列数
BS = zeros(row,col,2);%用三维矩阵存基站的经纬度，第一面是经度，第二面是纬度，每一面的值表示是图中第几行第几列的基站的经纬度值
for a = 1:row
    %两行基站间垂直距离换算为纬度
    unitLat = h/110;
    BS(a,1,2) = invArea(2,1) - sign(invArea(2,1))*(a-1)*unitLat;
    unitLon = deltalong(D*1000,BS(a,1,2));
    if  mod(a,2)==1
        BS(a,1,1) = invArea(1,1);
    else
        BS(a,1,1) = invArea(1,1) + 0.5*unitLon;
    end
    %为经度跨过180度的情况准备
    if  BS(a,1,1) < -180
        BS(a,1,1) = BS(a,1,1) + 360;
    end
    
    for b = 2:col
        %同一行基站纬度相同
        BS(a,b,2) = BS(a,1,2);
        tempLon = BS(a,1,1) + (b-1)*unitLon;
        %经度跨过180度的情况
        if tempLon>180
            BS(a,b,1) = -180 + tempLon - 180;
        else
            BS(a,b,1) = tempLon;
        end
    end
end
self.BS_array = BS;
self.BS_invArea = [BS(1,1,1),min(self.BS_array(:,col,1));
               BS(row,1,2),BS(1,1,2)];%第一行经度，第二行纬度

end


function long = deltalong(d,lat)
%输入的纬度与输出的经度单位均为角度制
lat = lat*pi/180;
R =  6371.393e3;
a = sin(d/2/R).^2;
b = cos(lat).^2;
long = sign(d).*acos(1-2*a./b);
long = long*180/pi;
end

%计算地球上两点的距离
function dist = calcuDist(lon1,lon2,lat1,lat2)
%输入的经纬度都是角度制
R =  6371.393e3;%单位是m
lon1 = lon1*pi/180;
lon2 = lon2*pi/180;
lat1 = lat1*pi/180;
lat2 = lat2*pi/180;
dist = 2*R*asin(sqrt(2*(1-cos(lat2 - lat1) + cos(lat2)*cos(lat1)-cos(lat2)*cos(lat1)*cos(lon2-lon1)))/2);
end

