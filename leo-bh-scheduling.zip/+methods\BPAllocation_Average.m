function BPAllocation_Average(interface)
% 本函数用于对波位内用户分配频带和功率，提出的算法

%% 获得数据
OrderOfServSatCur = interface.OrderOfServSatCur;    % 服务卫星的列表
NumOfServSatCur = length(OrderOfServSatCur);    % 服务卫星的数量
NumOfSche = interface.ScheInShot;  % 快照的调度周期数
Num_slot = interface.SlotInSche;    % 调度周期的slot数量
BW = interface.BandOfLink*1e6; % 带宽，单位是Hz
freqOfDownLink = interface.freqOfDownLink; % (Hz) 卫星的下行链路中心频点
startOfBand = freqOfDownLink - BW / 2;% (Hz) 卫星的下行链路开始频点
heightOfsat = interface.height;%卫星轨道高度
maxPower = 10^(interface.Pt_dBm_serv/10)/1000/interface.numOfServbeam;% 每个波束的总功率，单位是w
K = 1.38e-23;  % 玻尔兹曼常量
Ta_usr = interface.Config.Usr_T_noise;
F_usr = interface.Config.Usr_F_noise;
% 是否需要考虑每个首先每个波束的功率并不平均？
% 考虑的话也是个凸优化问题，应该可以同样使用拉格朗日+注水，考虑与否可以作为两个曲线结果
%% 遍历
for SatIdx = 1 : NumOfServSatCur % 遍历卫星
    
    BHST = interface.tmpSat(SatIdx).BHST;
    
    NumOfSlotPerShot = length(BHST(1,:));

    for slotIdx = 1 : NumOfSlotPerShot %遍历时隙
        scheIdx = ceil(slotIdx / Num_slot);
        % 获得当前卫星当前时隙的点亮波位
        notzero = BHST(:, slotIdx) ~= 0;
        LightBeamfoot = BHST(notzero, slotIdx);
        
        for footIdx = 1 : length(LightBeamfoot)
            curFoot = LightBeamfoot(footIdx);
            % 获得波位信息
            orderOfUsrs = interface.tmpSat(SatIdx).beamfoot(scheIdx, curFoot).usrs;
            numOfUserInFoot = length(orderOfUsrs);
            subBandWidth = BW/numOfUserInFoot;% 每个子带的宽度
            if numOfUserInFoot == 1
                %如果只有一个用户，那就不用那么费劲了
                tmp = find(interface.OrderOfSelectedUsrs == orderOfUsrs);
                interface.UsrsObj(tmp).Band(slotIdx, :) = [startOfBand, startOfBand + BW];
                interface.UsrsObj(tmp).BandWidth(slotIdx) = BW;
                interface.UsrsObj(tmp).PowerPercent(slotIdx) = 1;
            else          
                % 计算用户的矩阵
                n = numOfUserInFoot;% 矩阵维度
%                 HungMat = zeros(n, n);
%                 for i = 1 : n % 用户
%                     curUser = orderOfUsrs(i);
%                     for j = 1 : n % band
%                         % 计算award
%                         tmpBand = [startOfBand + subBandWidth * (j - 1), startOfBand + subBandWidth * j];
%                         [SINR, ~] = CaculateR(SatIdx, scheIdx, slotIdx, curUser, curFoot, LightBeamfoot, LightPower, BeamPoint, tmpBand, interface, 0);
%                         HungMat(i,j) = SINR;
%                     end
%                 end
%                 % 因为匈牙利是求最小化问题，但是我需要最大化，所以转换问题
%                 % 当面对最大化指派问题，可以从系数矩阵C中，找出最大元素m，用m减去矩阵C中所有元素得到系数矩阵B，则以B为系数矩阵的最小化指派问题和以C为系数矩阵的原最大化指派问题有相同最优解。
%                 NewHungMat = max(max(HungMat)) - HungMat;
%                 [assignment,~] = munkres(NewHungMat);

                assignment = randperm(n , n);
                % 当前
                allocBand = zeros(n,2);
                for i = 1 : n
                    res = assignment(i);
                    allocBand(i, 1) = startOfBand + (res - 1) * subBandWidth;
                    allocBand(i, 2) = startOfBand + res * subBandWidth;              
                end

                %存结果
                for i = 1 : n
    %                 res = assignment(i);
                    tmp = find(interface.OrderOfSelectedUsrs == orderOfUsrs(i));
                    interface.UsrsObj(tmp).Band(slotIdx, :) = [allocBand(i,1), allocBand(i,2)];
                    interface.UsrsObj(tmp).BandWidth(slotIdx) =  allocBand(i,2) - allocBand(i,1);
                end


                %% 分配功率：平均
                allocPercentage = 1 / n;
                %存结果
                for i = 1 : n
                    tmp = find(interface.OrderOfSelectedUsrs == orderOfUsrs(i));
                    interface.UsrsObj(tmp).PowerPercent(slotIdx) = allocPercentage;
                end
                

            end
        end
  

    fprintf('第%d颗卫星波束内资源调度计算已完成%f%%\n',SatIdx,slotIdx * 100 /NumOfSlotPerShot);
    end
    
end
end


%%
function PosInDescartes = LngLat2Descartes(CurPos, h)
    tmpPhi = CurPos(1) * pi / 180;
    if tmpPhi < 0
        tmpPhi = tmpPhi + 2*pi;
    end
    tmpTheta = (90 - CurPos(2)) * pi / 180;
    R = 6371.393e3; % 地球半径
    tmpX = (R+h) * sin(tmpTheta) * cos(tmpPhi);
    tmpY = (R+h) * sin(tmpTheta) * sin(tmpPhi);
    tmpZ = (R+h) * cos(tmpTheta); 
    PosInDescartes = [tmpX, tmpY, tmpZ];    
end


