% run_visualization.m
% 运行所有可视化脚本

clear; clc;

fprintf('=== 运行所有可视化脚本 ===\n\n');

% 吞吐量对比
fprintf('1. 生成吞吐量对比图...\n');
try
    addpath('visualize');
    plot_Throughput_Comparison;
    fprintf('[✓] 吞吐量对比图生成完成\n\n');
    rmpath('visualize');
catch ME
    fprintf('[✗] 吞吐量对比图生成失败: %s\n\n', ME.message);
end

% 满足率对比
fprintf('2. 生成满足率对比图...\n');
try
    addpath('visualize');
    plot_Satisfaction_Rate;
    fprintf('[✓] 满足率对比图生成完成\n\n');
    rmpath('visualize');
catch ME
    fprintf('[✗] 满足率对比图生成失败: %s\n\n', ME.message);
end

% SINR CDF对比
fprintf('3. 生成SINR CDF对比图...\n');
try
    addpath('visualize');
    plot_SINR_CDF;
    fprintf('[✓] SINR CDF对比图生成完成\n\n');
    rmpath('visualize');
catch ME
    fprintf('[✗] SINR CDF对比图生成失败: %s\n\n', ME.message);
end

% 时间对比
fprintf('4. 生成时间对比图...\n');
try
    addpath('visualize');
    plot_Time_Comparison;
    fprintf('[✓] 时间对比图生成完成\n\n');
    rmpath('visualize');
catch ME
    fprintf('[✗] 时间对比图生成失败: %s\n\n', ME.message);
end

fprintf('=== 可视化脚本运行完成 ===\n');
fprintf('请查看 visualize/ 目录中的生成的图片\n');
