function BeamFoot_Method1(interface)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
% 根据用户位置调整波位中心，波位只与用户地理位置有关
% 参考：宁爽.星载相控阵凝视波束成形技术的研究[D].哈尔滨工业大学,2020.中4.3.1节波束覆盖算法

%% 获取所需参数
%需要地球半径（计算距离）
Radius = 6371.393e3;
%算波位半径
AngleOf3dB = interface.AngleOf3dB;% 天线3dB张角
Rb = tools.getEarthLength(AngleOf3dB, interface.height)/2;

hOfDiscr = tools.LatLngCoordi2Length([0 0], [0 1], Radius)/interface.factorOfDiscr;%离散三角行的行高
NofRaw = 2 * ceil(Rb/(2*hOfDiscr/sqrt(3))); % 一个波位占用的离散三角行数

%每波位最大用户数，可选1、2、3
Musr = 3;%每波位最大用户数
%卫星数量
NumOfSat = length(interface.OrderOfServSatCur);%卫星数量
%调度周期总数
sche = interface.ScheInShot; 

referDist = 2 * Rb; % 参考距离

%% 按照调度周期遍历
for idx = 1 : sche
    %% 按卫星遍历
    for i = 1 : NumOfSat
        %获得当前卫星下的用户信息
        numOfUsrs = interface.SatObj(i).numOfusrs(idx); %卫星服务用户的编号
        UsrsOrder = interface.SatObj(i).servUsr(idx,:); 

        if numOfUsrs == 0
            interface.tmpSat(i).NumOfBeamFoot(idx) = 0;
            continue;
        end
    
        % 该星下用户的坐标
        UsrsPosition = zeros(numOfUsrs, 2);
        for ii = 1 : numOfUsrs
            UsrsPosition(ii, :) = interface.UsrsObj(UsrsOrder(ii)).position;    
        end
    
        %获得一个每用户与其他用户的距离矩阵，距离超过referDist的话就置0
        bfT = zeros(numOfUsrs, numOfUsrs);
        for s = 1 : numOfUsrs
            for q = 1 : s
                if s ~= q%同一个用户的相邻关系置0
                    deltaL = tools.LatLngCoordi2Length(UsrsPosition(s, :), UsrsPosition(q, :), Radius);
                    if deltaL <= referDist  %相邻的标准是半径，因为不调整波位中心坐标
                        bfT(s, q) = deltaL;
                        bfT(q, s) = deltaL;
                    end
                else
                    bfT(s, q) = 0;
                end
            end
        end
        
        %预分配内存，这些是需要存储的数据
        cetrTri = zeros(numOfUsrs,2);%用来存储波位中心的经纬度坐标
        userInBeam = zeros(numOfUsrs,Musr);
        sortList = zeros(1,numOfUsrs);%当前用户是否已经被分配，如果被分配了，置1
        
        % 遍历用户
        count = 1;%用于总波位的计数
        for j = 1 : numOfUsrs
            if sortList(j) == 1
                % 如果当前用户已经被划分了波位，就跳过，直接进行下一次
                continue;
            end
            flag = 0;
            if Musr == 1  %如果每个波位最大一个用户，那波位中心和服务用户就是他自己
    %             cetrTri(count,:) = [UsrsPosition(curUserInSat,1),UsrsPosition(curUserInSat, 2)];
    %             userInBeam(count,1) = curUser;
    %             count = count + 1;
    
            elseif Musr == 2 %如果每个波位最大两个用户，那直接找到最近然后调整中心就行
                flag = 0; % 设置是否有可划分相邻的标记，如果有，置为1
                tempNear = find(bfT(j,j+1 : end) ~= 0) + j; %本来就是按照用户顺序来的，所以邻接矩阵只需要看右三角就行，注意按照matlab的计算方式，要+j
                %先把已经被划分过的去掉，这样之后就不用判断了
                divided = find(sortList == 1);
                inter = intersect(divided,tempNear);
                if ~isempty(inter)
                    for iin = 1 : length(inter)
                        tempNear(find(tempNear == inter(iin))) = [];
                    end
                end
                if ~isempty(tempNear)
                    %找到最近的
                    [~, nearUsr] = min(bfT(j,tempNear));
                    nearUsr = tempNear(nearUsr);
                    flag = 1;
                end           
            elseif Musr == 3
                tempNear = find(bfT(j,j+1 : end) ~= 0) + j;%本来就是按照用户顺序来的，所以邻接矩阵只需要看右三角就行
                %先把已经被划分过的去掉，这样之后就不用判断了
                divided = find(sortList == 1);
                inter = intersect(divided,tempNear);
                if ~isempty(inter)
                    for iin = 1 : length(inter)
                        tempNear(find(tempNear == inter(iin))) = [];
                    end
                end
    
                flag = 0; % 设置是否有可划分相邻的标记，没有相邻:0，一个相邻：1，两个相邻：2
    
                if ~isempty(tempNear)
                    if length(tempNear) == 1
                        %如果只有一个相邻
                        flag = 1;
                        nearUsr = tempNear;       
                    else
                        %如果有多个相邻,先找最近的
                        [~, nearUsr] = min(bfT(j,tempNear));
                        nearUsr = tempNear(nearUsr);
                        % 临时中心
                        tempCoord = zeros(1,2);
                        tempCoord(1) = (UsrsPosition(j,1) +  UsrsPosition(nearUsr,1))/2;
                        tempCoord(2) = (UsrsPosition(j,2) +  UsrsPosition(nearUsr,2))/2;                    
                        %删去最近，然后遍历剩下的相邻点，找和临时中心最近的那个
                        tempNear(find(tempNear == nearUsr)) = [];
                        bfAdja = zeros(1,length(tempNear));% 存储其他点和临时中心的相邻距离，找到次近
                        for b = 1 : length(tempNear)
                            %还要判断和临时中心的距离有没有超过Rb，没超过才可以存进去
                            tempDist = tools.LatLngCoordi2Length([tempCoord(1),tempCoord(2)],UsrsPosition(tempNear(b),:),Radius);
                            if tempDist <= Rb
                                bfAdja(b) = tempDist;
                            end
                        end
                        tempSedNear = find(bfAdja ~= 0);
                        if isempty(tempSedNear)
                            flag = 1;
                        else
                            flag = 2;
                            [~,sedmin] = min(tempSedNear);
                            sedmin = tempSedNear(sedmin);
                            sedminUsr = tempNear(sedmin);
                        end
                        
                    end
                end
            end
            if flag == 0
                %如果没有相邻，那也不用调整了
                cetrTri(count,:) = [UsrsPosition(j, 1),UsrsPosition(j, 2)];
                userInBeam(count,1) = UsrsOrder(j);
                sortList(j) = 1;
            elseif flag == 1
                % 如果只有一个相邻
                % 调整中心
                cetrCoord(1) = (UsrsPosition(j,1) +  UsrsPosition(nearUsr,1))/2;
                cetrCoord(2) = (UsrsPosition(j,2) +  UsrsPosition(nearUsr,2))/2;
                %记录波位中心信息
                cetrTri(count,:) = [cetrCoord(1),cetrCoord(2)];
                %记录波位内用户编号
                userInBeam(count,1) = UsrsOrder(j);
                userInBeam(count,2) = UsrsOrder(nearUsr);
                % 置为1，已划分
                sortList(j) = 1;
                sortList(nearUsr) = 1;
    
            elseif flag == 2
                % 如果有两个相邻
                % 调整中心
                cetrCoord(1) = (UsrsPosition(j,1) +  UsrsPosition(nearUsr,1) + UsrsPosition(sedminUsr,1))/3;
                cetrCoord(2) = (UsrsPosition(j,2) +  UsrsPosition(nearUsr,2) + UsrsPosition(sedminUsr,2))/3;
                %记录波位中心信息
                cetrTri(count,:) = [cetrCoord(1),cetrCoord(2)];
                %记录波位内用户编号
                userInBeam(count,1) = UsrsOrder(j);
                userInBeam(count,2) = UsrsOrder(nearUsr);
                userInBeam(count,3) = UsrsOrder(sedminUsr);
                %置为1，已划分
                sortList(j) = 1;
                sortList(nearUsr) = 1;
                sortList(sedminUsr) = 1;
    
            end
            count = count + 1;
        end
    
        %% 以下为存数据
        if ~isempty(cetrTri)
            %计算波位总数
            if cetrTri(length(cetrTri)) ~= 0 
                NumOfBeam = length(cetrTri(:,1));
            else
                NumOfBeam = min(find(cetrTri == 0)) - 1;
            end    
            interface.tmpSat(i).NumOfBeamFoot(idx) = NumOfBeam;

            for j = 1 : NumOfBeam
                interface.tmpSat(i).beamfoot(idx, j).position = cetrTri(j,:);
                usr = [];
                for jj = 1 : Musr
                    if userInBeam(j,jj) ~= 0
                        usr = [usr userInBeam(j,jj)];
                    end
                end
                interface.tmpSat(i).beamfoot(idx, j).usrs = usr;
                position = cetrTri(j,:);
                [orderOfcetr(1),orderOfcetr(2), orderOfcetr(3)] = tools.findPointXY(interface, position(2),position(1));
                interface.tmpSat(i).beamfoot(idx, j).servTri = ...
                        simSatSysClass.tools.setBeamFoot(orderOfcetr(1:2), orderOfcetr(3), NofRaw, interface.rowNum, interface.colNum); 
            end

        else
            NumOfBeam = 0;
            interface.tmpSat(i).NumOfBeamFoot(idx) = NumOfBeam;
            %没有波位
            
        end 
        fprintf('第%d次调度第%d个卫星波位形成\n',idx,i); 
    end
end

end



