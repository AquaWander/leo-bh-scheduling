function generateSigSpan(self)
%GENERATESIGSPAN 生成信令波束扫描的时序
    methods.SigSpan_Method(self.interface);
end

