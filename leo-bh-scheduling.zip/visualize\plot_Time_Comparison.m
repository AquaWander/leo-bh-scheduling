% visualize/plot_Time_Comparison.m
% 绘制禁忌搜索 vs DQN 的运行时间对比图

clear; clc;

fprintf('=== 运行时间对比分析 ===\n\n');

% 加载结果文件
try
    load('results/results_TabuSearch.mat');
    fprintf('[✓] 禁忌搜索结果已加载\n');
catch
    fprintf('[✗] 禁忌搜索结果文件不存在\n');
    fprintf('    请先运行 run_TabuSearch.m\n');
    return;
end

try
    load('results/results_DQN.mat');
    fprintf('[✓] DQN结果已加载\n');
catch
    fprintf('[✗] DQN结果文件不存在\n');
    fprintf('    请先运行 run_DQN.m\n');
    return;
end

fprintf('\n');

% 统计有效数据
valid_Tabu = ~isnan(times_Tabu);
valid_DQN = ~isnan(times_DQN);

num_valid_Tabu = sum(valid_Tabu);
num_valid_DQN = sum(valid_DQN);

fprintf('有效数据统计:\n');
fprintf('  - 禁忌搜索: %d/%d\n', num_valid_Tabu, length(times_Tabu));
fprintf('  - DQN: %d/%d\n\n', num_valid_DQN, length(times_DQN));

if num_valid_Tabu == 0 || num_valid_DQN == 0
    fprintf('[✗] 有效数据不足，无法绘制对比图\n');
    return;
end

% 计算统计量
mean_Tabu = mean(times_Tabu(valid_Tabu));
std_Tabu = std(times_Tabu(valid_Tabu));
median_Tabu = median(times_Tabu(valid_Tabu));
min_Tabu = min(times_Tabu(valid_Tabu));
max_Tabu = max(times_Tabu(valid_Tabu));

mean_DQN = mean(times_DQN(valid_DQN));
std_DQN = std(times_DQN(valid_DQN));
median_DQN = median(times_DQN(valid_DQN));
min_DQN = min(times_DQN(valid_DQN));
max_DQN = max(times_DQN(valid_DQN));

% 计算速度比
speedup = mean_DQN / mean_Tabu;

% 绘制柱状图
figure('Color', 'w', 'Position', [100, 100, 800, 500]);

% 子图1: 平均运行时间
subplot(2, 1, 1);

data_mean = [mean_Tabu, mean_DQN];
errors_mean = [std_Tabu, std_DQN];

b_mean = bar(data_mean, 'FaceColor', 'flat', 'BarWidth', 0.6);
b_mean.CData(1,:) = [0, 0.4470, 0.7410]; % 蓝色（禁忌搜索）
b_mean.CData(2,:) = [0.8500, 0.3250, 0.0980]; % 红色（DQN）

hold on;
errorbar(1:2, data_mean, errors_mean, 'k.', 'LineWidth', 2, 'CapSize', 10);

% 添加数值标签
for i = 1:length(data_mean)
    text(i, data_mean(i) + errors_mean(i), sprintf('%.2f', data_mean(i)), ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'bottom', ...
        'FontSize', 11, ...
        'FontWeight', 'bold');
end

% 添加速度比标记
if speedup > 1
    text(1, data_mean(1) + errors_mean(1) * 2, ...
        sprintf('%.2fx更快', speedup), ...
        'HorizontalAlignment', 'center', ...
        'Color', [0, 0.5, 0], ...
        'FontSize', 12, ...
        'FontWeight', 'bold');
end

grid on;
ylabel('运行时间 (秒)', 'FontSize', 12, 'FontName', 'Times New Roman');
title('平均运行时间对比', 'FontSize', 14, 'FontName', 'Times New Roman');
set(gca, 'XTickLabel', {'禁忌搜索', 'DQN'}, 'FontSize', 11, 'FontName', 'Times New Roman');
set(gca, 'YGrid', 'on', 'XGrid', 'on', 'LineWidth', 1.5);
legend('平均值', '标准差', 'Location', 'best', 'FontSize', 10);

% 子图2: 单次运行时间分布（箱线图）
subplot(2, 1, 2);

data_boxplot = [times_Tabu(valid_Tabu); times_DQN(valid_DQN)];
group = [ones(num_valid_Tabu, 1); 2 * ones(num_valid_DQN, 1)];

boxplot(data_boxplot, group, 'Colors', [0, 0.4470, 0.7410; 0.8500, 0.3250, 0.0980]);
set(gca, 'XTick', [1, 2], 'XTickLabel', {'禁忌搜索', 'DQN'}, ...
    'FontSize', 11, 'FontName', 'Times New Roman');
ylabel('运行时间 (秒)', 'FontSize', 12, 'FontName', 'Times New Roman');
title('单次运行时间分布', 'FontSize', 14, 'FontName', 'Times New Roman');
grid on;

% 保存图像
dateStr = datestr(now, 'yyyy-mm-dd_HH-MM-SS');
filename_fig = sprintf('visualize/Time_Comparison_%s.fig', dateStr);
filename_png = sprintf('visualize/Time_Comparison_%s.png', dateStr);

try
    saveas(gcf, filename_fig);
    fprintf('[✓] FIG图像已保存: %s\n', filename_fig);
catch ME
    fprintf('[✗] FIG图像保存失败: %s\n', ME.message);
end

try
    saveas(gcf, filename_png);
    fprintf('[✓] PNG图像已保存: %s\n', filename_png);
catch ME
    fprintf('[✗] PNG图像保存失败: %s\n', ME.message);
end

% 打印统计结果
fprintf('\n=== 统计结果 ===\n');
fprintf('禁忌搜索:\n');
fprintf('  - 平均时间: %.2f ± %.2f 秒\n', mean_Tabu, std_Tabu);
fprintf('  - 中位数: %.2f 秒\n', median_Tabu);
fprintf('  - 最小值: %.2f 秒\n', min_Tabu);
fprintf('  - 最大值: %.2f 秒\n', max_Tabu);
fprintf('\n');

fprintf('DQN:\n');
fprintf('  - 平均时间: %.2f ± %.2f 秒\n', mean_DQN, std_DQN);
fprintf('  - 中位数: %.2f 秒\n', median_DQN);
fprintf('  - 最小值: %.2f 秒\n', min_DQN);
fprintf('  - 最大值: %.2f 秒\n', max_DQN);
fprintf('\n');

fprintf('性能对比:\n');
fprintf('  - 速度比 (DQN/Tabu): %.2fx\n', speedup);
if speedup > 1
    fprintf('  - 禁忌搜索快 %.2fx\n', speedup);
else
    fprintf('  - DQN快 %.2fx\n', 1/speedup);
end
fprintf('\n');

% 显著性检验（t检验）
try
    [h, p] = ttest2(times_Tabu(valid_Tabu), times_DQN(valid_DQN));
    fprintf('t检验结果:\n');
    fprintf('  - h = %d (h=1表示有显著差异)\n', h);
    fprintf('  - p = %.4f\n', p);
    if p < 0.01
        fprintf('  - 结论: 差异极其显著 (p < 0.01)\n');
    elseif p < 0.05
        fprintf('  - 结论: 差异显著 (p < 0.05)\n');
    else
        fprintf('  - 结论: 差异不显著 (p >= 0.05)\n');
    end
catch ME
    fprintf('显著性检验失败: %s\n', ME.message);
end

fprintf('\n=== 分析完成 ===\n');
