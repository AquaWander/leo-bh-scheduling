function BPAllocation_PowerOnly(interface)
% 本函数用于对波位内用户分配频带和功率，提出的算法

%% 获得数据
OrderOfServSatCur = interface.OrderOfServSatCur;    % 服务卫星的列表
NumOfServSatCur = length(OrderOfServSatCur);    % 服务卫星的数量
NumOfSche = interface.ScheInShot;  % 快照的调度周期数
BW = interface.BandOfLink*1e6; % 带宽，单位是Hz
freqOfDownLink = interface.freqOfDownLink; % (Hz) 卫星的下行链路中心频点
startOfBand = freqOfDownLink - BW / 2;% (Hz) 卫星的下行链路开始频点
heightOfsat = interface.height;%卫星轨道高度
maxPower = 10^(interface.Pt_dBm_serv/10)/1000/interface.numOfServbeam;% 每个波束的总功率，单位是w
K = 1.38e-23;  % 玻尔兹曼常量
Ta_usr = interface.Config.Usr_T_noise;
F_usr = interface.Config.Usr_F_noise;
% 是否需要考虑每个首先每个波束的功率并不平均？
% 考虑的话也是个凸优化问题，应该可以同样使用拉格朗日+注水，考虑与否可以作为两个曲线结果
%% 遍历波位
for idxOfSat = 1 : NumOfServSatCur
    curSatPos = interface.SatObj(idxOfSat).position;
    satPosInDescartes = LngLat2Descartes(curSatPos, heightOfsat);
    curSatNextPos = interface.SatObj(idxOfSat).nextpos;
    for idxOfSche = 1 : NumOfSche
        for idxOfFoot = 1 : interface.tmpSat(idxOfSat).NumOfBeamFoot(idxOfSche)
        % 获得当前波位的用户数
        orderOfUsrs = interface.tmpSat(idxOfSat).beamfoot(idxOfSche, idxOfFoot).usrs;
        numOfUserInFoot = length(orderOfUsrs);
        if numOfUserInFoot == 1
            %如果只有一个用户，那就不用那么费劲了
            interface.UsrsObj(orderOfUsrs).Band = [startOfBand, startOfBand + BW];
            interface.UsrsObj(orderOfUsrs).BandWidth = BW;
            interface.UsrsObj(orderOfUsrs).PowerPercent = 1;
        else
            % 计算到这个波位的指向
            BeamPoint = zeros(1,2);
            curBeamPos = interface.tmpSat(idxOfSat).beamfoot(idxOfSche, idxOfFoot).position;
            [outputTheta, outputPhi] = tools.getPointAngleOfUsr(...
                    curSatPos, curSatNextPos, curBeamPos, heightOfsat);
            BeamPoint(1) = outputPhi;
            BeamPoint(2) = outputTheta;
            %% 分配子频带：匈牙利算法
            n = numOfUserInFoot;% 矩阵维度
            Gtmp = zeros(n, n);
            d = zeros(1, n);
            avgPower = maxPower / n;
            subBandWidth = BW/numOfUserInFoot;% 每个子带的宽度
            %以下开始生成n*n矩阵，第(i,j)元素表示第j个子频段分给i用户的消耗
            HungMat = zeros(n, n);
            for i = 1 : n % 用户
                curUser = orderOfUsrs(i);
                curUserPos = interface.UsrsObj(curUser).position;
                usrPosInDescartes = LngLat2Descartes(curUserPos, 0);
                distance = sqrt((satPosInDescartes(1)-usrPosInDescartes(1)).^2 + ...
                                (satPosInDescartes(2)-usrPosInDescartes(2)).^2 + ...
                                (satPosInDescartes(3)-usrPosInDescartes(3)).^2);
                d(i) = distance;
                for j = 1 : n % band
                    % 计算award
                    tmpBand = [startOfBand + subBandWidth * (j - 1), startOfBand + subBandWidth * j];
                    tmpFc = mean(tmpBand(1,:));   
    
                    [UsrTheta, UsrPhi] = tools.getPointAngleOfUsr(curSatPos, curSatNextPos, curUserPos, heightOfsat);%计算方位角和仰角
                    Gsat = antenna.getSatAntennaServG([UsrTheta, UsrPhi], [BeamPoint(2), BeamPoint(1)], tmpFc);
                    Gusr = antenna.getUsrAntennaServG(0, tmpFc, false);
                    %还有Gsat+Gusr？？
                    Gtmp(i,j) = Gsat * Gusr;

                    N_noise_usr = subBandWidth*K*(Ta_usr+(F_usr-1)*300);
    
                    award = (3e8/tmpFc / distance)^2 * Gsat * Gusr / N_noise_usr;% award = (lambda/d)^2*G/N0
                    
                    HungMat(i,j) = award;
                end
            end
    
            % 因为匈牙利是求最小化问题，但是我需要最大化，所以转换问题
            % 当面对最大化指派问题，可以从系数矩阵C中，找出最大元素m，用m减去矩阵C中所有元素得到系数矩阵B，则以B为系数矩阵的最小化指派问题和以C为系数矩阵的原最大化指派问题有相同最优解。
            [assignment,~] = munkres(HungMat);

            allocBand = zeros(n,2);
            for i = 1 : n
                res = assignment(i);
                allocBand(i, 1) = startOfBand + (res - 1) * subBandWidth;
                allocBand(i, 2) = startOfBand + res * subBandWidth;              
            end
            
             %存结果
            for i = 1 : n
%                 res = assignment(i);
                interface.UsrsObj(orderOfUsrs(i)).Band = [allocBand(i,1), allocBand(i,2)];
                interface.UsrsObj(orderOfUsrs(i)).BandWidth =  allocBand(i,2) - allocBand(i,1);
            end


            %% 分配功率：拉格朗日+注水
            % 获得的结果应该是一个波位内每个用户之于总功率的占比
            h = zeros(1, n);
            for i = 1 : n % 用户
                curUser = orderOfUsrs(i);
                curUserPos = interface.UsrsObj(curUser).position;
                curFc = mean(allocBand(i,:));

                [UsrTheta, UsrPhi] = tools.getPointAngleOfUsr(curSatPos, curSatNextPos, curUserPos, heightOfsat);%计算方位角和仰角
                Gsat = antenna.getSatAntennaServG([UsrTheta, UsrPhi], [BeamPoint(2), BeamPoint(1)], curFc);

                Gusr = antenna.getUsrAntennaServG(0, curFc, false);

                N_noise_usr = (allocBand(i, 2) - allocBand(i, 1)) * K * (Ta_usr+(F_usr-1)*300);
                
                curLambda = 3e8/curFc;

                h(i) = Gsat * Gusr * (curLambda/(4*pi*d(i)))^2 / N_noise_usr;% Gt*Gr*(lambda/(4*pi*d))^2/N
            end
            [~, allocPercentage] = water_filling2(1./h, maxPower);
            %存结果
            for i = 1 : n
                interface.UsrsObj(orderOfUsrs(i)).PowerPercent = allocPercentage(i);
            end

        end
            
        end
        fprintf('第%d颗卫星第%d调度周期计算已完成\n',idxOfSat,idxOfSche);
    end
end
end

%% 匈牙利
function [assignment,cost] = munkres(costMat)
% MUNKRES   Munkres (Hungarian) Algorithm for Linear Assignment Problem. 
%
% [ASSIGN,COST] = munkres(COSTMAT) returns the optimal column indices,
% ASSIGN assigned to each row and the minimum COST based on the assignment
% problem represented by the COSTMAT, where the (i,j)th element represents the cost to assign the jth
% job to the ith worker.
%
% Partial assignment: This code can identify a partial assignment is a full
% assignment is not feasible. For a partial assignment, there are some
% zero elements in the returning assignment vector, which indicate
% un-assigned tasks. The cost returned only contains the cost of partially
% assigned tasks.

% This is vectorized implementation of the algorithm. It is the fastest
% among all Matlab implementations of the algorithm.

% Examples
% Example 1: a 5 x 5 example
%{
[assignment,cost] = munkres(magic(5));
disp(assignment); % 3 2 1 5 4
disp(cost); %15
%}
% Example 2: 400 x 400 random data
%{
n=400;
A=rand(n);
tic
[a,b]=munkres(A);
toc                 % about 2 seconds 
%}
% Example 3: rectangular assignment with inf costs
%{
A=rand(10,7);
A(A>0.7)=Inf;
[a,b]=munkres(A);
%}
% Example 4: an example of partial assignment
%{
A = [1 3 Inf; Inf Inf 5; Inf Inf 0.5]; 
[a,b]=munkres(A)
%}
% a = [1 0 3]
% b = 1.5
% Reference:
% "Munkres' Assignment Algorithm, Modified for Rectangular Matrices", 
% http://csclab.murraystate.edu/bob.pilgrim/445/munkres.html

% version 2.3 by Yi Cao at Cranfield University on 11th September 2011

assignment = zeros(1,size(costMat,1));
cost = 0;

validMat = costMat == costMat & costMat < Inf;
bigM = 10^(ceil(log10(sum(costMat(validMat))))+1);
costMat(~validMat) = bigM;

% costMat(costMat~=costMat)=Inf;
% validMat = costMat<Inf;
validCol = any(validMat,1);
validRow = any(validMat,2);

nRows = sum(validRow);
nCols = sum(validCol);
n = max(nRows,nCols);
if ~n
    return
end

maxv=10*max(costMat(validMat));

dMat = zeros(n) + maxv;
dMat(1:nRows,1:nCols) = costMat(validRow,validCol);

%*************************************************
% Munkres' Assignment Algorithm starts here
%*************************************************

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   STEP 1: Subtract the row minimum from each row.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
minR = min(dMat,[],2);
minC = min(bsxfun(@minus, dMat, minR));

%**************************************************************************  
%   STEP 2: Find a zero of dMat. If there are no starred zeros in its
%           column or row start the zero. Repeat for each zero
%**************************************************************************
zP = dMat == bsxfun(@plus, minC, minR);

starZ = zeros(n,1);
while any(zP(:))
    [r,c]=find(zP,1);
    starZ(r)=c;
    zP(r,:)=false;
    zP(:,c)=false;
end

while 1
%**************************************************************************
%   STEP 3: Cover each column with a starred zero. If all the columns are
%           covered then the matching is maximum
%**************************************************************************
    if all(starZ>0)
        break
    end
    coverColumn = false(1,n);
    coverColumn(starZ(starZ>0))=true;
    coverRow = false(n,1);
    primeZ = zeros(n,1);
    [rIdx, cIdx] = find(dMat(~coverRow,~coverColumn)==bsxfun(@plus,minR(~coverRow),minC(~coverColumn)));
    while 1
        %**************************************************************************
        %   STEP 4: Find a noncovered zero and prime it.  If there is no starred
        %           zero in the row containing this primed zero, Go to Step 5.  
        %           Otherwise, cover this row and uncover the column containing 
        %           the starred zero. Continue in this manner until there are no 
        %           uncovered zeros left. Save the smallest uncovered value and 
        %           Go to Step 6.
        %**************************************************************************
        cR = find(~coverRow);
        cC = find(~coverColumn);
        rIdx = cR(rIdx);
        cIdx = cC(cIdx);
        Step = 6;
        while ~isempty(cIdx)
            uZr = rIdx(1);
            uZc = cIdx(1);
            primeZ(uZr) = uZc;
            stz = starZ(uZr);
            if ~stz
                Step = 5;
                break;
            end
            coverRow(uZr) = true;
            coverColumn(stz) = false;
            z = rIdx==uZr;
            rIdx(z) = [];
            cIdx(z) = [];
            cR = find(~coverRow);
            z = dMat(~coverRow,stz) == minR(~coverRow) + minC(stz);
            rIdx = [rIdx(:);cR(z)];
            cIdx = [cIdx(:);stz(ones(sum(z),1))];
        end
        if Step == 6
            % *************************************************************************
            % STEP 6: Add the minimum uncovered value to every element of each covered
            %         row, and subtract it from every element of each uncovered column.
            %         Return to Step 4 without altering any stars, primes, or covered lines.
            %**************************************************************************
            [minval,rIdx,cIdx]=outerplus(dMat(~coverRow,~coverColumn),minR(~coverRow),minC(~coverColumn));            
            minC(~coverColumn) = minC(~coverColumn) + minval;
            minR(coverRow) = minR(coverRow) - minval;
        else
            break
        end
    end
    %**************************************************************************
    % STEP 5:
    %  Construct a series of alternating primed and starred zeros as
    %  follows:
    %  Let Z0 represent the uncovered primed zero found in Step 4.
    %  Let Z1 denote the starred zero in the column of Z0 (if any).
    %  Let Z2 denote the primed zero in the row of Z1 (there will always
    %  be one).  Continue until the series terminates at a primed zero
    %  that has no starred zero in its column.  Unstar each starred
    %  zero of the series, star each primed zero of the series, erase
    %  all primes and uncover every line in the matrix.  Return to Step 3.
    %**************************************************************************
    rowZ1 = find(starZ==uZc);
    starZ(uZr)=uZc;
    while rowZ1>0
        starZ(rowZ1)=0;
        uZc = primeZ(rowZ1);
        uZr = rowZ1;
        rowZ1 = find(starZ==uZc);
        starZ(uZr)=uZc;
    end
end

% Cost of assignment
rowIdx = find(validRow);
colIdx = find(validCol);
starZ = starZ(1:nRows);
vIdx = starZ <= nCols;
assignment(rowIdx(vIdx)) = colIdx(starZ(vIdx));
pass = assignment(assignment>0);
pass(~diag(validMat(assignment>0,pass))) = 0;
assignment(assignment>0) = pass;
cost = trace(costMat(assignment>0,assignment(assignment>0)));
end

function [minval,rIdx,cIdx]=outerplus(M,x,y)

ny=size(M,2);
minval=inf;
for c=1:ny
    M(:,c)=M(:,c)-(x+y(c));
    minval = min(minval,min(M(:,c)));
end
[rIdx,cIdx]=find(M==minval);
end

%% 注水
function [palloc_matrix, allocPercentage] = water_filling1(loss, P)
% loss, Kx1向量，即L
% P, 要分配的总功率
% A, 对角阵，即权重alpha
% palloc_matrix, 对角阵，功率分配结果，迹等于P

	K = length(loss); % 用户数

    w = log(2) + zeros(1, K);
    
% 	w = diag(A); % width, 台阶宽度
	h = loss./w; % height, 台阶高度
%     h = loss;
	
    allo_set = 1:K; % 初始化要注水用户的索引集合
    level = (P+sum(loss(allo_set>0)))/sum(w(allo_set>0)); % “虚拟”水位线
    [h_hat, k_hat] = max(h(allo_set>0));
    
    while h_hat>=level
        
        allo_set(k_hat) = -1;
        level = (P+sum(loss(allo_set>0)))/sum(w(allo_set>0)); % “虚拟”水位线
        [h_hat, k_hat] = max(h(allo_set>0));
    
    end
    
    palloc_matrix = zeros(K);
    for k = 1:K
        if allo_set(k)>0
            palloc_matrix(k, k) = (level - h(k))*w(k);
        end
    end

    %我要获得的是比例
    allocPercentage = zeros(1, K);
    for k = 1 : K
        allocPercentage(k) = palloc_matrix(k, k) / P;
    end
    
end

function [palloc_matrix, allocPercentage] = water_filling2(loss, P)
% loss, Kx1向量，即L
% P, 要分配的总功率
% A, 对角阵，即权重alpha
% palloc_matrix, 对角阵，功率分配结果，迹等于P

	K = length(loss);
    
	w = 1/log(2) + zeros(1, K); % 台阶宽度
	h = loss./w; % 台阶高度
	
	[h_sorted, h_idx] = sort(h); % 根据台阶高度升序排序
	w_sorted = w(h_idx);
    
    % 线性搜索，从后往前确定最后一个需要注水的台阶
    for i = K:-1:1
        
        w_tmp = sum(w_sorted(1:i-1)); % 当前台阶前面所有台阶的宽度之和
        h_tmp = h_sorted(i); % 当前台阶的高度
        
        % 把当前台阶之前的台阶注水到与当前台阶同高还有剩余水
        if w_tmp*h_tmp-sum(h_sorted(1:i-1).*w_sorted(1:i-1))<P
            idx = i;
            break;
        end
        
    end
    
    w_filled = sum(w_sorted(1:idx)); % 需要注水的所有台阶的总宽度
    h_filled = (P+sum(h_sorted(1:idx).*w_sorted(1:idx)))/w_filled; % 最终的水位线
	
	p_allocate = zeros(1, K);
    p_allocate(1:idx) = w_sorted(1:idx).*(h_filled-h_sorted(1:idx));
	
    % 恢复原来顺序
    [~, back_idx] = sort(h_idx);
    p_allocate = p_allocate(back_idx);
    
    palloc_matrix = diag(p_allocate);

    %我要获得的是比例
    allocPercentage = zeros(1, K);
    for k = 1 : K
        allocPercentage(k) = palloc_matrix(k, k) / P;
    end
    
end

function [palloc_matrix, allocPercentage] = water_filling3(loss, P)
    %% 初始化
    N= length(loss) ;                    %信道个数
    [noise_sorted,index]=sort(loss); 
    for p=length(noise_sorted):-1:1 
        T_P=(P+sum(noise_sorted(1:p)))/p; 
        Input_Power=T_P-noise_sorted; 
        Pt=Input_Power(1:p); 
        if(Pt(:)>=0)
            break 
        end 
    end 
    power_alloc=zeros(1,N); 
    power_alloc(index(1:p))=Pt;                                %分配的功率
    
    palloc_matrix = diag(power_alloc);

    %我要获得的是比例
    allocPercentage = zeros(1, N);
    for k = 1 : N
        allocPercentage(k) = palloc_matrix(k, k) / P;
    end

end


function PosInDescartes = LngLat2Descartes(CurPos, h)
    tmpPhi = CurPos(1) * pi / 180;
    if tmpPhi < 0
        tmpPhi = tmpPhi + 2*pi;
    end
    tmpTheta = (90 - CurPos(2)) * pi / 180;
    R = 6371.393e3; % 地球半径
    tmpX = (R+h) * sin(tmpTheta) * cos(tmpPhi);
    tmpY = (R+h) * sin(tmpTheta) * sin(tmpPhi);
    tmpZ = (R+h) * cos(tmpTheta); 
    PosInDescartes = [tmpX, tmpY, tmpZ];    
end


%% 计算碱基的SINR值和SNR值
function [SINR, SNR] = CaculateR(SatIdx, ScheIdx, Gene, i, BeamPoint, interface)
    % 基因上第i个碱基所受到的干扰
    Pt = (10.^((interface.SatObj(SatIdx).Pt_dBm_serv)./10))./1e3./interface.numOfServbeam;   % W
    UsrIdx = interface.tmpSat(SatIdx).beamfoot(ScheIdx, i).usrs;
    T_noise = interface.UsrsObj(UsrIdx(1)).T_noise;
    F_noise_dB = interface.UsrsObj(UsrIdx(1)).F_noise;
    F_noise = 10.^(F_noise_dB./10);
    N0_noise = 1.380649e-23*(T_noise + (F_noise-1)*300);

%     BW = interface.BandOfLink*1e6; % 带宽，单位是Hz
%     T = 300;%开尔文温度，单位是k
%     k = 1.38e-23;%玻尔兹曼常数
%     N0 = k*T*BW;%噪声
    Bandwidth = interface.BandOfLink*1e6;
    ExpressedGene = find(Gene == 1);
    % 计算当前波位中心的指向角 
    usrCurPos = interface.tmpSat(SatIdx).beamfoot(ScheIdx, i).position; % 当前用户坐标    
    satCurPos = interface.SatObj(SatIdx).position; % 当前卫星星下点坐标
    satCurnextPos = interface.SatObj(SatIdx).nextpos; % 当前卫星星下点下一step坐标
    [UsrTheta, UsrPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, usrCurPos, interface.height);%计算方位角和仰角
    % 计算用户接收增益
    G_usrDown = antenna.getUsrAntennaServG(0, interface.freqOfDownLink, false);
    % 计算当前卫星到当前用户的距离
    usrPosInDescartes = LngLat2Descartes(usrCurPos, 0);
    satPosInDescartes = LngLat2Descartes(satCurPos, interface.height);
    distance = sqrt((satPosInDescartes(1)-usrPosInDescartes(1)).^2 + ...
                    (satPosInDescartes(2)-usrPosInDescartes(2)).^2 + ...
                    (satPosInDescartes(3)-usrPosInDescartes(3)).^2);  
    InterfInSatDown = 0;
    lambdaDown = 3e8/interface.freqOfDownLink;
    for bfIdx = 1 : length(ExpressedGene)
        if bfIdx ~= find(ExpressedGene == i)
            poiBeta = BeamPoint(bfIdx,1);
            poiAlpha = BeamPoint(bfIdx,2);
            AgleOfInv = [UsrTheta, UsrPhi];
            AgleOfPoi = [poiAlpha, poiBeta];
            G_sat_interfDown = antenna.getSatAntennaServG(AgleOfInv, AgleOfPoi, interface.freqOfDownLink);
            InterfInSatDown = InterfInSatDown + ...
                Pt * G_sat_interfDown * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
        end
    end
    %%%%%%%%%%%%%%%%%%%%%
    bfIdx = find(ExpressedGene == i);
    poiBeta = BeamPoint(bfIdx,1);
    poiAlpha = BeamPoint(bfIdx,2);
    AgleOfInv = [UsrTheta, UsrPhi];
    AgleOfPoi = [poiAlpha, poiBeta];

    G_sat_down = antenna.getSatAntennaServG(AgleOfInv, AgleOfPoi, interface.freqOfDownLink);
    %%%%%%%%%%%%%%%%%%%%%
    Carrier_down = Pt * G_sat_down * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
    SINR = Carrier_down./(InterfInSatDown + Bandwidth*N0_noise);
    SNR = Carrier_down./(Bandwidth*N0_noise);
end