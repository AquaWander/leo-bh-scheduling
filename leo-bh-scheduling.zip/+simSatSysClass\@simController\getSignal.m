% 2023/03/16
% 获取星下信令波位，输出self.SignalOfDiscrArea
%%
% self.SignalOfDiscrArea
% 矩阵，格式为"self.DiscrArea总行数 × self.DiscrArea总列数 × 2"
% self.SignalOfDiscrArea(i,j,1)表示第i行第j列小三角形所属信令波位在self.DiscrArea区域中的编号
% self.SignalOfDiscrArea(i,j,2)表示第i行第j列小三角形所属信令波位在全球区域的编号
%%
function getSignal(self)
%信令点的位置不会随着快照变化的，直接获得以下就可以了
%还没有把有wrapaound的情况写进来
% ifDebug = self.ifDebug;
%% 加载信令波位的中心点数据
path = pwd;
name = '\SignalCoord.mat';
load([path, name],'signaling');

%% 获得在范围内的信令波位点
if self.Config.ifWrapAround == 1 %如果考虑了wraparound
    lat1 = min(self.wrapRange(2,:));%小的那个纬度
    lat2 = max(self.wrapRange(2,:));
else
    lat1 = min(self.Config.rangeOfInves(2,:));%小的那个纬度
    lat2 = max(self.Config.rangeOfInves(2,:));
end
if  self.Config.rangeOfInves(1,1) < self.Config.rangeOfInves(1,2)
%如果是向着经度增大的方向    
    if self.Config.ifWrapAround == 1 %如果考虑了wraparound
        lon1 = min(min(self.wrapRange(1,:)),self.DiscrArea(end,1,1));%小的那个经度
        lon2 = max(max(self.wrapRange(1,:)),self.DiscrArea(end,end,1));
    else
        lon1 = min(min(self.Config.rangeOfInves(1,:)),self.DiscrArea(end,1,1));%小的那个经度
        lon2 = max(max(self.Config.rangeOfInves(1,:)),self.DiscrArea(end,end,1)); 
    end

    %然后从信令波位表里获得在考察区域里的
    t = intersect(find(signaling(:,1) >= lon1 & signaling(:,1) <= lon2), find(signaling(:,2) >= lat1 & signaling(:,2) <= lat2));
    temp = signaling(t,1:2);
    signalOfArea = zeros();%用来存储实际用到的信令波位点
    count = 1;%计数
    rawNum = length(self.DiscrArea(:,1,1));%总行数
    for i = 1 : length(temp)
        [ii,jj,~] = tools.findPointXY(self,temp(i,2),temp(i,1));
        if ii > 0 && ii <= rawNum && jj > 0 && jj <= length(self.DiscrArea(1,:,1))
            signalOfArea(count,1:2) = [temp(i,1),temp(i,2)]; % 经纬坐标
            signalOfArea(count,3) = (jj - 1) * rawNum + ii; % 所属三角形的编号
%             signalOfArea(count,1:2) = self.SeqDiscrArea(signalOfArea(count,3), :); % 经纬坐标
            tmpK = find(signaling == temp(i,:));
            signalOfArea(count,4) = tmpK(1); % 该信令波位的原始编号
            count = count + 1;
        end
%         if ifDebug == 1
%             fprintf('加载信令波位中心点坐标%f%%\n', i*100/length(temp));
%         end
    end
else
%如果是向着经度减小的方向   
    if self.Config.ifWrapAround == 1 %如果考虑了wraparound
        lon1 = min(min(self.wrapRange(1,:)),self.DiscrArea(end,end,1));%小的那个经度
        lon2 = max(max(self.wrapRange(1,:)),self.DiscrArea(end,1,1)); 
    else
        lon1 = min(min(self.Config.rangeOfInves(1,:)),self.DiscrArea(end,end,1));%小的那个经度
        lon2 = max(max(self.Config.rangeOfInves(1,:)),self.DiscrArea(end,1,1)); 
    end
    %然后从信令波位表里获得在考察区域里的
    t = intersect(find(signaling(:,1) <= lon1 | signaling(:,1) >= lon2), find(signaling(:,2) >= lat1 & signaling(:,2) <= lat2));
    temp = signaling(t,1:2);
    signalOfArea = zeros();%用来存储实际用到的信令波位点
    count = 1;%计数
    rawNum = length(self.DiscrArea(:,1,1));%总行数
    for i = 1 : length(temp)
        [ii,jj,~] = tools.findPointXY(self,temp(i,2),temp(i,1));
        if ii > 0 && ii <= rawNum && jj > 0 && jj <= length(self.DiscrArea(1,:,1))
            signalOfArea(count,1:2) = [temp(i,1),temp(i,2)];% 经纬坐标
            signalOfArea(count,3) = (jj - 1) * rawNum + ii; % 所属三角形的编号
%             signalOfArea(count,1:2) = self.SeqDiscrArea(signalOfArea(count,3), :); % 经纬坐标
            tmpK = find(signaling == temp(i,:));
            signalOfArea(count,4) = tmpK(1); % 该信令波位的原始编号
            count = count + 1;
        end
%         if ifDebug == 1
%             fprintf('加载信令波位中心点坐标%f%%\n', i*100/length(temp));
%         end
    end
end
self.signalOfArea = signalOfArea;%获得当前区域的信令波位点坐标，这个不会随着step变化而变化，只和区域有关

%% 将信令波位映射至离散三角形
    NumOfSigB = length(signalOfArea(:,1));
    tempSeqDiscrArea = self.SeqDiscrArea;%离散小三角形的中心点坐标
    tempsignal = zeros(NumOfSigB,3);    
    tempsignal(:,1:2) = signalOfArea(:, 1:2); % 信令波位的经纬坐标
    tempsignal(:,3) = signalOfArea(:, 4); % 信令波位的原始编号

    tempOfNum = zeros(NumOfSigB, 1); % 统计各各波位下小三角形数量
    tempSignalServCur = zeros(length(self.SeqDiscrArea(:,1)), 4); % 存储离散小三角形所属波位
    tempSignalServCur(:,1:2) = self.SeqDiscrArea; %前两列是经纬度，第三列是波位在self.signalOfArea的编号，第四列是原始编号

    rawNum = length(self.DiscrArea(:,1,1));%总行数
    colNum = length(self.DiscrArea(1,:,1));%总列数
    interval = floor(colNum/100);
    for i = 1 : rawNum%遍历行
        last_q = 0;%如果q == last_q说明没找到
        for j = 1 : interval : colNum%间隔遍历列
            seq = simSatSysClass.tools.ij2Seq(i, j, rawNum, colNum);%计算当前ij在离散三角形中的编号
            q = findShortest(...
                tempSeqDiscrArea(seq, :),...
                tempsignal(:, 1:2)...
                );%找到最近的信令波位
            if j ~= 1%补充计算
                if q ~= last_q
                    for k = j-interval+1 : j
                        seq = simSatSysClass.tools.ij2Seq(i, k, rawNum, colNum);
                        q = findShortest(...
                            tempSeqDiscrArea(seq, :),...
                            tempsignal(:, 1:2)...
                            );
                        tempSignalServCur(seq, 3) = q;
                        tempSignalServCur(seq, 4) = tempsignal(q, 3);%在第三列存入卫星编号
                        tempOfNum(q) = tempOfNum(q) + 1; 
                    end
                    last_q = q;
                else
                    for k = j-interval+1 : j
                        seq = simSatSysClass.tools.ij2Seq(i, k, rawNum, colNum);
                        tempSignalServCur(seq, 3) = q;
                        tempSignalServCur(seq, 4) = tempsignal(q, 3);
                        tempOfNum(q) = tempOfNum(q) + 1; 
                    end                    
                end              
            else
                tempSignalServCur(seq, 3) = q;
                tempSignalServCur(seq, 4) = tempsignal(q, 3);
                tempOfNum(q) = tempOfNum(q) + 1;
                last_q = q;
            end
%             if ifDebug == 1
%                 fprintf('将信令波位映射至离散区域%f%%\n', ((i-1)*colNum+j)*100/(rawNum*colNum));          
%             end
            if colNum - j < interval
                for k = j+1 : colNum
                    seq = simSatSysClass.tools.ij2Seq(i, k, rawNum, colNum);
                    q = findShortest(...
                        tempSeqDiscrArea(seq, :),...
                        tempsignal(:, 1:2)...
                        );
                    tempSignalServCur(seq, 3) = q;
                    tempSignalServCur(seq, 4) = tempsignal(q, 3);
                    tempOfNum(q) = tempOfNum(q) + 1;
                end
%                 if ifDebug == 1
%                     fprintf('将信令波位映射至离散区域%f%%\n', ((i-1)*colNum+j)*100/(rawNum*colNum));          
%                 end
            end
        end 
    end

    self.SignalOfDiscrArea = zeros(rawNum, colNum, 2); % 每个小三角形的所属信令波位，1是在仿真区域的编号，2是全球原始编号
    for j = 1:colNum
        for i = 1:rawNum
            self.SignalOfDiscrArea(i, j, 1) = tempSignalServCur((j-1)*rawNum+i, 3);
            self.SignalOfDiscrArea(i, j, 2) = tempSignalServCur((j-1)*rawNum+i, 4);
        end
    end


end

%% 找到距离最近的点
function Satpos = findShortest(pos, SatposSet)
    % pos 考察坐标
    % SatposSet 卫星坐标集合
    R = 6371.393e3; % 地球半径
    lngA = pos(1);
    alpha1 = lngA * pi / 180;
    latA = pos(2);
    beta1 = latA * pi / 180;
    num = length(SatposSet(:,1));
    len = zeros(num,1);%可见卫星个数
    for i = 1 : num
    lngB = SatposSet(i, 1);
    alpha2 = lngB * pi / 180;
    latB = SatposSet(i, 2);
    beta2 = latB * pi / 180;
    len(i) = R * acos(cos(pi/2-beta2)*cos(pi/2-beta1) + sin(pi/2-beta2)*sin(pi/2-beta1)*cos(alpha2-alpha1));
    end
    Satpos = find(len == min(len), 1);
end