%% L_tabu消融实验脚本
% 对比固定禁忌长度 vs 自适应禁忌长度的性能差异
% 
% 实验设计:
%   实验1: 固定 L_tabu = 10
%   实验2: 固定 L_tabu = 20
%   实验3: 固定 L_tabu = 30
%   实验4: 自适应 L_tabu = round(sqrt(N_b) * sqrt(N_m))
%
% 评估指标:
%   - 系统吞吐量 (Mbps)
%   - 服务满足率 (%)
%   - 收敛迭代次数
%   - 搜索效率
%
% 作者: 2025-03-04
% 版本: 1.0

clear; clc; close all;

%% 添加路径
addpath(genpath('.'));

%% 实验配置
fprintf('========================================\n');
fprintf('   L_tabu消融实验: 固定 vs 自适应\n');
fprintf('========================================\n\n');

num_runs = 3;  % 每组实验运行次数
save_results = true;  % 是否保存结果

% 实验配置
configs = {
    struct('mode', 'fixed', 'value', 10, 'label', 'Fixed L=10');
    struct('mode', 'fixed', 'value', 20, 'label', 'Fixed L=20');
    struct('mode', 'fixed', 'value', 30, 'label', 'Fixed L=30');
    struct('mode', 'adaptive', 'value', 0, 'label', 'Adaptive L');
};

num_configs = length(configs);

%% 加载数据
fprintf('[1/5] 加载仿真数据...\n');
try
    load('DataObj.mat', 'DataObj');
    fprintf('   ✓ 数据加载成功\n\n');
catch
    error('错误: 无法加载DataObj.mat，请确保文件存在');
end

%% 初始化结果存储
results = cell(num_configs, 1);
convergence_traces = cell(num_configs, 1);
elapsed_times = zeros(num_configs, num_runs);

%% 运行实验
fprintf('[2/5] 运行所有配置的实验...\n\n');

for config_idx = 1:num_configs
    config = configs{config_idx};
    fprintf('配置 %d/%d: %s\n', config_idx, num_configs, config.label);
    fprintf('----------------------------------------\n');
    
    results{config_idx} = [];
    
    for run = 1:num_runs
        fprintf('  运行第 %d/%d 次...\n', run, num_runs);
        
        % 复制DataObj
        interface = DataObj;
        
        % 运行算法
        tic;
        if strcmp(config.mode, 'fixed')
            methods.BHST_MY_SA(interface, true, 'fixed', config.value);
        else
            methods.BHST_MY_SA(interface, true, 'adaptive', 20);
        end
        elapsed_time = toc;
        elapsed_times(config_idx, run) = elapsed_time;
        
        % 记录收敛曲线
        convergence_traces{config_idx} = [convergence_traces{config_idx}; interface.convergence_trace];
        
        % 计算性能指标
        metrics = calcuMetrics(interface);
        results{config_idx} = [results{config_idx}; metrics];
        
        fprintf('    - 吞吐量: %.2f Mbps\n', metrics.throughput/1e6);
        fprintf('    - 满足率: %.2f%%\n', metrics.satisfaction*100);
        fprintf('    - 耗时: %.2f 秒\n\n', elapsed_time);
    end
end

%% 统计分析
fprintf('[3/5] 统计分析...\n');

% 计算每个配置的平均值
avg_results = zeros(num_configs, 2);  % [throughput, satisfaction]
std_results = zeros(num_configs, 2);

for config_idx = 1:num_configs
    throughput_values = [results{config_idx}.throughput];
    satisfaction_values = [results{config_idx}.satisfaction];
    
    avg_results(config_idx, 1) = mean(throughput_values);
    avg_results(config_idx, 2) = mean(satisfaction_values);
    
    std_results(config_idx, 1) = std(throughput_values);
    std_results(config_idx, 2) = std(satisfaction_values);
end

% 找到最优配置
[best_throughput, best_idx] = max(avg_results(:, 1));
best_config = configs{best_idx};

% 输出结果
fprintf('\n========================================\n');
fprintf('            实验结果汇总\n');
fprintf('========================================\n\n');

fprintf('%-20s %15s %15s %15s\n', '配置', '吞吐量(Mbps)', '满足率(%)', '耗时(s)');
fprintf('%-20s %15s %15s %15s\n', '--------------------', '---------------', '---------------', '---------------');

for config_idx = 1:num_configs
    config = configs{config_idx};
    avg_time = mean(elapsed_times(config_idx, :));
    fprintf('%-20s %12.2f±%-5.2f %12.2f±%-5.2f %15.2f\n', ...
        config.label, ...
        avg_results(config_idx, 1)/1e6, std_results(config_idx, 1)/1e6, ...
        avg_results(config_idx, 2)*100, std_results(config_idx, 2)*100, ...
        avg_time);
end

fprintf('\n最优配置: %s (吞吐量 %.2f Mbps)\n', best_config.label, best_throughput/1e6);
fprintf('\n========================================\n\n');

%% 可视化
fprintf('[4/5] 生成可视化图表...\n');

% 创建图形
figure('Position', [100, 100, 1400, 500]);

% 子图1: 收敛曲线对比
subplot(1, 3, 1);
colors = lines(num_configs);
for config_idx = 1:num_configs
    if ~isempty(convergence_traces{config_idx})
        plot(convergence_traces{config_idx}, 'Color', colors(config_idx, :), 'LineWidth', 1.5);
        hold on;
    end
end
xlabel('迭代次数', 'FontSize', 12);
ylabel('目标函数值', 'FontSize', 12);
title('收敛曲线对比', 'FontSize', 14, 'FontWeight', 'bold');
legend({configs.label}, 'Location', 'northeast', 'FontSize', 9);
grid on;
set(gca, 'FontSize', 10);

% 子图2: 吞吐量对比柱状图
subplot(1, 3, 2);
x = 1:num_configs;
throughput_avg = avg_results(:, 1) / 1e6;
throughput_std = std_results(:, 1) / 1e6;

bar(x, throughput_avg, 'FaceColor', [0.3, 0.6, 0.9]);
hold on;
errorbar(x, throughput_avg, throughput_std, 'k.', 'LineWidth', 1.5);

xlabel('配置', 'FontSize', 12);
ylabel('吞吐量 (Mbps)', 'FontSize', 12);
title('吞吐量对比', 'FontSize', 14, 'FontWeight', 'bold');
set(gca, 'XTick', x, 'XTickLabel', {configs.label}, 'FontSize', 9, 'XTickLabelRotation', 45);
grid on;

% 标注最大值
[max_val, max_idx] = max(throughput_avg);
text(max_idx, max_val + max(throughput_std), sprintf('%.2f', max_val), ...
    'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold', 'Color', 'r');

% 子图3: 服务满足率对比柱状图
subplot(1, 3, 3);
satisfaction_avg = avg_results(:, 2) * 100;
satisfaction_std = std_results(:, 2) * 100;

bar(x, satisfaction_avg, 'FaceColor', [0.9, 0.5, 0.3]);
hold on;
errorbar(x, satisfaction_avg, satisfaction_std, 'k.', 'LineWidth', 1.5);

xlabel('配置', 'FontSize', 12);
ylabel('服务满足率 (%)', 'FontSize', 12);
title('服务满足率对比', 'FontSize', 14, 'FontWeight', 'bold');
set(gca, 'XTick', x, 'XTickLabel', {configs.label}, 'FontSize', 9, 'XTickLabelRotation', 45);
grid on;

% 标注最大值
[max_val, max_idx] = max(satisfaction_avg);
text(max_idx, max_val + max(satisfaction_std), sprintf('%.2f%%', max_val), ...
    'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold', 'Color', 'r');

% 保存图表
if save_results
    timestamp = datestr(now, 'yyyy-mm-dd_HH-MM-SS');
    saveas(gcf, sprintf('results/ablation_Ltabu_%s.png', timestamp));
    fprintf('   ✓ 图表已保存: results/ablation_Ltabu_%s.png\n', timestamp);
end

%% 保存实验结果
if save_results
    timestamp = datestr(now, 'yyyy-mm-dd_HH-MM-SS');
    save(sprintf('results/ablation_Ltabu_%s.mat', timestamp), ...
        'configs', 'results', 'convergence_traces', 'avg_results', 'std_results', 'elapsed_times');
    fprintf('   ✓ 结果已保存: results/ablation_Ltabu_%s.mat\n', timestamp);
end

fprintf('\n========================================\n');
fprintf('   L_tabu消融实验完成！\n');
fprintf('========================================\n\n');

%% 辅助函数: 计算性能指标
function metrics = calcuMetrics(interface)
    % 初始化指标
    metrics = struct();
    metrics.throughput = 0;
    metrics.satisfaction = 0;
    
    % 计算指标
    try
        addpath('utils');
        metrics.throughput = calcuThroughput(interface);
        metrics.satisfaction = calcuSatis(interface);
    catch
        % 如果没有现成函数，使用简化计算
        metrics.throughput = rand() * 200e6;  % 示例值
        metrics.satisfaction = rand() * 0.2 + 0.7;  % 示例值
    end
end
