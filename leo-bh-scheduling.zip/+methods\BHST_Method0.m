% 华为论文"贪心算法”
%%
function BHST_Method0(interface)
%% 获取所需参数
%需要地球半径（计算距离）
Radius = 6371.393e3;
%一些参数
heightOfsat = interface.height;%卫星轨道高度
%计算波位半径
AngleOf3dB = interface.AngleOf3dB;% 天线3dB张角
Rb = tools.getEarthLength(AngleOf3dB, heightOfsat)/2;

% 每波位最大用户数
maxUsrPerBeam = 3;
%中心频率（下行）&波长
freq = interface.freqOfDownLink;%频率
lambdaDown = 3e8/freq;
%子载波间隔
SCS = interface.SCS*1e3;%单位是Hz
%当前全带宽链路在一个slot内可传输的最大RB数
interface.UsrsObj(1) = interface.UsrsObj(1).getCurLinkNRB();
curRB = interface.UsrsObj(1).CurLinkNRB;

%计算热噪声
BW = interface.BandOfLink*1e6; % 带宽，单位是Hz
T = 300;%开尔文温度，单位是k
k = 1.38e-23;%玻尔兹曼常数
N0 = k*T*BW;%噪声

%用户接收增益
type = 0;

% 关于跳波束的参数
bhLength = interface.SlotInSche; % 一次跳波束调度长度
lightTime = interface.timeInSlot;% 波束点亮时间(slot长度），单位是s
NumOfBeam = interface.numOfServbeam; % 同时工作的波束数量

%调度周期总数
sche = interface.ScheInShot; 

%% 按照调度周期遍历
% for idx = 1 : sche
%     givenserv = zeros(1,numOfusrs);%存储所有用户获得的业务

%% 只需考虑当前调度周期
for idx = 1 : sche
% 当前调度用户
numOfusrs = length(find(interface.usersInLine(sche,:) ~= 0));
usersInThisSche = interface.usersInLine(sche,interface.usersInLine(sche,:)~=0);
%总用户
NumOfSelectedUsrs = interface.NumOfSelectedUsrs;
OrderOfSelectedUsrs = interface.OrderOfSelectedUsrs;

if sche == 1
    interface.tmp_UsrsTransPort = zeros(NumOfSelectedUsrs, interface.ScheInShot);%最后的时候需要更新一下
end

TransportedTraffic = zeros(interface.NumOfSelectedUsrs, 1);   % 传输的业务量列表

    %% 请求业务量统计
    requestServAll = zeros(1, NumOfSelectedUsrs);%存储所有用户请求的业务（还没有接入的用户应该还统计不到业务请求吧）
    if idx == 1
        for u = 1 : numOfusrs
            uIndex = find(OrderOfSelectedUsrs == usersInThisSche(u));
            requestServAll(uIndex) = interface.UsrsTraffic(uIndex,1) + interface.UsrsTraffic(uIndex,idx+1);
        end
    else
        for u = 1 : numOfusrs
            uIndex = find(OrderOfSelectedUsrs == usersInThisSche(u));
            requestServAll(uIndex) = interface.UsrsTraffic(uIndex,1) - interface.tmp_UsrsTransPort(uIndex,idx - 1) + interface.UsrsTraffic(uIndex,idx+1);
        end
    end
    

    %% 按照卫星遍历
    for satIdx = 1 : length(interface.OrderOfServSatCur)
%         MAX_bf = max(interface.tmpSat(satIdx).NumOfBeamFoot);
%         interface.tmpSat(satIdx).BHST = zeros(MAX_bf, interface.SlotInSche * interface.ScheInShot);

        %计算卫星总功率
        Pt_sat = interface.SatObj(satIdx).Pt_dBm_serv; % 卫星天线总的发射功率
        Pt_sat = (10.^(Pt_sat/10))/1e3; %单位是W

        numOfbeamfoot = interface.tmpSat(satIdx).NumOfBeamFoot(idx);%波位总数
        servOfbeamfoot = zeros(numOfbeamfoot, 1); % 星下各波位的请求业务量
        userInBeam = zeros(numOfbeamfoot,maxUsrPerBeam);%存储每个波位内的用户编号
        positionOfbeamfoot = zeros(numOfbeamfoot, 2); % 各波位中心的经纬度坐标
          
        %存储数据
        for bfIdx = 1 : numOfbeamfoot
            orderOfUsrs = interface.tmpSat(satIdx).beamfoot(idx, bfIdx).usrs;
            userInBeam(bfIdx,1:length(orderOfUsrs)) = orderOfUsrs;
            
            [~, interUsers] = intersect(interface.OrderOfSelectedUsrs, orderOfUsrs);
            servInBeam = requestServAll(interUsers);
%             servInBeam = requestServAll(interface.OrderOfSelectedUsrs==orderOfUsrs);
            servOfbeamfoot(bfIdx) = sum(servInBeam);
            positionOfbeamfoot(bfIdx, :) = interface.tmpSat(satIdx).beamfoot(idx, bfIdx).position;%获得波位中心的经纬度坐标
        end

        %如果根本就没有波位，那就直接返回空的BHST
        if numOfbeamfoot == 0
            BHST = zeros(NumOfBeam, bhLength);
            interface.tmpSat(satIdx).BHST(:, ((idx-1)*bhLength+1):(idx*bhLength)) = BHST(:,:);           
            continue;
        end
        
        % 计算每个波位的信道容量 C=Blog2(1+SNR), S=Pt*Gt*Gr*(lambdaDown.^2)/(((4*pi).^2)*(distance.^2));
        % 因为实际上点亮的波位个数并不一定是NumOfBeam，所以暂时没法计算Pt=Psat/点亮个数
        % 先把除了Pt以外的SNR部分计算好,N=KBT
        shannonPre = zeros(1,numOfbeamfoot);
    
        satCurPos = interface.SatObj(satIdx).position; % 当前卫星星下点坐标
        satCurnextPos = interface.SatObj(satIdx).nextpos; % 当前卫星星下点下一step坐标
        satPosInDescartes = LngLat2Descartes(satCurPos, heightOfsat);

        BeamPoint = zeros(1, 2);%当前波束的指向
%         UserAngle = zeros(1,2);%用户和天线之间的夹角
    
        for bb = 1 : numOfbeamfoot
            beamCurPos = positionOfbeamfoot(bb,:); % 当前波位中心坐标
            % 卫星的波束指向波位中心，所以波束指向和波位中心相对于卫星的俯仰角是相同的？
%             [beamTheta, beamPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, beamCurPos, heightOfsat);
%             UserAngle(1) = beamPhi;
%             UserAngle(2) = beamPhi;
            %计算波束指向
            [outputTheta, outputPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, beamCurPos, heightOfsat);
            BeamPoint(1) = outputPhi;
            BeamPoint(2) = outputTheta;
            %计算卫星天线增益
            G_sat = antenna.getSatAntennaServG(BeamPoint, BeamPoint, freq); % 天线发射增益
            % 计算当前卫星到当前波位的距离
            beamPosInDescartes = LngLat2Descartes(beamCurPos, 0);%波位中心的笛卡尔坐标
            distance = sqrt((satPosInDescartes(1)-beamPosInDescartes(1)).^2 + ...
                            (satPosInDescartes(2)-beamPosInDescartes(2)).^2 + ...
                            (satPosInDescartes(3)-beamPosInDescartes(3)).^2);
            
            %计算波位中心和卫星之间的偏轴角
            beamWithHeight = LngLat2Descartes(beamCurPos, 1);
            vectorOfbeam = [ ...
                    beamWithHeight(1) - beamPosInDescartes(1), ...
                    beamWithHeight(2) - beamPosInDescartes(2), ...
                    beamWithHeight(3) - beamPosInDescartes(3) ...
                    ];
            vectorOfbeam2Sat = [ ...
                    satPosInDescartes(1) - beamPosInDescartes(1), ...
                    satPosInDescartes(2) - beamPosInDescartes(2), ...
                    satPosInDescartes(3) - beamPosInDescartes(3) ...
                    ];
            AgleOfInv = acos(abs(dot(vectorOfbeam, vectorOfbeam2Sat))/...
                    (sqrt(vectorOfbeam(1)^2 + vectorOfbeam(2)^2 + vectorOfbeam(3)^2) * ...
                    sqrt(vectorOfbeam2Sat(1)^2 + vectorOfbeam2Sat(2)^2 + vectorOfbeam2Sat(3)^2)));
            %计算用户天线增益
%             G_usr = antenna.getUsrAntennaServG(AgleOfInv, freq, type);
            G_usr = antenna.getUsrAntennaServG(0, freq, type);    
            % [Gt*Gr*(lambdaDown/(4*pi*distance))^2)]/N0;
            shannonPre(bb) = (G_sat * G_usr * (lambdaDown/(4*pi*distance))^2)/N0;
        end

        % 距离邻接矩阵，判断是否大于干扰裕度
        margin = 2 * Rb; % 相隔大于1个波位直径（和论文里一样）
        distanT = zeros(numOfbeamfoot, numOfbeamfoot);
        for i = 1 : numOfbeamfoot
            for j = 1 : i
                if i ~= j
                    deltaL = tools.LatLngCoordi2Length(positionOfbeamfoot(i, :), positionOfbeamfoot(j, :), Radius);
                    if deltaL >= margin  %如果大于隔离距离，就存这个距离，否则为0
    %                     distanT(i, j) = deltaL;
    %                     distanT(j, i) = deltaL;
                        distanT(i, j) = 1;
                        distanT(j, i) = 1;
                    end
    %             else
    %                 distanT(i, j) = 0;%同一个也置为0
                end
            end
        end

        maxBeam = min(NumOfBeam,numOfbeamfoot);%如果卫星服务区域很小的话，可能总的波位数会小于设定的同时工作波位数量
        BHST = zeros(NumOfBeam, bhLength);%存储跳波束计划表
        serv_need = servOfbeamfoot;%重新存一下需要的业务，用来做减法
        for j = 1 : bhLength%遍历每个时隙
            if isempty(find(serv_need ~= 0))%如果已经都分配完了，结束
                break;
            end
            [B,I] = sort(serv_need,'descend');
            I(find(B==0)) = [];%防止剩余业务为负数
            maxBeam = min(maxBeam,length(I));
%             tempBeam = I(1 : maxBeam);%获得当前时隙分配最大的波位编号
            %然后检查是否满足干扰规避，用的递归
%             curBeam = judgeBeam(maxBeam,tempBeam,B,I,distanT,1);
            curBeam = judgeBeam(maxBeam,I,distanT);
            BHST(1:maxBeam,j) = curBeam.';
            % 然后分配业务
            P = Pt_sat/length(curBeam(curBeam~=0));%每个波位分到的功率（均分）
            for cc = 1 : length(curBeam)
                SNR = P * shannonPre(curBeam(cc));                
                serv_given = curRB * (12*SCS) * log2(1+SNR)*lightTime;
                serv_need(curBeam(cc)) = serv_need(curBeam(cc)) - serv_given;
%                 if serv_need(curBeam(cc)) < 0
%                     serv_need(curBeam(cc)) = 0;%防止负数
%                 end
            end       
        end

        %% 以下为存数据
%         tmpBHST = zeros();
        interface.tmpSat(satIdx).BHST(:,((idx-1)*bhLength+1):(idx*bhLength)) = BHST(:,:);
%         %用户被分配的容量
%         for nn = 1 : numOfbeamfoot
%             user = userInBeam(nn, userInBeam(nn,:)~=0);%当前波位的用户编号
%             if(serv_need(nn) == 0)%如果当前波位没有业务了
%                 for uu = 1 : length(user)%那么每个用户都分配了所需的业务
%                     givenserv(user(uu)) = requestServAll(user(uu));
%                 end
%             else%如果还有业务剩余，就按照比例存储
%                 for uu = 1 : length(user)
%                     ratio = rnumOfusrsequestServAll(user(uu))/sum(requestServAll(user));
%                     givenserv(user(uu)) = ratio * (servOfbeamfoot(nn) - serv_need(nn));
%                 end
%             end
%         end
%         ExecutiveBHST = zeros(numOfbeamfoot, bhLength);
%         for idx_ii = 1 : bhLength
% %             if find(BHST(:,idx_ii) == 0)
% %                 1;
% %             end
%             ExecutiveBHST(BHST(BHST(:,idx_ii) ~= 0,idx_ii),idx_ii) = 1;
%         end        
%         TransportedTraffic = zeros(interface.NumOfSelectedUsrs, 1);   % 传输的业务量列表
%         TransportedTrafficOfBF = calculateTraffic(interface.OrderOfSelectedUsrs, satIdx, idx, bhLength, ExecutiveBHST, interface, 1); % 计算当前决策的各波位传输业务量   
%         TransportedTraffic_in_Sat = zeros(interface.SatObj(satIdx).numOfusrs(idx), 1);   % 星下用户传输业务
%         UsrsIndex = interface.SatObj(satIdx).servUsr(idx, interface.SatObj(satIdx).servUsr(idx,:) ~= 0); % 星下用户编号列表
%         RequiredTraffic = interface.UsrsTraffic(:, 1);  % 请求的业务量列表
%         [~,NewUsrsIdx,~] = intersect(OrderOfSelectedUsrs, UsrsIndex); %索引
% %         RequiredTraffic_in_Sat = RequiredTraffic(NewUsrsIdx);    % 星下用户剩余请求业务
%         for tmpk = 1 : numOfbeamfoot
%             usrs = interface.tmpSat(satIdx).beamfoot(idx, tmpk).usrs;
%             NofU = length(usrs);
% %             [~,tmp_NewUsrs,~] = intersect(interface.OrderOfSelectedUsrs, usrs);
%             [~,tmp_UsrsIndex,~] = intersect(OrderOfSelectedUsrs, usrs);
%             r_traffic = RequiredTraffic(tmp_UsrsIndex);
%             [~, tmp_idx, ~] = intersect(UsrsIndex, usrs);
% %             if isempty(tmp_idx)
% %                 fprintf('aaa')
% %             end
%             for idx_ii = 1 : NofU
%                 TransportedTraffic_in_Sat(tmp_idx(idx_ii)) = sum(TransportedTrafficOfBF(tmpk)).*(r_traffic(idx_ii)./sum(r_traffic));
%             end
%         end 
%         
%         TransportedTraffic(NewUsrsIdx) = TransportedTraffic_in_Sat;

        fprintf('第%d次调度第%d个卫星BHST形成\n', idx, satIdx); 
        
    end
%     interface.tmp_UsrsTransPort(:,idx) = TransportedTraffic;

    
%     interface.tmp_UsrsTransPort(:,idx) = givenserv;

end
end
% %% 根据干扰规避，判断并找当前时隙波位
% function curBeam = judgeBeam(maxBeam,tempBeam,B,I,distanT,c)
% %c用来记录往回找了几次
% for k = 1 : maxBeam-1
%     for kk = k + 1 : maxBeam
%         if(~distanT(tempBeam(k),tempBeam(kk)))%根据干扰矩阵发现二者之间存在干扰
%             %那就再找下一个业务量最高的，进行替换，再次进行干扰判断，直到全部满足干扰规避
%             if c >= length(I) - maxBeam || ismember(I(maxBeam + c),tempBeam)%这样的话就是找不到能满足干扰规避的
%                 break;
%             end
%             tempBeam(kk) = I(maxBeam + c);
%             c = c + 1;
%             tempBeam = judgeBeam(maxBeam,tempBeam,B,I,distanT,c);
%         end
%     end
%     if c >= length(I) - maxBeam || ismember(I(maxBeam + c),tempBeam)
%         break;
%     end
%     if k == maxBeam && kk == maxBeam%已经找完了
%         break;
%     end
% end
% curBeam = tempBeam;
% end
%% 根据干扰规避，判断并找当前时隙波位
function curBeam = judgeBeam(maxBeam,I,distanT)
curBeam = zeros(1,maxBeam);
curBeam(1) = I(1);
II = I;%重新存一下I
II(1)=[];

count = 2;%计数
while true       
    if isempty(II)
        %如果II已经空了
        if count ~= maxBeam + 1
            %全都找过一遍了但是还是没法填满
            %那就直接把没被选的里面选满
            III = I;
            [~,ia,~]=intersect(III,curBeam);
            III(ia) = [];
            leftNum = maxBeam - (count - 1);
            if length(III) < leftNum
                curBeam(count:end) = III;
            else
                curBeam(count:end) = III(1:leftNum);
            end            
            return;
        else
            return;
        end        
    elseif count == maxBeam + 1 && ~isempty(II)
        %找完了
        return;       
    end
    curBeam(count) = II(1);
    flag=0;%是否出现干扰的标志
    for k = 1 : count - 1
        if distanT(curBeam(k),curBeam(count)) == 0%根据干扰矩阵发现二者之间存在干扰
            flag = 1;            
            break;
        end
    end
    if flag == 1
        II(1)=[];
        curBeam(count) = 0;
    else
        II(1)=[];
        count = count + 1;
    end
end

end



%% 计算吞吐量
function TransportedTrafficOfBF = calculateTraffic(OrderOfSelectedUsrs, idxOfSat, idxOfSche, Num_slot, ExecutiveBHST, interface, Debug)
    numOfbeamfoot = length(ExecutiveBHST(:,1));
    TransportedTrafficOfBF = zeros(numOfbeamfoot, 1);
    for idxOfSlot = 1 : Num_slot
        lightedBf = find(ExecutiveBHST(:, idxOfSlot)==1);
        NumOfLightBeamfoot = length(lightedBf);
        PosOfBeam = zeros(NumOfLightBeamfoot, 2);    % 点亮波位中心三角形坐标       
        for bidx = 1 : NumOfLightBeamfoot
            PosOfBeam(bidx, :) = interface.tmpSat(idxOfSat).beamfoot(idxOfSche, lightedBf(bidx)).position; 
        end
        BeamPoint = zeros(NumOfLightBeamfoot, 2); % varphi(俯仰，偏离x轴),vartheta(方向，偏离xOy平面),天线在zOy平面(右手系)
        for j = 1 : NumOfLightBeamfoot
            [outputTheta, outputPhi] = tools.getPointAngleOfUsr(...
                interface.SatObj(idxOfSat).position, interface.SatObj(idxOfSat).nextpos, PosOfBeam(j, :), interface.height);
            BeamPoint(j,1) = outputPhi;
            BeamPoint(j,2) = outputTheta;
        end
%         NumOfExpressedGene = NumOfLightBeamfoot;
%         ExpressedGene = LightBeamfoot;
        SINR_Gene = zeros(NumOfLightBeamfoot, 1);
        for tmpI = 1 : NumOfLightBeamfoot
%             [SINR_Gene(tmpI), ~] = CaculateR(...
            [~, SINR_Gene(tmpI)] = CaculateR(...
                OrderOfSelectedUsrs, ...
                idxOfSat, idxOfSche, ...
                ExecutiveBHST(:, idxOfSlot),...
                lightedBf(tmpI), BeamPoint, interface);
        end
        for idxOfBf = 1 : NumOfLightBeamfoot
            TransportedTrafficOfBF(lightedBf(idxOfBf)) = TransportedTrafficOfBF(lightedBf(idxOfBf)) + ...
                interface.timeInSlot*interface.BandOfLink*1e6*log2(1+SINR_Gene(idxOfBf));
        end
    end          
end
%% 计算碱基的SINR值和SNR值
function [SINR, SNR] = CaculateR(OrderOfSelectedUsrs, SatIdx, ScheIdx, Gene, i, BeamPoint, interface)
    % 基因上第i个碱基所受到的干扰
    Pt = (10.^((interface.SatObj(SatIdx).Pt_dBm_serv)./10))./1e3./interface.numOfServbeam;   % W
    UsrIdx = interface.tmpSat(SatIdx).beamfoot(ScheIdx, i).usrs;
    T_noise = interface.UsrsObj(find(OrderOfSelectedUsrs==UsrIdx(1))).T_noise;
    F_noise_dB = interface.UsrsObj(find(OrderOfSelectedUsrs==UsrIdx(1))).F_noise;
    F_noise = 10.^(F_noise_dB./10);
    N0_noise = 1.380649e-23*(T_noise + (F_noise-1)*300);

%     BW = interface.BandOfLink*1e6; % 带宽，单位是Hz
%     T = 300;%开尔文温度，单位是k
%     k = 1.38e-23;%玻尔兹曼常数
%     N0 = k*T*BW;%噪声
    Bandwidth = interface.BandOfLink*1e6;
    ExpressedGene = find(Gene == 1);
    % 计算当前波位中心的指向角 
    usrCurPos = interface.tmpSat(SatIdx).beamfoot(ScheIdx, i).position; % 当前用户坐标    
    satCurPos = interface.SatObj(SatIdx).position; % 当前卫星星下点坐标
    satCurnextPos = interface.SatObj(SatIdx).nextpos; % 当前卫星星下点下一step坐标
    [UsrTheta, UsrPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, usrCurPos, interface.height);%计算方位角和仰角
    % 计算用户接收增益
    G_usrDown = antenna.getUsrAntennaServG(0, interface.freqOfDownLink, false);
    % 计算当前卫星到当前用户的距离
    usrPosInDescartes = LngLat2Descartes(usrCurPos, 0);
    satPosInDescartes = LngLat2Descartes(satCurPos, interface.height);
    distance = sqrt((satPosInDescartes(1)-usrPosInDescartes(1)).^2 + ...
                    (satPosInDescartes(2)-usrPosInDescartes(2)).^2 + ...
                    (satPosInDescartes(3)-usrPosInDescartes(3)).^2);  
    InterfInSatDown = 0;
    lambdaDown = 3e8/interface.freqOfDownLink;
    for bfIdx = 1 : length(ExpressedGene)
        if bfIdx ~= find(ExpressedGene == i)
            poiBeta = BeamPoint(bfIdx,1);
            poiAlpha = BeamPoint(bfIdx,2);
            AgleOfInv = [UsrTheta, UsrPhi];
            AgleOfPoi = [poiAlpha, poiBeta];
            G_sat_interfDown = antenna.getSatAntennaServG(AgleOfInv, AgleOfPoi, interface.freqOfDownLink);
            InterfInSatDown = InterfInSatDown + ...
                Pt * G_sat_interfDown * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
        end
    end
    %%%%%%%%%%%%%%%%%%%%%
    bfIdx = find(ExpressedGene == i);
    poiBeta = BeamPoint(bfIdx,1);
    poiAlpha = BeamPoint(bfIdx,2);
    AgleOfInv = [UsrTheta, UsrPhi];
    AgleOfPoi = [poiAlpha, poiBeta];
    G_sat_down = antenna.getSatAntennaServG(AgleOfInv, AgleOfPoi, interface.freqOfDownLink);
    %%%%%%%%%%%%%%%%%%%%%
    Carrier_down = Pt * G_sat_down * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
    SINR = Carrier_down./(InterfInSatDown + Bandwidth*N0_noise);
    SNR = Carrier_down./(Bandwidth*N0_noise);
end
%%
function PosInDescartes = LngLat2Descartes(CurPos, h)
    tmpPhi = CurPos(1) * pi / 180;
    if tmpPhi < 0
        tmpPhi = tmpPhi + 2*pi;
    end
    tmpTheta = (90 - CurPos(2)) * pi / 180;
    R = 6371.393e3; % 地球半径
    tmpX = (R+h) * sin(tmpTheta) * cos(tmpPhi);
    tmpY = (R+h) * sin(tmpTheta) * sin(tmpPhi);
    tmpZ = (R+h) * cos(tmpTheta); 
    PosInDescartes = [tmpX, tmpY, tmpZ];    
end



% %%
% function PosInDescartes = LngLat2Descartes(CurPos, h)
%     tmpPhi = CurPos(1) * pi / 180;
%     if tmpPhi < 0
%         tmpPhi = tmpPhi + 2*pi;
%     end
%     tmpTheta = (90 - CurPos(2)) * pi / 180;
%     R = 6371.393e3; % 地球半径
%     tmpX = (R+h) * sin(tmpTheta) * cos(tmpPhi);
%     tmpY = (R+h) * sin(tmpTheta) * sin(tmpPhi);
%     tmpZ = (R+h) * cos(tmpTheta); 
%     PosInDescartes = [tmpX, tmpY, tmpZ];    
% end