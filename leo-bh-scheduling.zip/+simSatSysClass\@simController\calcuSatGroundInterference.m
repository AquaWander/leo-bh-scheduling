 function DataObj = calcuSatGroundInterference(self,DataObj,IdxOfStep, MC_idx)
%CALCUSATGROUNDINTERFERENCE 星地同频干扰计算
%   计算几种场景下的星地同频干扰：
% 1、基站发射信号干扰卫星用户接收；
% 2、地面用户发射干扰卫星接收
%%
    NumOfSlotPerShot = self.slotInShot;
    NumOfSlotPerSche = self.subFInSche * self.slotInSubF;  %每调度周期子帧数
    NumOfShot = length(self.SatPosition(1,:,1)) - 1; % 仿真快照总数(最后一张快照不计算)

    NumOfSat = length(self.OrderOfServSatCur);
    NumOfInvesUsrs = self.numOfUsrs_inves;
    
    heightOfsat = self.Config.height;  
    numofBeam = self.Config.numOfServbeam;

    %% 基站参数
    BSTx_dBm = self.Config.Pt_dBm_BS;
    BSTx = (10.^(BSTx_dBm/10))/1e3;%发射功率，W
    BS_height = 15;%天线高度

    %% 地面终端参数
    Pt_TeUsr_dBm = self.UsrsObj(1).Pt_dBm;
    Pt_TeUsr = (10.^(Pt_TeUsr_dBm/10))/1e3; % W
   
%     UserperBeam = self.Config.maxUsrPerBeam;%每波束最大服务卫星用户数量
    dense = self.Config.Userdense; %用户密度

    %% 卫星波束参数
    %  卫星业务波束总功率
    Pt_SAT_dBm_serv = self.SatObj(1).Pt_dBm_serv;
    %%%%%%%%%%%%%%%%% 业务波束功率均分 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Pt_SAT_serv = (10.^(Pt_SAT_dBm_serv/10))/1e3/numofBeam; % W
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if self.Config.numOfSigbeam > 0
        Pt_SAT_dBm_signal = self.SatObj(1).Pt_dBm_signal;
        Pt_SAT_signal = (10.^(Pt_SAT_dBm_signal/10))/1e3/self.Config.numOfSigbeam; % W
    end

    Beam_radius = 10;%波束半径为10km

    %% 卫星用户参数
    UsrAntennaConfig = antenna.initialUsrAntenna();
    IfUsrAntennaDeGravity = UsrAntennaConfig.ifDeGravity;
    IfUsrAntennaVSAT = UsrAntennaConfig.ifVSAT;%若为1，则为VSAT终端；若为0，则为手持终端（全向天线）
    %
    if IfUsrAntennaVSAT == 1
        Pt_Usr_dBm = 33;
    else
        Pt_Usr_dBm = self.UsrsObj(1).Pt_dBm;
    end
    Pt_Usr = (10.^(Pt_Usr_dBm/10))/1e3; % W    %% 计算噪声

    %% 计算噪声
    K = 1.38e-23;  % 玻尔兹曼常量
    Band = self.Config.BandOfLink;  % 带宽
    Ta_usr = self.UsrsObj(1).T_noise;
    Ta_sat = self.SatObj(1).T_noise;
    if IfUsrAntennaVSAT == 1
        F_usr = 10.^((self.UsrsObj(1).F_noise-5.8)/10);
    else
        F_usr = 10.^(self.UsrsObj(1).F_noise/10);
    end
    F_sat = 10.^(self.SatObj(1).F_noise/10);
    N_noise_usr = Band*K*(Ta_usr+(F_usr-1)*300);
    N_noise_sat = Band*K*(Ta_sat+(F_sat-1)*300);

   
    Debug1 = 0; % f11地面FDD，下行高于上行，5G基站--卫星UE接收
    Debug2 = 0; % f12地面FDD，下行高于上行，地面UE--卫星接收
    Debug3 = 0; % 5G基站--卫星接收
    Debug4 = 0; % 地面UE--卫星UE接收
    Debug5 = 0; % f21地面TDD，5G基站+地面UE--卫星接收
    Debug6 = 0; % f22地面TDD，5G基站+地面UE--卫星UE接收

    if self.Config.TerrestrialDuplexing
        Debug1 = 1;Debug2 = 1;
    else
        Debug5 = 1;Debug6 = 1;
    end
    
    if Debug5
        Debug2 = 1; Debug3 = 1;
    end
    if Debug6 
        Debug1 = 1; Debug4 = 1;
    end
    if (Debug1 || Debug2 || Debug3 || Debug4) && (~Debug5 && ~Debug6)
        % 地面FDD上下行频段中心频率
        freqOfDL = 3560e6;
        freqOfUL = 3440e6;
    elseif Debug5 || Debug6
        % 地面TDD上下行频段中心频率
        freqOfDL = 4840e6;
        freqOfUL = 4840e6;
    end
    % 对应上面不同频段的卫星3dB波束宽度
    theta3dB_UL = tools.find3dBAgle(freqOfUL);
    theta3dB_DL = tools.find3dBAgle(freqOfDL);

    % 生成基站
    self.generateBS();   

    %% 遍历所有算法
    for MethodIdx = 1 : self.numOfMethods_BeamGenerate * self.numOfMethods_BeamHopping
        idxOfBG = ceil(MethodIdx/self.numOfMethods_BeamHopping);
        
        for slotIdx = 1 : NumOfSlotPerShot
            self.getBeamPoint(slotIdx,MethodIdx);
            dpIdx = ceil(slotIdx/NumOfSlotPerSche); % 第几次调度
             for SatIdx = 1 : NumOfSat %遍历卫星
                    eval(['numOfbeam = self.SatObj(SatIdx).numOfbeam_method',num2str(idxOfBG-1),';']);

                    UserperBeam = numOfbeam(dpIdx);

                    tmpNo = find(self.SatObj(SatIdx).servUsr <= NumOfInvesUsrs);
                    UsrsOfSatCur = self.SatObj(SatIdx).servUsr(tmpNo); % 当前星下考察区域内用户集合
                    NumOfUsrs = length(tmpNo); % 星下用户数量
    

                    %% 获得当前卫星波束指向相关参数
                    LightBeamfoot = self.SatObj(SatIdx).LightBeamfoot; % 当前点亮的波位编号
                    LBF_BeamPoint = self.SatObj(SatIdx).BeamPoint; % 当前点亮的波位波束指向,第一列phi，第二列theta
                    LBFnum = length(LightBeamfoot);
                    Pos_Beam = zeros(LBFnum,2);%波束中心坐标
                    for i = 1 : LBFnum
                        Pos_Beam(i,:) = self.SatObj(SatIdx).beamfoot(dpIdx,LightBeamfoot(i)).position;
                    end
                    %星下点坐标以及其在笛卡尔坐标系下坐标
                    satCurPos = self.SatObj(SatIdx).position; % 当前卫星星下点坐标
                    satPosInDescartes = LngLat2Descartes(satCurPos, heightOfsat);
                    satCurnextPos = self.SatObj(SatIdx).nextpos; % 当前卫星星下点下一step坐标

                    %% 5G基站对卫星UE接收信号的干扰           
                    %% 遍历星下用户
                    if Debug1
                        nn = 40;         %基站干扰计算范围,以卫星UE为中心，64km边长的正方形
                        for UsrIdx = 1 : NumOfUsrs %遍历用户
                            UsrOrderCur = UsrsOfSatCur(UsrIdx); % 当前用户编号
                            BeamfootOrderOfUsrCur = self.Usr2SatCur(UsrOrderCur, 1+ceil(MethodIdx/self.numOfMethods_BeamHopping), dpIdx); % 当前用户归属波位        
        
                         % 判断用户在当前帧是否点亮
                            tmpOrderOfbeam = find(LightBeamfoot == BeamfootOrderOfUsrCur);
                         % 判断用户是否在星地干扰考察区域内
                            usrCurPos = self.UsrsObj(find(self.OrderOfSelectedUsrs==UsrOrderCur)).position; % 当前用户坐标
     
                            Areainv = self.BS_invArea;
                          
                            ifIn = (Areainv(1,1)<=usrCurPos(1))&&(usrCurPos(1)<=Areainv(1,2)) && ...
                                    (Areainv(2,1)<=usrCurPos(2))&&(usrCurPos(2)<=Areainv(2,2)); 
        
                            % 如果用户点亮且在考察区域内，计算干扰
                            if ~isempty(tmpOrderOfbeam) && ifIn
                                % 计算当前用户的指向角 
                                [UsrTheta, UsrPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, usrCurPos, heightOfsat);%计算方位角和仰角
                                % 计算卫星天线
                                G_sat_down1 = self.SatObj(SatIdx).getAntennaServG(UsrTheta, UsrPhi, tmpOrderOfbeam, freqOfDL);
                                % 计算用户接收增益
                                if IfUsrAntennaDeGravity == 1
                                    u_s_distance = calcudistance(usrCurPos,satPosInDescartes);
                                    tmp_angle = getElevation(u_s_distance,heightOfsat);
                                    G_usrDown = antenna.getUsrAntennaServG(0.5*pi - tmp_angle, freqOfDL, 0);
                                elseif IfUsrAntennaVSAT == 1
                                    [tmp_angle, ~, ~] = simSatSysClass.tools.getAngleOfInterfSat(usrCurPos, satCurPos, usrCurPos, heightOfsat);
                                    G_usrDown = antenna.getUsrAntennaServG(tmp_angle, freqOfDL, 0);
                                else
                                    G_usrDown = antenna.getUsrAntennaServG(0, freqOfDL, 0);
                                end
                                    
                                % 计算卫星用户接收卫星信号功率
                                distance = calcudistance(usrCurPos,satPosInDescartes);
                                PL1 = PL_Sat_Ground(distance,freqOfDL,pi,1);
                                C_sat = Pt_SAT_serv * G_sat_down1 * G_usrDown * (10^(-0.1*PL1));
    

                                tempBS = findClosestBS(self,usrCurPos);
                                row = size(self.BS_array,1);col = size(self.BS_array,2);
                                x1 = (tempBS(1)-nn>0)*(tempBS(1)-nn) + (tempBS(1)-nn<=0);
                                y1 = (tempBS(2)-nn>0)*(tempBS(2)-nn) + (tempBS(2)-nn<=0);
                                x2 = (tempBS(1)+nn<=row)*(tempBS(1)+nn) + (tempBS(1)+nn>row)*row;
                                y2 = (tempBS(2)+nn<=col)*(tempBS(2)+nn) + (tempBS(2)+nn>col)*col;
                                a = x2 - x1 + 1;
                                b = y2 - y1 + 1;
                                I1 = zeros(a,b);
                                tempco1 = usrCurPos;
                                if IfUsrAntennaDeGravity == 1
                                    tmp_angle = (rand()*10)*pi/180;
                                    G_usrDown_intf = antenna.getUsrAntennaServG(tmp_angle, freqOfDL, 0);
                                elseif IfUsrAntennaVSAT == 1
                                    
                                    G_usrDown_intf = antenna.getUsrAntennaServG(0.5*pi, freqOfDL, false);
                                else
                                    G_usrDown_intf = antenna.getUsrAntennaServG(0, freqOfDL, false);
                                end
                                for i = 1:a
                                    for j = 1:b
                                        tempco2 = self.BS_array(x1+i-1,y1+j-1,:);
                                        tempdist = tools.calcuDist(tempco1(1),tempco2(1),tempco1(2),tempco2(2));
                                        temptheta = abs((pi/18-atan(BS_height/tempdist))+(50+rand()*30)/180*pi);
                                        tempphi = (rand()*180)*pi/180;
                                        PL2 = PL_Ground_Ground(tempdist,freqOfDL);
                                        tempBSgain  = antenna.getBSAntennaServG([temptheta,tempphi],[0,0],freqOfDL);
                                        I1(i,j) = BSTx * tempBSgain * G_usrDown_intf * (10^(-PL2/10));
                                    end
                                end
                                I_BS1 = sum(I1,'all');
                                if ~MC_idx
                                    DataObj(IdxOfStep).Interf1(MethodIdx, slotIdx, UsrOrderCur, 1) = C_sat/ (N_noise_usr + I_BS1);
                                    DataObj(IdxOfStep).Interf1(MethodIdx, slotIdx, UsrOrderCur, 2) = I_BS1;
                                    DataObj(IdxOfStep).Interf1(MethodIdx, slotIdx, UsrOrderCur, 3) = C_sat/ I_BS1;
                                else
                                    DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf1(MethodIdx, slotIdx, UsrOrderCur, 1) = C_sat/ (N_noise_usr + I_BS1);
                                    DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf1(MethodIdx, slotIdx, UsrOrderCur, 2) = I_BS1;
                                    DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf1(MethodIdx, slotIdx, UsrOrderCur, 3) = C_sat/ I_BS1;
                                end
        
                            end
                        end
                    end

                    %%  计算地面UE对卫星接收干扰
                    if Debug2
                        if ~isempty(self.SatObj(SatIdx).beamfoot)
                            l = 100;
                            for lbfidx = 1 : LBFnum
                                tempinv = self.BS_invArea;
                                ifIn = (tempinv(1,1)<=Pos_Beam(lbfidx,1))&&(Pos_Beam(lbfidx,1)<=tempinv(1,2)) && ...
                                       (tempinv(2,1)<=Pos_Beam(lbfidx,2))&&(Pos_Beam(lbfidx,2)<=tempinv(2,2)); 
                                if ifIn                                  
                                    tempinv = [tools.d2Lon(Pos_Beam(lbfidx,2),Pos_Beam(lbfidx,1),-Beam_radius*1e3) , tools.d2Lon(Pos_Beam(lbfidx,2),Pos_Beam(lbfidx,1),Beam_radius*1e3);...
                                              Pos_Beam(lbfidx,2)-Beam_radius/110 , Pos_Beam(lbfidx,2)+Beam_radius/110];%第一行经度，第二行纬度
                                    unitlon = abs(tempinv(1,2) - tempinv(1,1))/l;
                                    unitlat = abs(tempinv(2,2) - tempinv(2,1))/l;
 
                                    temppos = zeros(l,l,2);
                                    I2 = zeros(l,l);
    
                                    % 计算卫星用户发射给卫星信号功率
                                    G_satup = self.SatObj(SatIdx).getAntennaServG(LBF_BeamPoint(lbfidx,2), LBF_BeamPoint(lbfidx,1), lbfidx, freqOfUL);
                                    
                                    if IfUsrAntennaDeGravity == 1
                                        u_s_distance = calcudistance(Pos_Beam(lbfidx,:),satPosInDescartes);
                                        tmp_angle = getElevation(u_s_distance,heightOfsat);
                                        G_usrup = antenna.getUsrAntennaServG(0.5*pi - tmp_angle, freqOfUL, 1);
                                    elseif IfUsrAntennaVSAT == 1
                                        [tmp_angle, ~, ~] = simSatSysClass.tools.getAngleOfInterfSat(Pos_Beam(lbfidx,:), satCurPos, Pos_Beam(lbfidx,:), heightOfsat);
                                        G_usrup = antenna.getUsrAntennaServG(tmp_angle, freqOfUL, 1);
                                    else
                                        G_usrup = antenna.getUsrAntennaServG(1,freqOfUL,1);
                                    end

                                    distance = calcudistance(Pos_Beam(lbfidx,:),satPosInDescartes);
                                    PL = PL_Sat_Ground(distance,freqOfUL, pi,1);
                                    C_usr = UserperBeam * Pt_Usr * G_usrup * 10^(-0.1 * PL) * G_satup;
    
                                    % 计算地面用户发射给卫星干扰信号功率
                                    G_Teusr = 10^-0.35;
                                    for i = 1:l
                                        for j = 1:l
                                            temppos(i,j,1) = tempinv(1,1) + (i-0.5)*unitlon;
                                            temppos(i,j,2) = tempinv(2,2) - (j-0.5)*unitlat;
                                            tempdistance = calcudistance(temppos(i,j,:),satPosInDescartes);
                                            tempelevation = getElevation(tempdistance,heightOfsat);
                                            tempPL = PL_Sat_Ground(tempdistance,freqOfUL,tempelevation,1);
                                            %计算方位角和仰角,仰角为与法线方向夹角
                                            [temptheta,tempphi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, temppos(i,j,:), heightOfsat);
                                            G_sat_up1 = self.SatObj(SatIdx).getAntennaServG(temptheta, tempphi, lbfidx, freqOfUL);
                                            I2(i,j) = dense * (Beam_radius/l)^2 * Pt_TeUsr * G_Teusr * 10^(-0.1 * tempPL) * G_sat_up1;
                                        end
                                    end
                                    
                                    I_UE1 = sum(I2,'all');
                                    if ~MC_idx
                                        DataObj(IdxOfStep).Interf2(MethodIdx, slotIdx, SatIdx, lbfidx, 1) = C_usr / (N_noise_sat + I_UE1);
                                        DataObj(IdxOfStep).Interf2(MethodIdx, slotIdx, SatIdx, lbfidx, 2) = I_UE1;
                                        DataObj(IdxOfStep).Interf2(MethodIdx, slotIdx, SatIdx, lbfidx, 3) = C_usr / I_UE1;
                                    else
                                        DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf2(MethodIdx, slotIdx, SatIdx, lbfidx, 1) = C_usr / (N_noise_sat + I_UE1);
                                        DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf2(MethodIdx, slotIdx, SatIdx, lbfidx, 2) = I_UE1;
                                        DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf2(MethodIdx, slotIdx, SatIdx, lbfidx, 3) = C_usr / I_UE1;
                                    end
                                end
                            end
                        end
                    end

                   

                    
                    %% 5G基站对卫星接收信号的干扰     
                    
                    if Debug3 
                        if ~isempty(self.SatObj(SatIdx).beamfoot)
               
                            for idx = 1 : LBFnum
    
%                                 tmptheta = abs(LBF_BeamPoint(idx,2));
%                                 tmpbr = theta3dB_DL;
%                                 tbr = heightOfsat * (tan(tmptheta) - tan(tmptheta - 0.5 * tmpbr));%波束半径
                                n = round(2*Beam_radius/0.8); 
                                %计算卫星用户发射功率
                                distance = calcudistance(Pos_Beam(idx,:),satPosInDescartes);
                                PL = PL_Sat_Ground(distance,freqOfDL, pi,1);
                                G_satup = self.SatObj(SatIdx).getAntennaServG(LBF_BeamPoint(idx,2), LBF_BeamPoint(idx,1), idx, freqOfDL);
                                
                                if IfUsrAntennaDeGravity == 1
                                    u_s_distance = calcudistance(Pos_Beam(idx,:),satPosInDescartes);
                                    tmp_angle = getElevation(u_s_distance,heightOfsat);
                                    G_usrup = antenna.getUsrAntennaServG(0.5*pi - tmp_angle, freqOfDL, 1);
                                elseif IfUsrAntennaVSAT == 1
                                    u_s_distance = calcudistance(Pos_Beam(idx,:),satPosInDescartes);
                                    tmp_angle = getElevation(u_s_distance,heightOfsat);
                                    G_usrup = antenna.getUsrAntennaServG(tmp_angle, freqOfDL, 1);
                                else
                                    G_usrup = antenna.getUsrAntennaServG(1,freqOfDL,1);
                                end
    
                                C_usr = UserperBeam * Pt_Usr * G_usrup * 10^(-0.1 * PL) * G_satup;
    
                                %如果波束在生成基站范围内，计算基站的干扰功率 
                                tempinv = self.BS_invArea;
                                ifIn = (tempinv(1,1)<=Pos_Beam(idx,1))&&(Pos_Beam(idx,1)<=tempinv(1,2)) && ...
                                       (tempinv(2,1)<=Pos_Beam(idx,2))&&(Pos_Beam(idx,2)<=tempinv(2,2)); 
                                
                                if ifIn
                                    tempBS = findClosestBS(self,Pos_Beam(idx,:));
                                    row = size(self.BS_array,1);col = size(self.BS_array,2);
                                    x1 = (tempBS(1)-n>0)*(tempBS(1)-n) + (tempBS(1)-n<=0);
                                    y1 = (tempBS(2)-n>0)*(tempBS(2)-n) + (tempBS(2)-n<=0);
                                    x2 = (tempBS(1)+n<=row)*(tempBS(1)+n) + (tempBS(1)+n>row)*row;
                                    y2 = (tempBS(2)+n<=col)*(tempBS(2)+n) + (tempBS(2)+n>col)*col;
                                    a = x2 - x1 + 1;
                                    b = y2 - y1 + 1;
                                    I3 = zeros(a,b);
                                    for i = 1:a
                                        for j = 1:b
                                            tempco1 = self.BS_array(x1+i-1,y1+j-1,:);
                                            tempdist = calcudistance(tempco1,satPosInDescartes);
                                            tempele = getElevation(tempdist,heightOfsat);
                                            flag1 = tempele + 32.5*pi/180 + rand()*25*pi/180;
                                            temptheta = (flag1<pi/2) * (pi/2 - flag1);
                                            tempphi = (rand()*180)*pi/180;
                                            tempPL = PL_Sat_Ground(tempdist,freqOfDL,tempele,1);
                                            while PL - tempPL > 5
                                                tempPL = PL_Sat_Ground(tempdist,freqOfDL,tempele,1);
                                            end
                                            tempBSgain  = antenna.getBSAntennaServG([temptheta,tempphi],[0,0],freqOfDL);
                                            [tmptheta,tmpphi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, tempco1, heightOfsat);
                                            G_sat_up2 = self.SatObj(SatIdx).getAntennaServG(tmptheta, tmpphi, idx, freqOfDL);
                                            I3(i,j) = BSTx * tempBSgain * G_sat_up2 * (10^(-tempPL/10));
                                        end
                                    end
                                    I_BS2 = sum(I3,'all');
                                    if ~MC_idx
                                        DataObj(IdxOfStep).Interf3(MethodIdx, slotIdx, SatIdx, idx, 1) = C_usr / (N_noise_sat + I_BS2);
                                        DataObj(IdxOfStep).Interf3(MethodIdx, slotIdx, SatIdx, idx, 2) = I_BS2;
                                        DataObj(IdxOfStep).Interf3(MethodIdx, slotIdx, SatIdx, idx, 3) = C_usr /  I_BS2;
                                    else
                                        DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf3(MethodIdx, slotIdx, SatIdx, idx, 1) = C_usr / (N_noise_sat + I_BS2);
                                        DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf3(MethodIdx, slotIdx, SatIdx, idx, 2) = I_BS2;
                                        DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf3(MethodIdx, slotIdx, SatIdx, idx, 3) = C_usr /  I_BS2;
                                    end
                                end
                            end   
                        end
                        
                    end

                     %% 地面UE传输信号对卫星UE接收信号的干扰 
                    if Debug4
                        for UsrIdx = 1 : NumOfUsrs %遍历用户

                            UsrOrderCur = UsrsOfSatCur(UsrIdx); % 当前用户编号
                            BeamfootOrderOfUsrCur = self.Usr2SatCur(UsrOrderCur, 1+ceil(MethodIdx/self.numOfMethods_BeamHopping), dpIdx); % 当前用户归属波位    
                            % 判断用户在当前帧是否点亮
                            tmpOrderOfbeam = find(LightBeamfoot == BeamfootOrderOfUsrCur);

                            % 当前用户坐标
                            usrCurPos = self.UsrsObj(find(self.OrderOfSelectedUsrs==UsrOrderCur)).position; 

                            Areainv = self.BS_invArea;
                          
                            ifIn = (Areainv(1,1)<=usrCurPos(1))&&(usrCurPos(1)<=Areainv(1,2)) && ...
                                    (Areainv(2,1)<=usrCurPos(2))&&(usrCurPos(2)<=Areainv(2,2)); 

                            % 如果用户点亮，计算干扰
                            if ~isempty(tmpOrderOfbeam) && ifIn 
                            
                                k = 50;
                                tempinv = [tools.d2Lon(usrCurPos(2), usrCurPos(1), -Beam_radius*1e3), tools.d2Lon(usrCurPos(2), usrCurPos(1), Beam_radius*1e3);...
                                          usrCurPos(2) - Beam_radius/110, usrCurPos(2) + Beam_radius/110];
                                unitlon = abs(tempinv(1,2) - tempinv(1,1))/k;
                                unitlat = abs(tempinv(2,2) - tempinv(2,1))/k;
                                temppos = zeros(k,k,2);
                                I4 = zeros(k,k);
                                tempdistance = I4;
        
                                % 计算当前用户的指向角 
                                [UsrTheta, UsrPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, usrCurPos, heightOfsat);%计算方位角和仰角
                                % 计算卫星天线
                                G_sat_down2 = self.SatObj(SatIdx).getAntennaServG(UsrTheta, UsrPhi, tmpOrderOfbeam, freqOfUL);
                                % 计算用户接收增益
                                if IfUsrAntennaDeGravity == 1
                                    u_s_distance = calcudistance(usrCurPos,satPosInDescartes);
                                    tmp_angle = getElevation(u_s_distance,heightOfsat);
                                    G_usrDown1 = antenna.getUsrAntennaServG(0.5*pi - tmp_angle, freqOfUL, 0);
                                elseif IfUsrAntennaVSAT == 1
                                    u_s_distance = calcudistance(usrCurPos,satPosInDescartes);
                                    tmp_angle = getElevation(u_s_distance,heightOfsat);
                                    G_usrDown1 = antenna.getUsrAntennaServG(0.5*pi - tmp_angle, freqOfUL, 0);
                                else
                                    G_usrDown1 = antenna.getUsrAntennaServG(0, freqOfUL, 0);
                                end
                                    
                                % 计算当前卫星到当前用户的距离与路径损耗
                                distance = calcudistance(usrCurPos,satPosInDescartes);
                                PL1 = PL_Sat_Ground(distance,freqOfUL,pi,1);
                                %计算卫星UE接收功率
                                C_sat = Pt_SAT_serv * G_sat_down2 * 10^(-0.1*PL1) * G_usrDown1;

    
                                G_Teusr = 10^-0.35;
                                if IfUsrAntennaDeGravity == 1
                                    tmp_angle = (rand()*10)*pi/180;
                                    G_usrDown2 = antenna.getUsrAntennaServG(tmp_angle, freqOfUL, 0);
                                elseif IfUsrAntennaVSAT == 1
                                    
                                    G_usrDown2 = antenna.getUsrAntennaServG((65+25*rand())*pi/180, freqOfUL, 0);
                                else
                                    G_usrDown2 = antenna.getUsrAntennaServG(0, freqOfUL, 0);
                                end
                                for i = 1:k
                                    for j = 1:k
                                        temppos(i,j,1) = tempinv(1,1) + (i-0.5)*unitlon;
                                        temppos(i,j,2) = tempinv(2,2) - (j-0.5)*unitlat;
                                        tempdistance(i,j) = tools.calcuDist(temppos(i,j,1), usrCurPos(1), temppos(i,j,2), usrCurPos(2));
                                        if tempdistance(i,j) < 200
                                            continue;
                                        end
                                        tempPL = PL_Ground_Ground(tempdistance(i,j),freqOfUL);
                                        I4(i,j) = dense * (Beam_radius/k)^2 * Pt_TeUsr * G_Teusr * 10^(-0.1 * tempPL) * G_usrDown2;
                                    end
                                end
                                I_UE2 = sum(I4,'all');
                                if ~MC_idx
                                    DataObj(IdxOfStep).Interf4(MethodIdx, slotIdx, UsrOrderCur, 1) = C_sat / (I_UE2 + N_noise_usr);
                                    DataObj(IdxOfStep).Interf4(MethodIdx, slotIdx, UsrOrderCur, 2) = I_UE2;
                                    DataObj(IdxOfStep).Interf4(MethodIdx, slotIdx, UsrOrderCur, 3) = C_sat /  I_UE2;
                                else
                                    DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf4(MethodIdx, slotIdx, UsrOrderCur, 1) = C_sat / (I_UE2 + N_noise_usr);
                                    DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf4(MethodIdx, slotIdx, UsrOrderCur, 2) = I_UE2;
                                    DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf4(MethodIdx, slotIdx, UsrOrderCur, 3) = C_sat /  I_UE2;
                                end
                            end
                        end
                    end
%%
                    if Debug5
                        if ~MC_idx
                            C1 = zeros(1,1,1,length(DataObj(IdxOfStep).Interf2(MethodIdx, slotIdx, SatIdx, :, 1)));
                            C2 = C1;
                            C1(:) = DataObj(IdxOfStep).Interf2(MethodIdx, slotIdx, SatIdx, :, 2) .*...
                                    DataObj(IdxOfStep).Interf2(MethodIdx, slotIdx, SatIdx, :, 3);
                            C2(:) = DataObj(IdxOfStep).Interf3(MethodIdx, slotIdx, SatIdx, :, 2) .*...
                                    DataObj(IdxOfStep).Interf3(MethodIdx, slotIdx, SatIdx, :, 3);
                            C = min(C1,C2);
                            DataObj(IdxOfStep).Interf5(MethodIdx, slotIdx, SatIdx, :, 2) = ...
                                    DataObj(IdxOfStep).Interf2(MethodIdx, slotIdx, SatIdx, :, 2) + ...
                                    DataObj(IdxOfStep).Interf3(MethodIdx, slotIdx, SatIdx, :, 2);
                            DataObj(IdxOfStep).Interf5(MethodIdx, slotIdx, SatIdx, :, 1) = ...
                                    C./(DataObj(IdxOfStep).Interf5(MethodIdx, slotIdx, SatIdx, :, 2) + N_noise_sat);
                            DataObj(IdxOfStep).Interf5(MethodIdx, slotIdx, SatIdx, :, 3) = ...
                                    C./DataObj(IdxOfStep).Interf5(MethodIdx, slotIdx, SatIdx, :, 2);
                        else
                            C1 = zeros(1,1,1,length(DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf2(MethodIdx, slotIdx, SatIdx, :, 1)));
                            C2 = C1;
                            C1(:) = DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf2(MethodIdx, slotIdx, SatIdx, :, 2) .*...
                                    DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf2(MethodIdx, slotIdx, SatIdx, :, 3);
                            C2(:) = DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf3(MethodIdx, slotIdx, SatIdx, :, 2) .*...
                                    DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf3(MethodIdx, slotIdx, SatIdx, :, 3);
                            C = min(C1,C2);
                            DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf5(MethodIdx, slotIdx, SatIdx, :, 2) = ...
                                    DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf2(MethodIdx, slotIdx, SatIdx, :, 2) + ...
                                    DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf3(MethodIdx, slotIdx, SatIdx, :, 2);
                            DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf5(MethodIdx, slotIdx, SatIdx, :, 1) = ...
                                    C./(DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf5(MethodIdx, slotIdx, SatIdx, :, 2) + N_noise_sat);
                            DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf5(MethodIdx, slotIdx, SatIdx, :, 3) = ...
                                    C./DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf5(MethodIdx, slotIdx, SatIdx, :, 2);
                        end
                    end
%%
                    if Debug6
                        if ~MC_idx
                            C1 = zeros(1,1,length(DataObj(IdxOfStep).Interf1(MethodIdx, slotIdx, :, 1)));
                            C2 = C1;
                            C1(:) = DataObj(IdxOfStep).Interf1(MethodIdx, slotIdx, :, 2) .* ...
                                    DataObj(IdxOfStep).Interf1(MethodIdx, slotIdx, :, 3);
                            C2(:) = DataObj(IdxOfStep).Interf4(MethodIdx, slotIdx, :, 2) .* ...
                                    DataObj(IdxOfStep).Interf4(MethodIdx, slotIdx, :, 3);
                            C = min(C1,C2);
                            DataObj(IdxOfStep).Interf6(MethodIdx, slotIdx, :, 2) = ...
                                    DataObj(IdxOfStep).Interf1(MethodIdx, slotIdx, :, 2) + ...
                                    DataObj(IdxOfStep).Interf4(MethodIdx, slotIdx, :, 2);
                            DataObj(IdxOfStep).Interf6(MethodIdx, slotIdx, :, 1) = ...
                                    C./(DataObj(IdxOfStep).Interf6(MethodIdx, slotIdx, :, 2) + N_noise_usr);
                            DataObj(IdxOfStep).Interf6(MethodIdx, slotIdx, :, 3) = ...
                                    C./DataObj(IdxOfStep).Interf6(MethodIdx, slotIdx, :, 2);
                        else
                            C1 = zeros(1,1,length(DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf1(MethodIdx, slotIdx, :, 1)));
                            C2 = C1;
                            C1(:) = DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf1(MethodIdx, slotIdx, :, 2) .* ...
                                    DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf1(MethodIdx, slotIdx, :, 3);
                            C2(:) = DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf4(MethodIdx, slotIdx, :, 2) .* ...
                                    DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf4(MethodIdx, slotIdx, :, 3);
                            C = min(C1,C2);
                            DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf6(MethodIdx, slotIdx, :, 2) = ...
                                    DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf1(MethodIdx, slotIdx, :, 2) + ...
                                    DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf4(MethodIdx, slotIdx, :, 2);
                            DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf6(MethodIdx, slotIdx, :, 1) = ...
                                    C./(DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf6(MethodIdx, slotIdx, :, 2) + N_noise_usr);
                            DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf6(MethodIdx, slotIdx, :, 3) = ...
                                    C./DataObj((MC_idx-1)*NumOfShot+IdxOfStep).Interf6(MethodIdx, slotIdx, :, 2);
                        end
                    end
          
              end
            fprintf('第%d快照第%d算法星地干扰计算%f%%\n', IdxOfStep, MethodIdx, slotIdx*100/NumOfSlotPerShot); 
        end
    end
 end

 function distance = calcudistance(terrpos,SatposInDesc)
         terrposInDesc = LngLat2Descartes(terrpos,0);
         distance = norm(terrposInDesc - SatposInDesc);
 end

 function alpha = getElevation(distance,hofsat)
    R = 6371.393e3; % 地球半径
    alpha = acos((R^2 + distance^2 - (R+hofsat)^2) / (2 * distance * R)) - 0.5 * pi;
 end
function PosInDescartes = LngLat2Descartes(CurPos, h)
    tmpPhi = CurPos(1) * pi / 180;
    if tmpPhi < 0
        tmpPhi = tmpPhi + 2*pi;
    end
    tmpTheta = (90 - CurPos(2)) * pi / 180;
    R = 6371.393e3; % 地球半径
    tmpX = (R+h) * sin(tmpTheta) * cos(tmpPhi);
    tmpY = (R+h) * sin(tmpTheta) * sin(tmpPhi);
    tmpZ = (R+h) * cos(tmpTheta); 
    PosInDescartes = [tmpX, tmpY, tmpZ];    
end
function PL = PL_Sat_Ground(d,fc,angle,scenario)
%PL_SAT_GROUND 星-地链路信道系数/dB
%   根据3GPP TR38.811建立城市/郊区和农村场景下地-地链路损耗模型，输入通信距离(m)，中心频点(Hz)，用户仰角(°)
    %scenario为1表示郊区和农村场景，2表示城市场景
    %sigma(1)是LOS情况下，阴影衰落所服从正态分布标准差
    %sigma(2)是NLOS情况下，阴影衰落所服从正态分布标准差
    %Prob为不同仰角下的LOS概率


    %angle正常输入范围为[0~pi/2]，若输入为pi表示LOS传播
    angle = ceil(angle*18/pi);

    lambda = 3e8/fc;
    PL_fs = fspl(d,lambda);
  
    %%基本损耗
    if scenario == 1
        switch angle
            case {0,1}
            Prob = 0.246;  sigma = [1.79,8.93];  CL = 19.52;
            case 2
            Prob = 0.386;  sigma = [1.14,9.08];  CL = 18.17;
            case 3
            Prob = 0.493;  sigma = [1.14,8.78];  CL = 18.42;
            case 4
            Prob = 0.613;  sigma = [0.92,10.25];  CL = 18.28;
            case 5
            Prob = 0.726;  sigma = [1.42,10.56];  CL = 18.63;
            case 6
            Prob = 0.805;  sigma = [1.56,10.74];  CL = 17.68;
            case 7
            Prob = 0.919;  sigma = [0.85,10.17];  CL = 16.50;
            case 8
            Prob = 0.968;  sigma = [0.72,11.52];  CL = 16.30;
            case 9
            Prob = 0.992;  sigma = [0.72,11.52];  CL = 16.30;
            case 18
            Prob = 1;  sigma = [0.72,11.52];  CL = 16.30;
        end    
            a = rand();
            if a >= Prob
                %NLOS情况
                while 1
                SF = normrnd(0,sigma(2));
                if abs(SF) <= 20
                    break;
                end
                end
                PL_b = PL_fs + SF + CL;
            else
                %LOS情况
                while 1
                SF = normrnd(0,sigma(1));
                if abs(SF) <= 10
                    break;
                end
                end
                PL_b = PL_fs + SF;
            end
    elseif scenario == 2
        switch angle
            case {0,1}
            Prob = 0.782;  sigma = [4,6];  CL = 34.3;
            case 2
            Prob = 0.869;  sigma = [4,6];  CL = 30.9;
            case 3
            Prob = 0.919;  sigma = [4,6];  CL = 29.0;
            case 4
            Prob = 0.929;  sigma = [4,6];  CL = 27.7;
            case 5
            Prob = 0.935;  sigma = [4,6];  CL = 26.8;
            case 6
            Prob = 0.94;  sigma = [4,6];  CL = 26.2;
            case 7
            Prob = 0.949;  sigma = [4,6];  CL = 25.8;
            case 8
            Prob = 0.952;  sigma = [4,6];  CL = 25.5;
            case 9
            Prob = 0.998;  sigma = [4,6];  CL = 25.5;
            case 18
            Prob = 1;  sigma = [4,6];  CL = 25.5;
        end    
            a = rand();
            if a >= Prob
                %NLOS情况
                while 1
                SF = normrnd(0,sigma(2));
                if abs(SF) <= 12
                    break;
                end
                end
                PL_b = PL_fs + SF + CL;
            else
                %LOS情况
                while 1
                SF = normrnd(0,sigma(1));
                if abs(SF) <= 8
                    break;
                end
                end
                PL_b = PL_fs + SF;
            end
    end

    %%大气损耗
    PL_g = 0.03;
    %%闪烁损耗
    PL_s = 0;
    %%总路径损耗
    PL = PL_b + PL_g + PL_s;

end

function PL = PL_Ground_Ground(d,f)
%PL_GROUND_GROUND 地-地链路损耗函数
%   根据ITU-R P.2108建立地物损耗模型，输入参数有通信距离(m)，中心频点(Hz)。
    %%参数转换
    c = 3e8;
    lambda = c/f;
    %%基本路径损耗
    PL_b = fspl(d,lambda);
    %%地物损耗
    delta_l = 4;
    delta_s = 6;
    p = 50;
    d1 = d/1000;
	f1 = f/1e9;
    if d1 <= 2
        L_s = 32.98 + 23.9.*log10(d1)+3*log10(f1);
        L_l = -2*log10(10^(-5*log10(f1)-12.5)+10^(-16.5));
        delta_cb = sqrt((delta_l.^2.*10.^(-0.2.*L_l)+delta_s.^2.*10.^(-0.2.*L_s)) ...
            ./(10.^(-0.2.*L_l) + 10.^(-0.2.*L_s)));
        Lc = -5.*log10(10.^(-0.2.*L_l) + 10.^(-0.2.*L_s)) - delta_cb .* qfuncinv(p/100);
    else 
        L_s = 32.98 + 23.9.*log10(2)+3*log10(f1);
        L_l = -2*log10(10^(-5*log10(f1)-12.5)+10^(-16.5));
        delta_cb = sqrt((delta_l.^2*10^(-0.2.*L_l)+delta_s^2*10^(-0.2.*L_s)) ...
            ./(10^(-0.2*L_l) + 10^(-0.2.*L_s)));
        Lc = -5.*log10(10^(-0.2.*L_l) + 10^(-0.2.*L_s)) - delta_cb * qfuncinv(p/100);
    end
    %% 总路径损耗
    PL = PL_b + Lc ;
end



