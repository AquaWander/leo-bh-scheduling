function getCurLinkRate(self, measureSINR)
    % 香农公式
    self.CurLinkRate = ...
        self.BandWidth*1e6*log10(1+10.^(measureSINR/10));
end

