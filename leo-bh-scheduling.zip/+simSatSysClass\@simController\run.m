% 2023/03/07
% 仿真平台运行的核心函数
% 所有的仿真模块都挂靠在该Method中运行
%%
function DataObj = run(self)
    NumOfShot = length(self.SatPosition(1,:,1)) - 1; % 仿真快照总数(最后一张快照不计算)
    %% 考虑边界效应，进行wrapAround
    if self.Config.ifWrapAround == 1
        self.findWrap();
        if self.ifDebug == 1
            fprintf('wrapAround扩展已完成\n'); 
        end
    end
    %% 根据输入的矩形区域范围将其离散化为等边三角形，得到等边三角形的中心点和顶点坐标
    self.DiscrInvesArea();  % 三角形中心点坐标  
    self.getTriCoord();    % 三角形顶点坐标
    if self.Config.ifWrapAround == 1
        self.getDiscrInNonWrap()    % 在wrapAround情况下，获取考察小区域的三角形编号
%     else
%         self.NofRawsInNonWrap = length(self.DiscrArea(:,1,1));
%         self.NofColsInNonWrap = length(self.DiscrArea(1,:,1));
    end
    if self.ifDebug == 1
        fprintf('考察区域离散化已完成\n'); 
    end
    %% 加载预规划的信令波位
    if self.Config.numOfSigbeam > 0
        self.getSignal(); 
        if self.ifDebug == 1
            fprintf('信令波位预规划已完成\n'); 
        end 
    end
    %% 分离升轨卫星
    self.SatPosition = tools.SeparateSat(self.SatPosition, self.Config.ifAscendUp);  
    if self.ifDebug == 1
        fprintf('升降轨卫星已分离\n'); 
    end  
    %% 计算当前区域的所有可见卫星
    self.calcuVisibleSat();
    if self.ifDebug == 1
        fprintf('可见卫星计算已完成\n'); 
    end
    %% 创建调度器
    scheduler = simSatSysClass.schedulerObj();
    if self.ifDebug == 1
        fprintf('调度器对象已生成\n');
    end
    %% 主循环体
    %----------------------------------------------------------------------
    % CP类型和slot配置
    % normal类型下，一个slot包含14个多载波符号
    % 一个Frame有10个Subframe，一个Subframe为1ms
    % SCS(kHz)  CyclicPrefixType       SlotPerSubframe
    %  15           Normal                   1                1ms/slot
    %  30           Normal                   2              0.5ms/slot
    %  60       Normal,Extended              4             0.25ms/slot
    %  120          Normal                   8            0.125ms/slot
    %  240          Normal                   16          0.0625ms/slot
    %----------------------------------------------------------------------    
    switch self.Config.SCS/1e3
        case 15
            self.slotInSubF = 1;        % 每子帧有多少时隙
            self.timeInSlot = 1e-3;     % 每时隙的长度
        case 30
            self.slotInSubF = 2;        % 每子帧有多少时隙
            self.timeInSlot = 0.5e-3;   % 每时隙的长度
        case 60
            self.slotInSubF = 4;        % 每子帧有多少时隙
            self.timeInSlot = 0.25e-3;  % 每时隙的长度
        case 120
            self.slotInSubF = 8;        % 每子帧有多少时隙
            self.timeInSlot = 0.125e-3; % 每时隙的长度
        case 240
            self.slotInSubF = 16;       % 每子帧有多少时隙
            self.timeInSlot = 0.0625e-3;% 每时隙的长度
    end
    %---------------------------------------------------------------------- 
    % 每快照子帧数
    NumOfSubFramePerShot = floor(self.Config.duration/(self.timeInSlot*self.slotInSubF));  
    % 每跳波束调度周期的子帧数
    NumOfSubFramePerSche = floor(self.Config.bhTime/self.timeInSlot/self.slotInSubF); 
    % 每快照跳波束调度周期数
    NumOfSchePerShot = floor(NumOfSubFramePerShot/NumOfSubFramePerSche);  
    % 根据调度周期数重算每快照子帧数
    NumOfSubFramePerShot = NumOfSubFramePerSche * NumOfSchePerShot; 
    % 每快照时隙数
    NumOfSlotPerShot = NumOfSubFramePerShot * self.slotInSubF;
    %---------------------------------------------------------------------- 
    self.scheInShot = NumOfSchePerShot;
    self.subFInSche = NumOfSubFramePerSche;
    self.subFInShot = NumOfSubFramePerShot;
    self.slotInShot = NumOfSlotPerShot;
    %---------------------------------------------------------------------- 
    % 创建储存仿真数据的类实例
    DataObj = simSatSysClass.dataObj.empty(NumOfShot, 0);
    %% 是否蒙特卡洛
    if self.Config.numOfMonteCarlo == 0
        numOfMethods = (self.numOfMethods_BeamGenerate) * (self.numOfMethods_BeamHopping);
        %% 遍历所有快照
        for IdxOfStep = 1 : NumOfShot
            %% 用户坐标self.UsrsPosition生成
            if self.Config.ifFixedUsrsNum == true   % 生成固定数量和位置的用户
%                 if IdxOfStep == 1
                    if self.Config.ifWrapAround == 1
                        self.numOfUsrs_inves = self.Config.meanUsrsNum; % 考察小区域的用户数量
                        % 获取用户分布密度
                        HeightOfArea = tools.LatLngCoordi2Length( ...
                            [0, self.Config.rangeOfInves(2,1)], ...
                            [0, self.Config.rangeOfInves(2,2)], ...
                            self.rOfearth);
                        LengthOfArea = self.rOfearth * ...
                            cos(self.Config.rangeOfInves(2,2)*pi/180) * ...
                            abs(self.Config.rangeOfInves(1,1)-self.Config.rangeOfInves(1,2))*pi/180;
                        AreaOfInves = HeightOfArea * LengthOfArea;
                        DensOfUsrs = self.numOfUsrs_inves/AreaOfInves;
                        % 获得考虑warpAround时总面积的用户数量
                        HeightOfAreaInAll = tools.LatLngCoordi2Length( ...
                            [0, self.wrapRange(2,1)], ...
                            [0, self.wrapRange(2,2)], ...
                            self.rOfearth);
                        LengthOfAreaInAll = self.rOfearth * ...
                            cos(self.wrapRange(2,2)*pi/180) * ...
                            abs(self.wrapRange(1,1)-self.wrapRange(1,2))*pi/180;
                        AreaOfAll = HeightOfAreaInAll * LengthOfAreaInAll;
                        self.numOfUsrs_all = fix(DensOfUsrs * AreaOfAll);                
                        % 获得UsrsPosition
                        NumOfSeqInves = length(self.SeqDiscrInNonWrap);   % 考察小区域的离散三角形总数
                        NumOfSeqAll = length(self.SeqDiscrArea(:,1));   % 全部大区域的离散三角形总数
                        selectedTriInves = sort(randperm(NumOfSeqInves, self.numOfUsrs_inves)); % 考察区域撒点
                        selectedTriWrap = sort(randperm(NumOfSeqAll, self.numOfUsrs_all)); % 全部大区域撒点
                        [~, PosInselectedAll, ~] = intersect(selectedTriWrap,self.SeqDiscrInNonWrap);    % 找到考察区域内的虚拟用户
                        selectedTriWrap(PosInselectedAll) = [];  % 删除考察区域内的虚拟用户
                        self.numOfUsrs_all = length(selectedTriWrap) + length(selectedTriInves);
                        self.UsrsPosition = zeros(self.numOfUsrs_all, 3);
                        for k = 1 : self.numOfUsrs_all
                            if k <= self.numOfUsrs_inves
                                self.UsrsPosition(k, 3) = self.SeqDiscrInNonWrap(selectedTriInves(k)); % 该用户的小三角形在全wrap区域的编号
                                self.UsrsPosition(k, 1:2) = self.SeqDiscrArea(self.UsrsPosition(k, 3), :);
                            else
                                self.UsrsPosition(k, 3) = selectedTriWrap(k-self.numOfUsrs_inves);
                                self.UsrsPosition(k, 1:2) = self.SeqDiscrArea(self.UsrsPosition(k, 3), :);
                            end
                        end
                    else
                        self.numOfUsrs_inves = self.Config.meanUsrsNum;
                        self.numOfUsrs_all = self.numOfUsrs_inves;
                        % 获得UsrsPosition
                        NumOfSeqAll = length(self.SeqDiscrArea(:,1));   % 全部区域的离散三角形总数
                        selectedTriInves = sort(randperm(NumOfSeqAll, self.numOfUsrs_inves)); % 考察区域撒点
                        self.UsrsPosition = zeros(self.numOfUsrs_inves, 3);
                        for k = 1 : self.numOfUsrs_inves
                            self.UsrsPosition(k, 3) = selectedTriInves(k);
                            self.UsrsPosition(k, 1:2) = self.SeqDiscrArea(self.UsrsPosition(k, 3), :);
                        end
                    end
                    if self.ifDebug == 1
                        fprintf('用户位置生成已完成\n'); 
                    end
%                 end
            else    % 每隔intervalStep个卫星空间状态更新step，重新生成用户
                if mod((IdxOfStep-1),self.Config.intervalStep) == 0
                    self.getUsrsPositionInPossion();
                    if self.ifDebug == 1
                        fprintf('第%d快照用户位置生成已完成\n',IdxOfStep); 
                    end                   
                end
            end
            %% 预计算
            % NumOfVisibleSat    当前快照下可见卫星数量 
            % OrderOfVisibleSat  当前快照下可见卫星的编号集合

            VisibleSatSet = self.VisibleSat(:,IdxOfStep,:);        
            % 计算当前快照可见卫星数量
            NumOfSat = length(self.VisibleSat(:,1,1));
            NumOfVisibleSat = NumOfSat; 
            for i = 1 : NumOfSat
                if VisibleSatSet(i, 1) == 500
                    NumOfVisibleSat = NumOfVisibleSat - 1; 
                end
            end
            % 计算当前快照可见卫星数量
            OrderOfVisibleSat = zeros(NumOfVisibleSat,1);
            tmpN = 1;
            for i = 1 : NumOfSat
                if VisibleSatSet(i, 1) ~= 500
                    OrderOfVisibleSat(tmpN) = i; 
                    tmpN = tmpN + 1;
                end
            end 
            %% 计算考察区域内可见卫星服务范围并判断用户所属、创建服务卫星对象实例
            self.calcuSatServArea(OrderOfVisibleSat, IdxOfStep, 0);
            if self.ifDebug == 1
                fprintf('第%d快照卫星服务范围计算已完成\n', IdxOfStep); 
            end
            %% 计算各卫星的相邻NumOfAdjaLayer层卫星编号
            self.getNeighborSat(IdxOfStep, 0);     
            if self.ifDebug == 1
                fprintf('第%d快照卫星邻居计算已完成\n', IdxOfStep); 
            end
            %% 在考虑边缘效应的情况下，去除不完整区域的卫星
            if self.Config.ifWrapAround == 1
                self.removeSomeSat(IdxOfStep, 0)
                if self.ifDebug == 1
                    fprintf('第%d快照去除wrapAround区域不完整卫星已完成\n', IdxOfStep); 
                end
            end
            %% 为每个卫星添加信令波位
            if self.Config.numOfSigbeam > 0
                self.getSignalOfSat(IdxOfStep, 0);
                if self.ifDebug == 1
                    fprintf('第%d快照卫星信令波位加载已完成\n', IdxOfStep); 
                end
            end
            %% 生成self.UsrsObj
            % 依据修正后的SatObj来生成星下用户的UsrsObj
            if self.Config.ifWrapAround == 1
                NumOfSat = length(self.OrderOfServSatCur);
                NumOfUsrs = 0;
                OrderOfUsrs = [];
                for idx_sat = 1 : NumOfSat
                    NumOfUsrs = NumOfUsrs + self.SatObj(idx_sat).numOfusrs;
                    OrderOfUsrs = [OrderOfUsrs, self.SatObj(idx_sat).servUsr];
                end
                OrderOfUsrs = sort(OrderOfUsrs,'ascend');
                self.SelectedUsrsPosition = self.UsrsPosition(OrderOfUsrs,:);
                self.numOfUsrs_selected = NumOfUsrs;
                self.UsrsObj = simSatSysClass.simUsrs.empty(self.numOfUsrs_selected, 0);
                if self.Config.numOfSigbeam > 0
                    self.UsrMapptoSig = zeros(self.numOfUsrs_selected, length(self.signalOfArea(:,1)));
                end
                self.OrderOfSelectedUsrs = OrderOfUsrs;
                for k = 1 : self.numOfUsrs_selected
                    self.UsrsObj(k).ordOfDiscr = self.SelectedUsrsPosition(k, 3);
                    self.UsrsObj(k).position = self.SelectedUsrsPosition(k, 1:2);
                    self.UsrsObj(k).homeSat = self.Usr2SatCur(OrderOfUsrs(k),1,1);
                    [DiscrArea_i,DiscrArea_j] = simSatSysClass.tools.Seq2ij(self.UsrsObj(k).ordOfDiscr, length(self.DiscrArea(:,1,1)));
                    if self.Config.numOfSigbeam > 0
                        self.UsrsObj(k).homeSig = self.SignalOfDiscrArea(DiscrArea_i,DiscrArea_j,1);
                        self.UsrMapptoSig(k, self.UsrsObj(k).homeSig) = 1;
                    
                    end
                    self.UsrsObj(k).SCS = self.Config.SCS/1e3;
                    self.UsrsObj(k).BandWidth = self.Config.BandOfLink/1e6;
                    self.UsrsObj(k).SlotInSche = self.slotInSubF * self.subFInSche;
                    self.UsrsObj(k).timeInSlot = self.timeInSlot;
                    self.UsrsObj(k).T_noise = self.Config.Usr_T_noise;
                    self.UsrsObj(k).F_noise = self.Config.Usr_F_noise;
                    self.UsrsObj(k).Pt_dBm = self.Config.Pt_dBm_Usr;
                end
            else
                self.SelectedUsrsPosition = self.UsrsPosition;
                self.numOfUsrs_selected = self.numOfUsrs_inves;
                self.UsrsObj = simSatSysClass.simUsrs.empty(self.numOfUsrs_inves, 0);
                if self.Config.numOfSigbeam > 0
                    self.UsrMapptoSig = zeros(self.numOfUsrs_selected, length(self.signalOfArea(:,1)));
                end
                self.OrderOfSelectedUsrs = 1 : self.numOfUsrs_selected;
                for k = 1 : self.numOfUsrs_inves
                    self.UsrsObj(k).ordOfDiscr = self.UsrsPosition(k, 3);
                    self.UsrsObj(k).position = self.UsrsPosition(k, 1:2);
                    self.UsrsObj(k).homeSat = self.Usr2SatCur(k,1,1);
                    [DiscrArea_i,DiscrArea_j] = simSatSysClass.tools.Seq2ij(self.UsrsObj(k).ordOfDiscr, length(self.DiscrArea(:,1,1)));
                    if self.Config.numOfSigbeam > 0
                        self.UsrsObj(k).homeSig = self.SignalOfDiscrArea(DiscrArea_i,DiscrArea_j,1);
                        self.UsrMapptoSig(k, self.UsrsObj(k).homeSig) = 1;
                    end
                    self.UsrsObj(k).SCS = self.Config.SCS/1e3;
                    self.UsrsObj(k).BandWidth = self.Config.BandOfLink/1e6;     
                    self.UsrsObj(k).SlotInSche = self.slotInSubF * self.subFInSche;
                    self.UsrsObj(k).timeInSlot = self.timeInSlot;  
                    self.UsrsObj(k).T_noise = self.Config.Usr_T_noise;
                    self.UsrsObj(k).F_noise = self.Config.Usr_F_noise;
                    self.UsrsObj(k).Pt_dBm = self.Config.Pt_dBm_Usr;
                end
            end      
            %% 为结果统计预分配空间

            % 星间/内干扰计算
            DataObj(IdxOfStep).InterfFromAll_Down = ...
                zeros( ...
                    numOfMethods, ...
                    self.slotInShot, ...
                    self.numOfUsrs_inves, ...
                    2 ...
                    );
            DataObj(IdxOfStep).InterfFromAll_Up = ...
                zeros( ...
                    numOfMethods, ...
                    self.slotInShot, ...
                    self.numOfUsrs_inves, ...
                    2 ...
                    );
            DataObj(IdxOfStep).InterfFromSingleSat_Down = ...
                zeros( ...
                    numOfMethods, ...
                    self.slotInShot, ...
                    self.numOfUsrs_inves, ...
                    2 ...
                    );
            DataObj(IdxOfStep).InterfFromSingleSat_Up = ...
                zeros( ...
                    numOfMethods, ...
                    self.slotInShot, ...
                    self.numOfUsrs_inves, ...
                    2 ...
                    );
            DataObj(IdxOfStep).InterSat_UsrsTransPort = ...
                zeros(numOfMethods, self.numOfUsrs_inves, self.scheInShot);

            % 星地同频干扰计算
            DataObj(IdxOfStep).Interf1 = ...
                zeros( ...
                    numOfMethods, ...
                    self.slotInShot, ...
                    self.numOfUsrs_inves, ...
                    3);

            DataObj(IdxOfStep).Interf2 = ...
                zeros( ...
                    numOfMethods, ...
                    self.slotInShot, ...
                    length(self.OrderOfServSatCur),...
                    self.Config.numOfSigbeam + self.Config.numOfServbeam,...
                    3);


            DataObj(IdxOfStep).Interf3 = ...
                zeros( ...
                    numOfMethods, ...
                    self.slotInShot, ...
                    length(self.OrderOfServSatCur),...
                    self.Config.numOfSigbeam + self.Config.numOfServbeam,...
                    3);

            DataObj(IdxOfStep).Interf4 = ...
                zeros( ...
                    numOfMethods, ...
                    self.slotInShot, ...
                    self.numOfUsrs_inves, ...
                    3);

            DataObj(IdxOfStep).Interf5 = ...
                zeros( ...
                    numOfMethods, ...
                    self.slotInShot, ...
                    length(self.OrderOfServSatCur),...
                    self.Config.numOfSigbeam + self.Config.numOfServbeam,...
                    3);
            
            DataObj(IdxOfStep).Interf6 = ...
                zeros( ...
                    numOfMethods, ...
                    self.slotInShot, ...
                    self.numOfUsrs_inves, ...
                    3);

            if self.ifDebug == 1
                fprintf('第%d快照干扰数据统计内存预分配已完成\n',IdxOfStep); 
            end 
            %% 跳波束调度
            % 接口生成
            interface = simSatSysClass.simInterface(self);
            scheduler.getinterface(interface); % 将类@simInterface的参数数据interface导入类@schedulerObj中
            if self.ifDebug == 1
                fprintf('第%d快照数据接口生成已完成\n', IdxOfStep); 
            end        
            % 用户业务生成
            scheduler.generateUsrsTraffic();
            if self.ifDebug == 1
                fprintf('第%d快照用户业务生成已完成\n', IdxOfStep); 
            end
            % 信令波位扫描时序生成
            if self.Config.numOfSigbeam > 0
                scheduler.generateSigSpan();
                if self.ifDebug == 1
                    fprintf('第%d快照信令波位扫描时序生成已完成\n', IdxOfStep); 
                end
            end
            
            % 信令波束 + 业务波束
            for sche = 1 : self.scheInShot
                % 以每个调度循环，开始的时候统计一下当前用户
                scheduler.getCurUsers(sche);                                
            end
            
            if self.Config.ifAdjustBHST == 1
                % 新接入边缘用户判定与服务竞争
                scheduler.judgeEdgeUsr();
                if self.ifDebug == 1
                    fprintf('第%d快照边缘用户判定与服务竞争已完成\n', IdxOfStep); 
                end
            end

            %波位生成
            scheduler.generateBeamFoot();
            if self.ifDebug == 1
                fprintf('第%d快照波位生成已完成\n', IdxOfStep); 
            end
% 
%             % 波束间功率平均分配
%             scheduler.generateBeamPower(IdxOfStep, NumOfShot);
%             if self.ifDebug == 1
%                 fprintf('第%d快照波束间功率分配已完成\n', IdxOfStep); 
%             end

            % BHST生成
            scheduler.generateBHST(IdxOfStep, NumOfShot);
            if self.ifDebug == 1
                fprintf('第%d快照BHST已完成\n', IdxOfStep); 
            end

            % 波束间功率分配
            scheduler.generateBeamPower(IdxOfStep, NumOfShot);
            if self.ifDebug == 1
                fprintf('第%d快照波束间功率分配已完成\n', IdxOfStep); 
            end

            % 波位内频率和功率分配
            scheduler.generateBPAllocation(IdxOfStep, NumOfShot);
            if self.ifDebug == 1
                fprintf('第%d快照资源分配已完成\n', IdxOfStep); 
            end

            % 接口更新       
            interface.refreshValue(self);
            if self.ifDebug == 1
                fprintf('第%d快照=数据更新已完成\n', IdxOfStep); 
            end  

            %% 干扰计算
            % 星间/星内干扰计算
            DataObj = self.calcuInterferenceForDiffBand(DataObj, IdxOfStep, 0);
%             DataObj = self.calcuInterference(DataObj, IdxOfStep, 0);

%             if self.Config.ifattenuation == 1
%                 % 考虑衰减模型
%                 DataObj = self.calcuInterference(DataObj, IdxOfStep, 0);
%             else
%                 % 仅考虑路径损耗
%                 DataObj = self.calcuInterferenceFSPL(DataObj, IdxOfStep, 0);
%             end
%             if self.ifDebug == 1
%                 fprintf('第%d快照干扰计算已完成\n', IdxOfStep); 
%             end

            % 星地同频干扰计算
%             if self.Config.ifSatAndGround == 1
%                 DataObj = self.calcuSatGroundInterference(DataObj, IdxOfStep, 0);
%                 if self.ifDebug == 1
%                     fprintf('第%d快照星地干扰计算已完成\n', IdxOfStep); 
%                 end
%             end
            %% 储存数据
            %------------------------画图数据--------------------------------%
            DataObj(IdxOfStep).forPlot.CoordiTri = self.CoordiTri;
            DataObj(IdxOfStep).forPlot.factorOfDiscr = self.Config.factorOfDiscr;
            DataObj(IdxOfStep).forPlot.rangeOfInves = self.Config.rangeOfInves;
            DataObj(IdxOfStep).forPlot.ifWrapAround = self.Config.ifWrapAround;
            DataObj(IdxOfStep).forPlot.wrapRange = self.wrapRange;
            DataObj(IdxOfStep).forPlot.numOfMethods_BeamGenerate = self.numOfMethods_BeamGenerate;
            DataObj(IdxOfStep).forPlot.numOfMethods_BeamHopping = self.numOfMethods_BeamHopping;
            DataObj(IdxOfStep).forPlot.NumOfSchePerShot = NumOfSchePerShot;
            DataObj(IdxOfStep).forPlot.stepOfSimuMove = self.Config.step;
            DataObj(IdxOfStep).forPlot.Config = self.Config;

            %---------------------其他-----------------------------%
            DataObj(IdxOfStep).UsrsTraffic = self.UsrsTraffic;
            DataObj(IdxOfStep).UsrsTransPort = self.UsrsTransPort;
            DataObj(IdxOfStep).NumOfInvesUsrs = self.numOfUsrs_inves;
            DataObj(IdxOfStep).OrderOfSelectedUsrs = self.OrderOfSelectedUsrs;
            DataObj(IdxOfStep).UsrsObj = self.UsrsObj;
            DataObj(IdxOfStep).ServSatOfDiscrAreaCur = self.ServSatOfDiscrAreaCur;
            DataObj(IdxOfStep).OrderOfServSatCur = self.OrderOfServSatCur;
            DataObj(IdxOfStep).SatObj = self.SatObj;
            DataObj(IdxOfStep).Usr2SatCur = self.Usr2SatCur;
            DataObj(IdxOfStep).TerrestrialDuplexing = self.Config.TerrestrialDuplexing;
            if self.ifDebug == 1
                fprintf('第%d快照数据存储已完成\n', IdxOfStep); 
            end
            %% 删除卫星对象和用户对象
            self.delSatObj(); 
        end
    else
        numOfMethods = (self.numOfMethods_BeamGenerate) * (self.numOfMethods_BeamHopping);
        %% 蒙特卡洛重复
        for IdxOfMonte = 1 : self.Config.numOfMonteCarlo
            %% 遍历所有快照
            for IdxOfStep = 1 : NumOfShot
                %% 用户坐标self.UsrsPosition生成
                if self.Config.ifFixedUsrsNum == true   % 生成固定数量和位置的用户
                    if IdxOfStep == 1
                        if self.Config.ifWrapAround == 1
                            self.numOfUsrs_inves = self.Config.meanUsrsNum; % 考察小区域的用户数量
                            % 获取用户分布密度
                            HeightOfArea = tools.LatLngCoordi2Length( ...
                                [0, self.Config.rangeOfInves(2,1)], ...
                                [0, self.Config.rangeOfInves(2,2)], ...
                                self.rOfearth);
                            LengthOfArea = self.rOfearth * ...
                                cos(self.Config.rangeOfInves(2,2)*pi/180) * ...
                                abs(self.Config.rangeOfInves(1,1)-self.Config.rangeOfInves(1,2))*pi/180;
                            AreaOfInves = HeightOfArea * LengthOfArea;
                            DensOfUsrs = self.numOfUsrs_inves/AreaOfInves;
                            % 获得考虑warpAround时总面积的用户数量
                            HeightOfAreaInAll = tools.LatLngCoordi2Length( ...
                                [0, self.wrapRange(2,1)], ...
                                [0, self.wrapRange(2,2)], ...
                                self.rOfearth);
                            LengthOfAreaInAll = self.rOfearth * ...
                                cos(self.wrapRange(2,2)*pi/180) * ...
                                abs(self.wrapRange(1,1)-self.wrapRange(1,2))*pi/180;
                            AreaOfAll = HeightOfAreaInAll * LengthOfAreaInAll;
                            self.numOfUsrs_all = DensOfUsrs * AreaOfAll;                
                            % 获得UsrsPosition
                            NumOfSeqInves = length(self.SeqDiscrInNonWrap);   % 考察小区域的离散三角形总数
                            NumOfSeqAll = length(self.SeqDiscrArea(:,1));   % 全部大区域的离散三角形总数
                            selectedTriInves = sort(randperm(NumOfSeqInves, self.numOfUsrs_inves)); % 考察区域撒点
                            selectedTriWrap = sort(randperm(NumOfSeqAll, self.numOfUsrs_all)); % 全部大区域撒点
                            [~, PosInselectedAll, ~] = intersect(selectedTriWrap,self.SeqDiscrInNonWrap);    % 找到考察区域内的虚拟用户
                            selectedTriWrap(PosInselectedAll) = [];  % 删除考察区域内的虚拟用户
                            self.numOfUsrs_all = length(selectedTriWrap) + length(selectedTriInves);
                            self.UsrsPosition = zeros(self.numOfUsrs_all, 3);
                            for k = 1 : self.numOfUsrs_all
                                if k <= self.numOfUsrs_inves
                                    self.UsrsPosition(k, 3) = self.SeqDiscrInNonWrap(selectedTriInves(k)); % 该用户的小三角形在全wrap区域的编号
                                    self.UsrsPosition(k, 1:2) = self.SeqDiscrArea(self.UsrsPosition(k, 3), :);
                                else
                                    self.UsrsPosition(k, 3) = selectedTriWrap(k-self.numOfUsrs_inves);
                                    self.UsrsPosition(k, 1:2) = self.SeqDiscrArea(self.UsrsPosition(k, 3), :);
                                end
                            end
                        else
                            self.numOfUsrs_inves = self.Config.meanUsrsNum;
                            self.numOfUsrs_all = self.numOfUsrs_inves;
                            % 获得UsrsPosition
                            NumOfSeqAll = length(self.SeqDiscrArea(:,1));   % 全部区域的离散三角形总数
                            selectedTriInves = sort(randperm(NumOfSeqAll, self.numOfUsrs_inves)); % 考察区域撒点
                            self.UsrsPosition = zeros(self.numOfUsrs_inves, 3);
                            for k = 1 : self.numOfUsrs_inves
                                self.UsrsPosition(k, 3) = selectedTriInves(k);
                                self.UsrsPosition(k, 1:2) = self.SeqDiscrArea(self.UsrsPosition(k, 3), :);
                            end
                        end
                        if self.ifDebug == 1
                            fprintf('蒙特卡洛第%d次用户位置生成已完成\n',IdxOfMonte); 
                        end
                    end
                else    % 每隔intervalStep个卫星空间状态更新step，重新生成用户
                    if mod((IdxOfStep-1),self.Config.intervalStep) == 0
                        self.getUsrsPositionInPossion();
                        if self.ifDebug == 1
                            fprintf('蒙特卡洛第%d次第%d快照用户位置生成已完成\n',IdxOfMonte,IdxOfStep); 
                        end                   
                    end
                end
                %% 预计算
                % NumOfVisibleSat    当前快照下可见卫星数量 
                % OrderOfVisibleSat  当前快照下可见卫星的编号集合         
                VisibleSatSet = self.VisibleSat(:,IdxOfStep,:);        
                % 计算当前快照可见卫星数量
                NumOfSat = length(self.VisibleSat(:,1,1));
                NumOfVisibleSat = NumOfSat; 
                for i = 1 : NumOfSat
                    if VisibleSatSet(i, 1) == 500
                        NumOfVisibleSat = NumOfVisibleSat - 1; 
                    end
                end
                % 计算当前快照可见卫星数量
                OrderOfVisibleSat = zeros(NumOfVisibleSat,1);
                tmpN = 1;
                for i = 1 : NumOfSat
                    if VisibleSatSet(i, 1) ~= 500
                        OrderOfVisibleSat(tmpN) = i; 
                        tmpN = tmpN + 1;
                    end
                end 
                %% 计算考察区域内可见卫星服务范围并判断用户所属、创建服务卫星对象实例
                self.calcuSatServArea(OrderOfVisibleSat, IdxOfStep, IdxOfMonte);
                if self.ifDebug == 1
                    fprintf('蒙特卡洛第%d次第%d快照卫星服务范围计算已完成\n', IdxOfMonte,IdxOfStep); 
                end
                %% 计算各卫星的相邻NumOfAdjaLayer层卫星编号
                self.getNeighborSat(IdxOfStep, IdxOfMonte);     
                if self.ifDebug == 1
                    fprintf('蒙特卡洛第%d次第%d快照卫星邻居计算已完成\n', IdxOfMonte,IdxOfStep); 
                end
                %% 为每个卫星添加信令波位
                if self.Config.numOfSigbeam > 0
                    self.getSignalOfSat(self, IdxOfStep, IdxOfMonte);
                    if self.ifDebug == 1
                        fprintf('蒙特卡洛第%d次第%d快照卫星信令波位加载已完成\n', IdxOfMonte,IdxOfStep); 
                    end
                end
                %% 在考虑边缘效应的情况下，去除不完整区域的卫星
                if self.Config.ifWrapAround == 1
                    self.removeSomeSat(IdxOfStep, IdxOfMonte)
                    if self.ifDebug == 1
                        fprintf('蒙特卡洛第%d次第%d快照去除wrapAround区域不完整卫星已完成\n', IdxOfMonte,IdxOfStep); 
                    end
                end
                %% 生成self.UsrsObj
                % 依据修正后的SatObj来生成星下用户的UsrsObj
                if self.Config.ifWrapAround == 1
                    NumOfSat = length(self.OrderOfServSatCur);
                    NumOfUsrs = 0;
                    OrderOfUsrs = [];
                    for idx_sat = 1 : NumOfSat
                        NumOfUsrs = NumOfUsrs + self.SatObj(idx_sat).numOfusrs;
                        OrderOfUsrs = [OrderOfUsrs, self.SatObj(idx_sat).servUsr];
                    end
                    OrderOfUsrs = sort(OrderOfUsrs,'ascend');
                    self.SelectedUsrsPosition = self.UsrsPosition(OrderOfUsrs,:);
                    self.numOfUsrs_selected = NumOfUsrs;
                    self.UsrsObj = simSatSysClass.simUsrs.empty(self.numOfUsrs_selected, 0);
                    self.UsrMapptoSig = zeros(self.numOfUsrs_selected, length(self.signalOfArea(:,1)));
                    self.OrderOfSelectedUsrs = OrderOfUsrs;
                    for k = 1 : self.numOfUsrs_selected
                        self.UsrsObj(k).ordOfDiscr = self.SelectedUsrsPosition(k, 3);
                        self.UsrsObj(k).position = self.SelectedUsrsPosition(k, 1:2);
                        self.UsrsObj(k).homeSat = self.Usr2SatCur(OrderOfUsrs(k),1,1);
                        [DiscrArea_i,DiscrArea_j] = simSatSysClass.tools.Seq2ij(self.UsrsObj(k).ordOfDiscr, length(self.DiscrArea(:,1,1)));
                        self.UsrsObj(k).homeSig = self.SignalOfDiscrArea(DiscrArea_i,DiscrArea_j,1);
                        self.UsrMapptoSig(k, self.UsrsObj(k).homeSig) = 1;
                        self.UsrsObj(k).SCS = self.Config.SCS/1e3;
                        self.UsrsObj(k).BandWidth = self.Config.BandOfLink/1e6;
                        self.UsrsObj(k).SlotInSche = self.slotInSubF * self.subFInSche;
                        self.UsrsObj(k).timeInSlot = self.timeInSlot;
                        self.UsrsObj(k).T_noise = self.Config.Usr_T_noise;
                        self.UsrsObj(k).F_noise = self.Config.Usr_F_noise;
                        self.UsrsObj(k).Pt_dBm = self.Config.Pt_dBm_Usr;
                    end
                else
                    self.SelectedUsrsPosition = self.UsrsPosition;
                    self.numOfUsrs_selected = self.numOfUsrs_inves;
                    self.UsrsObj = simSatSysClass.simUsrs.empty(self.numOfUsrs_inves, 0);
                    if self.Config.numOfSigbeam > 0
                        self.UsrMapptoSig = zeros(self.numOfUsrs_selected, length(self.signalOfArea(:,1)));
                    end
                    self.OrderOfSelectedUsrs = 1 : self.numOfUsrs_selected;
                    for k = 1 : self.numOfUsrs_inves
                        self.UsrsObj(k).ordOfDiscr = self.UsrsPosition(k, 3);
                        self.UsrsObj(k).position = self.UsrsPosition(k, 1:2);
                        self.UsrsObj(k).homeSat = self.Usr2SatCur(k,1,1);
                        [DiscrArea_i,DiscrArea_j] = simSatSysClass.tools.Seq2ij(self.UsrsObj(k).ordOfDiscr, length(self.DiscrArea(:,1,1)));
                        if self.Config.numOfSigbeam > 0
                            self.UsrsObj(k).homeSig = self.SignalOfDiscrArea(DiscrArea_i,DiscrArea_j,1);
                            self.UsrMapptoSig(k, self.UsrsObj(k).homeSig) = 1;
                        end
                        self.UsrsObj(k).SCS = self.Config.SCS/1e3;
                        self.UsrsObj(k).BandWidth = self.Config.BandOfLink/1e6;     
                        self.UsrsObj(k).SlotInSche = self.slotInSubF * self.subFInSche;
                        self.UsrsObj(k).timeInSlot = self.timeInSlot;  
                        self.UsrsObj(k).T_noise = self.Config.Usr_T_noise;
                        self.UsrsObj(k).F_noise = self.Config.Usr_F_noise;
                        self.UsrsObj(k).Pt_dBm = self.Config.Pt_dBm_Usr;
                    end
                end
                if self.ifDebug == 1
                    fprintf('蒙特卡洛第%d次第%d快照UsrObj生成已完成\n', IdxOfMonte,IdxOfStep); 
                end
                %% 为结果统计预分配空间
    
                % 星间/内干扰计算
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).InterfFromAll_Down = ...
                    zeros( ...
                        numOfMethods, ...
                        self.slotInShot, ...
                        self.numOfUsrs_inves, ...
                        2 ...
                        );
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).InterfFromAll_Up = ...
                    zeros( ...
                        numOfMethods, ...
                        self.slotInShot, ...
                        self.numOfUsrs_inves, ...
                        2 ...
                        );
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).InterfFromSingleSat_Down = ...
                    zeros( ...
                        numOfMethods, ...
                        self.slotInShot, ...
                        self.numOfUsrs_inves, ...
                        2 ...
                        );
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).InterfFromSingleSat_Up = ...
                    zeros( ...
                        numOfMethods, ...
                        self.slotInShot, ...
                        self.numOfUsrs_inves, ...
                        2 ...
                        );
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).InterSat_UsrsTransPort = ...
                    zeros(numOfMethods, self.numOfUsrs_inves, self.scheInShot);
    
                % 星地同频干扰计算
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).Interf1 = ...
                    zeros( ...
                        numOfMethods, ...
                        self.slotInShot, ...
                        self.numOfUsrs_inves, ...
                        3);
    
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).Interf2 = ...
                    zeros( ...
                        numOfMethods, ...
                        self.slotInShot, ...
                        length(self.OrderOfServSatCur),...
                        self.Config.numOfSigbeam + self.Config.numOfServbeam,...
                        3);
    
    
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).Interf3 = ...
                    zeros( ...
                        numOfMethods, ...
                        self.slotInShot, ...
                        length(self.OrderOfServSatCur),...
                        self.Config.numOfSigbeam + self.Config.numOfServbeam,...
                        3);
    
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).Interf4 = ...
                    zeros( ...
                        numOfMethods, ...
                        self.slotInShot, ...
                        self.numOfUsrs_inves, ...
                        3);
    
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).Interf5 = ...
                    zeros( ...
                        numOfMethods, ...
                        self.slotInShot, ...
                        length(self.OrderOfServSatCur),...
                        self.Config.numOfSigbeam + self.Config.numOfServbeam,...
                        3);
                
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).Interf6 = ...
                    zeros( ...
                        numOfMethods, ...
                        self.slotInShot, ...
                        self.numOfUsrs_inves, ...
                        3);

                if self.ifDebug == 1
                    fprintf('蒙特卡洛第%d次第%d快照干扰数据统计内存预分配已完成\n',IdxOfMonte,IdxOfStep); 
                end 
                %% 跳波束调度
                % 接口生成
                interface = simSatSysClass.simInterface(self);
                scheduler.getinterface(interface); % 将类@simInterface的参数数据interface导入类@schedulerObj中
                if self.ifDebug == 1
                    fprintf('蒙特卡洛第%d次第%d快照数据接口生成已完成\n', IdxOfMonte,IdxOfStep); 
                end        
                % 用户业务生成
                scheduler.generateUsrsTraffic();
                if self.ifDebug == 1
                    fprintf('蒙特卡洛第%d次第%d快照用户业务生成已完成\n', IdxOfMonte,IdxOfStep); 
                end
                % 信令波位扫描时序生成
                if self.Config.numOfSigbeam > 0
                    scheduler.generateSigSpan();
                    if self.ifDebug == 1
                        fprintf('蒙特卡洛第%d次第%d快照信令波位扫描时序生成已完成\n', IdxOfMonte,IdxOfStep); 
                    end
                end
               

                % 信令波束 + 业务波束
                for sche = 1 : self.scheInShot
                    % 以每个调度循环，开始的时候统计一下当前用户
                    scheduler.getCurUsers(sche);                                
                end
                
                if self.Config.ifAdjustBHST == 1
                    % 新接入边缘用户判定与服务竞争
                    scheduler.judgeEdgeUsr();
                    if self.ifDebug == 1
                        fprintf('蒙特卡洛第%d次第%d快照边缘用户判定与服务竞争已完成\n', IdxOfMonte,IdxOfStep); 
                    end
                end

                % 波位生成
                scheduler.generateBeamFoot();
                if self.ifDebug == 1
                    fprintf('蒙特卡洛第%d次第%d快照波位生成已完成\n', IdxOfMonte,IdxOfStep); 
                end
                % BHST生成
                scheduler.generateBHST();
                if self.ifDebug == 1
                    fprintf('蒙特卡洛第%d次第%d快照BHST生成已完成\n', IdxOfMonte,IdxOfStep); 
                end

                % 接口更新       
                interface.refreshValue(self);
                if self.ifDebug == 1
                    fprintf('蒙特卡洛第%d次第%d快照数据更新已完成\n', IdxOfMonte,IdxOfStep); 
                end   
                %% 干扰计算
                 % 星间/星内干扰计算
                DataObj = self.calcuInterference(DataObj, IdxOfStep, IdxOfMonte);
                if self.ifDebug == 1
                    fprintf('蒙特卡洛第%d次第%d快照干扰计算已完成\n', IdxOfMonte,IdxOfStep); 
                end
    
                % 星地同频干扰计算
                DataObj = self.calcuSatGroundInterference(DataObj, IdxOfStep, IdxOfMonte);
                if self.ifDebug == 1
                    fprintf('蒙特卡洛第%d次第%d快照星地干扰计算已完成\n', IdxOfMonte,IdxOfStep); 
                end
                %% 储存数据
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).UsrsTraffic = self.UsrsTraffic;
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).UsrsTransPort = self.UsrsTransPort;
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).NumOfInvesUsrs = self.numOfUsrs_inves;
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).OrderOfSelectedUsrs = self.OrderOfSelectedUsrs;
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).UsrsObj = self.UsrsObj;
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).ServSatOfDiscrAreaCur = self.ServSatOfDiscrAreaCur;
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).OrderOfServSatCur = self.OrderOfServSatCur;
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).SatObj = self.SatObj;
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).Usr2SatCur = self.Usr2SatCur;
                DataObj((IdxOfMonte-1)*NumOfShot+IdxOfStep).TerrestrialDuplexing = self.Config.TerrestrialDuplexing;
                if self.ifDebug == 1
                    fprintf('蒙特卡洛第%d次第%d快照数据存储已完成\n', IdxOfMonte,IdxOfStep); 
                end
                %% 删除卫星对象和用户对象
                self.delSatObj(); 
            end
        end
    end
end




















