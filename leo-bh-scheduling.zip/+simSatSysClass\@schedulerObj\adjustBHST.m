function adjustBHST(self)
%ADJUSTBHST 此处显示有关此函数的摘要
%   此处显示详细说明
    % 遍历调度周期
        % 遍历卫星
            % 遍历卫星的邻居星
                % 找到与邻居星的边缘用户
                % 判断边缘用户归属的业务波位
                    % 对比两星边缘用户的覆盖交叉，由用户密度小的做出妥协
                    % 遍历时隙，看是否同时有边缘用户被点亮
                        % 如果有，密度小的卫星调整BHST，在当前调度周期里，找到第1个无边缘用户被调度的时隙进行交换
                            % 如果不存在无边缘用户被调度的时隙，则找到被调度边缘用户最少的时隙进行交换
    method_type = 1; %                        
    for scheIdx = 1 : self.interface.ScheInShot
        adjaMatrix = self.interface.NeighborAdjaMatrix;
        for satIdx  = 1 : length(self.interface.OrderOfServSatCur)
            NeighborSat = self.interface.SatObj(satIdx).Neighbor(1,:);
            NeighborSat = NeighborSat(NeighborSat~=0);
            BHST = self.interface.tmpSat(satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+1):(scheIdx*self.interface.SlotInSche));
            for neighbor = 1 : length(NeighborSat)
                neighbor_satIdx = find(self.interface.OrderOfServSatCur==NeighborSat(neighbor));
                if adjaMatrix(satIdx, neighbor_satIdx) == 0
                    break
                end
                adjaMatrix(satIdx, neighbor_satIdx) = 0;
                adjaMatrix(neighbor_satIdx, satIdx) = 0;
                egdeSigSeq = intersect(self.interface.SatObj(satIdx).egdeSigSeq,self.interface.SatObj(neighbor_satIdx).egdeSigSeq);
                BHST_neighbor = self.interface.tmpSat(neighbor_satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+1):(scheIdx*self.interface.SlotInSche));
                for sigIdx = 1 : length(egdeSigSeq)
                    edgeUsr_sat = [];
                    edgeUsr_sat_servBeamf = [];
                    edgeUsr_neighbor = [];
                    edgeUsr_neighbor_servBeamf = [];
                    sigBidx = find(self.interface.SatObj(satIdx).IdxOfsigbeam==egdeSigSeq(sigIdx));
                    tmpUsrs_1 = self.interface.SatObj(satIdx).SignalBeamfoot(sigBidx).usrs;
                    tmpUsrs_2 = self.interface.SatObj(satIdx).servUsr(scheIdx,:);
                    tmpUsrs_2 = tmpUsrs_2(tmpUsrs_2~=0);
                    selectedUsr = intersect(tmpUsrs_1, tmpUsrs_2);
                    edgeUsr_sat = [edgeUsr_sat selectedUsr];
                    % 判断该交叠覆盖信令波位上是否双方都有用户，如果有主星一方没有用户，则跳过该信令波位
                    if isempty(edgeUsr_sat)
                        continue
                    end

                    for servBIdx = 1 : self.interface.tmpSat(satIdx).NumOfBeamFoot(scheIdx)
                        flag = 0;
                        for idx_selectedUsr = 1 : length(selectedUsr)
                            if find(self.interface.tmpSat(satIdx).beamfoot(scheIdx,servBIdx).usrs==selectedUsr(idx_selectedUsr))
                                flag = 1;
                            end
                        end
                        if flag == 1
                            edgeUsr_sat_servBeamf = [edgeUsr_sat_servBeamf servBIdx];
                        end
                    end

                    sigBidx_tmp = find(self.interface.SatObj(neighbor_satIdx).IdxOfsigbeam==egdeSigSeq(sigIdx));
                    tmpUsrs_3 = self.interface.SatObj(neighbor_satIdx).SignalBeamfoot(sigBidx_tmp).usrs;
                    tmpUsrs_4 = self.interface.SatObj(neighbor_satIdx).servUsr(scheIdx,:);
                    tmpUsrs_4 = tmpUsrs_4(tmpUsrs_4~=0);
                    selectedUsr_neighbor = intersect(tmpUsrs_3, tmpUsrs_4);
                    edgeUsr_neighbor = [edgeUsr_neighbor intersect(tmpUsrs_3, tmpUsrs_4)];
                    % 判断该交叠覆盖信令波位上是否双方都有用户，如果有邻星一方没有用户，则跳过该信令波位
                    if isempty(edgeUsr_neighbor)
                        continue
                    end

                    for servBIdx = 1 : self.interface.tmpSat(neighbor_satIdx).NumOfBeamFoot(scheIdx)
                        flag = 0;
                        for idx_selectedUsr_neighbor = 1 : length(selectedUsr_neighbor)
                            if find(self.interface.tmpSat(neighbor_satIdx).beamfoot(scheIdx,servBIdx).usrs==selectedUsr_neighbor(idx_selectedUsr_neighbor))
                                flag = 1;
                            end
                        end
                        if flag == 1
                            edgeUsr_neighbor_servBeamf = [edgeUsr_neighbor_servBeamf servBIdx];
                        end
                    end
                    if (length(edgeUsr_sat)~=length(edgeUsr_sat_servBeamf)) || (length(edgeUsr_neighbor)~=length(edgeUsr_neighbor_servBeamf)) 
                        error('边缘用户寻找所属业务波位出错！')
                    end
                    

                    if method_type == 1    % 边缘波位用户密度
                        if length(edgeUsr_sat) > length(edgeUsr_neighbor)
                            axis = zeros(self.interface.SlotInSche,2);
                            for slotIdx = 1 : self.interface.SlotInSche
                                tmp1 = intersect(BHST(:, slotIdx), edgeUsr_sat_servBeamf);
                                if ~isempty(tmp1)
                                    axis(slotIdx,1) = 1;
                                end
                                tmp2 = intersect(BHST_neighbor(:, slotIdx), edgeUsr_neighbor_servBeamf);
                                if ~isempty(tmp2)
                                    axis(slotIdx,2) = 1;
                                end
                            end
                            for slotIdx = 1 : self.interface.SlotInSche
                                if (axis(slotIdx,1)==1) && (axis(slotIdx,2)==1)
                                    tmpOrder = find(axis(:,1)==0);
                                    tmpOrder_2 = find(axis(tmpOrder,2)==0);
                                    if isempty(tmpOrder_2)
                                        continue
                                    end
                                    selectslot = tmpOrder(tmpOrder_2(1));                                    
                                    if ~isempty(selectslot)
                                        tmp = self.interface.tmpSat(neighbor_satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+slotIdx));
                                        self.interface.tmpSat(neighbor_satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+slotIdx)) = ...
                                            self.interface.tmpSat(neighbor_satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+selectslot));
                                        self.interface.tmpSat(neighbor_satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+selectslot))= ...
                                            tmp;
                                        tmp = axis(slotIdx,2);
                                        axis(slotIdx,2) = axis(selectslot,2);
                                        axis(selectslot,2) = tmp;
                                    end
                                end
                            end
                        else
                            axis = zeros(self.interface.SlotInSche,2);
                            for slotIdx = 1 : self.interface.SlotInSche
                                tmp1 = intersect(BHST(:, slotIdx), edgeUsr_sat_servBeamf);
                                if ~isempty(tmp1)
                                    axis(slotIdx,1) = 1;
                                end
                                tmp2 = intersect(BHST_neighbor(:, slotIdx), edgeUsr_neighbor_servBeamf);
                                if ~isempty(tmp2)
                                    axis(slotIdx,2) = 1;
                                end
                            end
                            for slotIdx = 1 : self.interface.SlotInSche
                                if (axis(slotIdx,1)==1) && (axis(slotIdx,2)==1)
                                    tmpOrder = find(axis(:,1)==0);
                                    tmpOrder_2 = find(axis(tmpOrder,2)==0);
                                    if isempty(tmpOrder_2)
                                        continue
                                    end
                                    selectslot = tmpOrder(tmpOrder_2(1));                                    
                                    if ~isempty(selectslot)
                                        tmp = self.interface.tmpSat(satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+slotIdx));
                                        self.interface.tmpSat(satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+slotIdx)) = ...
                                            self.interface.tmpSat(satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+selectslot));
                                        self.interface.tmpSat(satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+selectslot))= ...
                                            tmp;
                                        tmp = axis(slotIdx,1);
                                        axis(slotIdx,1) = axis(selectslot,1);
                                        axis(selectslot,1) = tmp;
                                    end
                                end
                            end    
                        end
                    else    % 卫星负载
                        if length(self.interface.SatObj(satIdx).servUsr) > length(self.interface.SatObj(neighbor_satIdx).servUsr)
                            axis = zeros(self.interface.SlotInSche,2);
                            for slotIdx = 1 : self.interface.SlotInSche
                                tmp1 = intersect(BHST(:, slotIdx), edgeUsr_sat_servBeamf);
                                if ~isempty(tmp1)
                                    axis(slotIdx,1) = 1;
                                end
                                tmp2 = intersect(BHST_neighbor(:, slotIdx), edgeUsr_neighbor_servBeamf);
                                if ~isempty(tmp2)
                                    axis(slotIdx,2) = 1;
                                end
                            end
                            for slotIdx = 1 : self.interface.SlotInSche
                                if (axis(slotIdx,1)==1) && (axis(slotIdx,2)==1)
                                    tmpOrder = find(axis(:,1)==0);
                                    tmpOrder_2 = find(axis(tmpOrder,2)==0);
                                    if isempty(tmpOrder_2)
                                        continue
                                    end
                                    selectslot = tmpOrder(tmpOrder_2(1));                                    
                                    if ~isempty(selectslot)
                                        tmp = self.interface.tmpSat(neighbor_satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+slotIdx));
                                        self.interface.tmpSat(neighbor_satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+slotIdx)) = ...
                                            self.interface.tmpSat(neighbor_satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+selectslot));
                                        self.interface.tmpSat(neighbor_satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+selectslot))= ...
                                            tmp;
                                        tmp = axis(slotIdx,2);
                                        axis(slotIdx,2) = axis(selectslot,2);
                                        axis(selectslot,2) = tmp;
                                    end
                                end
                            end
                        else
                            axis = zeros(self.interface.SlotInSche,2);
                            for slotIdx = 1 : self.interface.SlotInSche
                                tmp1 = intersect(BHST(:, slotIdx), edgeUsr_sat_servBeamf);
                                if ~isempty(tmp1)
                                    axis(slotIdx,1) = 1;
                                end
                                tmp2 = intersect(BHST_neighbor(:, slotIdx), edgeUsr_neighbor_servBeamf);
                                if ~isempty(tmp2)
                                    axis(slotIdx,2) = 1;
                                end
                            end
                            for slotIdx = 1 : self.interface.SlotInSche
                                if (axis(slotIdx,1)==1) && (axis(slotIdx,2)==1)
                                    tmpOrder = find(axis(:,1)==0);
                                    tmpOrder_2 = find(axis(tmpOrder,2)==0);
                                    if isempty(tmpOrder_2)
                                        continue
                                    end
                                    selectslot = tmpOrder(tmpOrder_2(1));                                    
                                    if ~isempty(selectslot)
                                        tmp = self.interface.tmpSat(satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+slotIdx));
                                        self.interface.tmpSat(satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+slotIdx)) = ...
                                            self.interface.tmpSat(satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+selectslot));
                                        self.interface.tmpSat(satIdx).BHST(:,((scheIdx-1)*self.interface.SlotInSche+selectslot))= ...
                                            tmp;
                                        tmp = axis(slotIdx,1);
                                        axis(slotIdx,1) = axis(selectslot,1);
                                        axis(selectslot,1) = tmp;
                                    end
                                end
                            end 
                        end
                    end
                end

            end
            
        end

    end


end

