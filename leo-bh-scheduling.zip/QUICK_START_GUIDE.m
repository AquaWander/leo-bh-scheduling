% QUICK_START_GUIDE.m
% 快速开始指南：禁忌搜索 vs DQN 对比实验
%
% 本脚本将引导您完成整个实验流程

clear; clc;

fprintf('============================================================\n');
fprintf('  禁忌搜索 vs DQN：性能对比实验 - 快速开始指南\n');
fprintf('============================================================\n\n');

%% 步骤1：环境检查
fprintf('步骤 1/5：检查环境...\n');
fprintf('----------------------------------------\n');
try
    check_environment;
    fprintf('[✓] 环境检查完成\n\n');
catch ME
    fprintf('[✗] 环境检查失败: %s\n\n', ME.message);
    return;
end

%% 步骤2：运行禁忌搜索基线
fprintf('步骤 2/5：运行禁忌搜索算法（5次）...\n');
fprintf('----------------------------------------\n');
fprintf('注意：这可能需要几分钟时间\n');
fprintf('是否继续？(y/n): ');

choice = input('', 's');
if lower(choice) == 'y'
    try
        run_TabuSearch;
        fprintf('[✓] 禁忌搜索基线测试完成\n\n');
    catch ME
        fprintf('[✗] 禁忌搜索运行失败: %s\n\n', ME.message);
        return;
    end
else
    fprintf('[i] 跳过禁忌搜索测试\n\n');
end

%% 步骤3：运行DQN对比
fprintf('步骤 3/5：运行DQN算法（10次）...\n');
fprintf('----------------------------------------\n');
fprintf('注意：这可能需要更长时间\n');
fprintf('是否继续？(y/n): ');

choice = input('', 's');
if lower(choice) == 'y'
    try
        run_DQN;
        fprintf('[✓] DQN对比测试完成\n\n');
    catch ME
        fprintf('[✗] DQN运行失败: %s\n\n', ME.message);
        return;
    end
else
    fprintf('[i] 跳过DQN测试\n\n');
end

%% 步骤4：生成对比图表
fprintf('步骤 4/5：生成对比图表...\n');
fprintf('----------------------------------------\n');

% 吞吐量对比
fprintf('生成吞吐量对比图...\n');
try
    visualize.plot_Throughput_Comparison;
    fprintf('[✓] 吞吐量对比图生成完成\n');
catch ME
    fprintf('[✗] 吞吐量对比图生成失败: %s\n', ME.message);
end

% 满足率对比
fprintf('生成满足率对比图...\n');
try
    visualize.plot_Satisfaction_Rate;
    fprintf('[✓] 满足率对比图生成完成\n');
catch ME
    fprintf('[✗] 满足率对比图生成失败: %s\n', ME.message);
end

% SINR CDF对比
fprintf('生成SINR CDF对比图...\n');
try
    visualize.plot_SINR_CDF;
    fprintf('[✓] SINR CDF对比图生成完成\n');
catch ME
    fprintf('[✗] SINR CDF对比图生成失败: %s\n', ME.message);
end

% 时间对比
fprintf('生成运行时间对比图...\n');
try
    visualize.plot_Time_Comparison;
    fprintf('[✓] 运行时间对比图生成完成\n');
catch ME
    fprintf('[✗] 运行时间对比图生成失败: %s\n', ME.message);
end

fprintf('\n');

%% 步骤5：综合统计分析
fprintf('步骤 5/5：综合统计分析...\n');
fprintf('----------------------------------------\n');
try
    utils.perform_statistics;
    fprintf('[✓] 综合统计分析完成\n\n');
catch ME
    fprintf('[✗] 综合统计分析失败: %s\n\n', ME.message);
    return;
end

%% 完成
fprintf('============================================================\n');
fprintf('  实验流程完成！\n');
fprintf('============================================================\n\n');

fprintf('生成的文件:\n');
fprintf('  - results/results_TabuSearch_*.mat\n');
fprintf('  - results/results_DQN_*.mat\n');
fprintf('  - results/Statistics_Report_*.mat\n');
fprintf('  - visualize/*.png\n');
fprintf('  - visualize/*.fig\n');
fprintf('  - docs/Comparison_Report.md\n');
fprintf('\n');

fprintf('下一步:\n');
fprintf('  1. 查看生成的可视化图表\n');
fprintf('  2. 阅读 docs/Comparison_Report.md 了解详细分析\n');
fprintf('  3. 根据需要调整参数重新运行实验\n');
fprintf('\n');

fprintf('提示:\n');
fprintf('  - 使用 type filename.m 查看脚本内容\n');
fprintf('  - 使用 help functionname 查看函数帮助\n');
fprintf('  - 使用 open filename.m 在编辑器中打开文件\n');
fprintf('\n');
