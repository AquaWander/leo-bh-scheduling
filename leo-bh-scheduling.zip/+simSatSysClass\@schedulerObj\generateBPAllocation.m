function generateBPAllocation(self, IdxOfStep, NumOfShot)

    % 平均分配
    methods.BPAllocation_Average(self.interface);

%     % B P 
%     methods.BPAllocation_BandandPower(self.interface);

%     % B
%     methods.BPAllocation_BandOnly(self.interface);

%     % P 
%     methods.BPAllocation_PowerOnly(self.interface);

%     % B 
%     methods.BPAllocation_BandOnlySINR(self.interface);


end