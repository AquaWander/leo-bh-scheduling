function getSignalOfSat(self, IdxOfStep, MC_idx)
    %获得信令波位和卫星的所属关系，这个是会随着step变化的，要放在循环下面
    %要传入当前step的序号，跳波束一个step总的调度周期数
    ifDebug = self.ifDebug;
    
%     signalOfArea = self.signalOfArea;
    OrderOfSat = self.OrderOfServSatCur;
    NumOfSat = length(OrderOfSat);
    
%     
%     tempSignalInfo = zeros(length(signalOfArea(1,:)),3);
%     tempSignalInfo(:,1:2) = signalOfArea(:,1:2); %用于暂时存储信令波位点的信息，1-2列是坐标，第3列是所属卫星
%     
%     
    
    
    %% 统计信令波位到卫星的映射关系
    ServSatOfDiscrAreaCur = self.ServSatOfDiscrAreaCur;
    % 来自self.calcuSatServArea()
    % 当前step考察区域中各三角形的归属卫星编号，即储存卫星的服务范围
    % 矩阵，格式为"DiscrArea行数×DiscrArea列数"
    % ServSatOfDiscrAreaCur(i, j)表示第i行第j列三角形的归属卫星编号
    SignalOfDiscrArea = self.SignalOfDiscrArea;
    % 来自self.getSignal()，储存三角形到信令波位的映射关系
    % 矩阵，格式为“区域总行数×区域总列数×2”
    % SignalOfDiscrArea(i, j, 1)表示DiscrArea中第i行第j列三角形所属的信令波位在signalOfArea的编号
    % SignalOfDiscrArea(i, j, 2)表示DiscrArea中第i行第j列三角形所属的信令波位在全球原始编号
    NumOfSignalBeam = length(self.signalOfArea(:, 1));
    tempMapping = zeros(NumOfSignalBeam, NumOfSat);
    colNum = length(self.DiscrArea(1,:,1));
    rawNum = length(self.DiscrArea(:,1,1));
    for j = 1 : colNum
        for i = 1 : rawNum
    %         if isempty(fing(findingsSignal == SignalOfDiscrArea(i, j, 1))) % 如果该波位没有被记录过
            satSeq = ServSatOfDiscrAreaCur(i, j);
            satIdx = find(self.OrderOfServSatCur == satSeq);
    %         end
            BeamIdx = SignalOfDiscrArea(i, j, 1);
%             tempMapping(BeamIdx, satIdx) = tempMapping(BeamIdx, satIdx) + 1;%相当于记录这个波位下有几个三角形属于哪个卫星
            if tempMapping(BeamIdx, satIdx) == 0
                tempMapping(BeamIdx, satIdx) = 1;
            end
%             if ifDebug == 1
%                 fprintf('第%d快照建立信令波位到卫星的映射第一步%f%%\n', IdxOfStep, ((j-1)*rawNum+i)*100/(rawNum*colNum)); 
%             end        
        end
    end
    self.SigBeamMapptoSat = tempMapping;
    %% 填写卫星实例的属性
    for k = 1 : NumOfSat
        self.SatObj(k).SignalBeamfoot = struct( ...
            'servTri', zeros(), ...
            'centerTri', 0, ...
            'usrs', zeros() ...
            );
    end
    tmpUsrsSeq = self.UsrsPosition(:, 3);
%     tmpUsrsSeq = self.SelectedUsrsPosition(:, 3);
    for k = 1 : NumOfSat
        tempSignalIdxSet = find(tempMapping(:, k) == 1);
        self.SatObj(k).numOfsigbeam = length(tempSignalIdxSet);
        self.SatObj(k).IdxOfsigbeam = tempSignalIdxSet;
        self.SatObj(k).SeqOfsigbeam = self.signalOfArea(tempSignalIdxSet, 4);
        self.SatObj(k).egdeSig = zeros(NumOfSat, length(tempSignalIdxSet));
        for beamIdx = 1 : self.SatObj(k).numOfsigbeam
            self.SatObj(k).SignalBeamfoot(beamIdx).centerTri = ...
                self.signalOfArea(self.SatObj(k).IdxOfsigbeam(beamIdx), 3); 
            tmpServTriSeq = find(SignalOfDiscrArea(:, :, 1) == self.SatObj(k).IdxOfsigbeam(beamIdx));
            self.SatObj(k).SignalBeamfoot(beamIdx).servTri = tmpServTriSeq;
            [~, idxOftmpUsrsSeq, ~] = intersect(tmpUsrsSeq, tmpServTriSeq);
            self.SatObj(k).SignalBeamfoot(beamIdx).usrs = idxOftmpUsrsSeq;
        end
%         if ifDebug == 1
%             fprintf('第%d快照建立信令波位到卫星的映射第二步%f%%\n', IdxOfStep, ((j-1)*rawNum+i)*100/(rawNum*colNum)); 
%         end 
        self.SatObj(k).egdeSigSeq = [];
        tempTex = self.SigBeamMapptoSat(tempSignalIdxSet, :);
        for ti = 1 : length(tempSignalIdxSet)
            tmpSat = find(tempTex(ti, :)==1);
            tmpSat(tmpSat==k) = [];
            if ~isempty(tmpSat)
                self.SatObj(k).egdeSig(tmpSat, tempSignalIdxSet(ti)) = 1;
                self.SatObj(k).egdeSigSeq = [self.SatObj(k).egdeSigSeq, tempSignalIdxSet(ti)];
            end
        end

    end
    %% 信令波位扫描排序
    % 给信令波位点排序，并为每个卫星形成信令点波位
    for i = 1 : NumOfSat
        A = zeros(self.SatObj(i).numOfsigbeam,2);%这是每个波位的经纬度
        for si = 1 : self.SatObj(i).numOfsigbeam
            triNo = self.SatObj(i).SignalBeamfoot(si).centerTri;
            A(si,1:2) = self.SeqDiscrArea(triNo,:); 
        end
        if self.Config.rangeOfInves(1,1) < self.Config.rangeOfInves(1,2) %如果是向着经度增大的方向
            %以下是给A排序，按照经纬度之差的大小排序
%             A = tempSignalInfo(A,1:2);
            B = zeros();
            for tt = 1 : length(A(:,1))
                B(tt) = A(tt,1) - A(tt,2);
            end
            [~,I] = sort(B);
    %         A(I,:);
            self.SatObj(i).SpanIDXOfsigbeam = I;%排序后的结果赋值
        else%如果跨过了180，排序的时候经度得改变一下
%             A = tempSignalInfo(A,1:2);
            AA = A;
            B=zeros();
            for tt = 1 : length(AA(:,1))
                if AA(tt,1) < 0
                    AA(tt,1) = 360 + AA(tt,1); 
                end
                B(tt) = AA(tt,1) - AA(tt,2);
            end
            [~,I] = sort(B);
    %         A(I,:);
            self.SatObj(i).SpanIDXOfsigbeam = I;%排序后的结果赋值
        end

%         %获得星下信令波位的经纬度信息，用中心三角形

%         %以下是给A排序，按照经纬度之差的大小排序
%         B=zeros();
%         for tt = 1 : length(A)
%             B(tt) = A(tt,1) - A(tt,2);
%         end
%         [~,I] = sort(B);%这是排序
%         self.SatObj(i).SpanIDXOfsigbeam = I;%排序后的结果赋值
    end


end
% %% 
% function getSignalOfSat(self, IdxOfStep, MC_idx)
% %获得信令波位和卫星的所属关系，这个是会随着step变化的，要放在循环下面
% %要传入当前step的序号，跳波束一个step总的调度周期数
% ifDebug = self.ifDebug;
% 
% signalOfArea = self.signalOfArea;
% OrderOfSat = self.OrderOfServSatCur;
% NumOfSat = length(OrderOfSat);
% 
% tempSatCoord = self.VisibleSat(OrderOfSat, step, :);%获得当前可见卫星的经纬度
% 
% %用于暂时存储信令波位点的信息，1-2列是坐标，第三列是所属卫星服务范围
% tempSignalInfo = zeros(length(signalOfArea),3);
% tempSignalInfo(:,1:2) = signalOfArea(:,1:2);
% 
% %获得每个波位所属的卫星编号
% for i = 1 : length(signalOfArea)
%     tempSignalInfo(i,3) = findShortest(...
%                             tempSignalInfo(i,1:2),...
%                             tempSatCoord(:, 1:2)...
%                             );%找到最近的卫星
% end
% 
% %一些需要的参数
% Rb = self.Config.intervalOfSig;%信令波位半径
% Radius = self.radiusOfearth;
% hOfDiscr = tools.LatLngCoordi2Length([0 0], [0 1], Radius)/self.SimConfig.factorOfdiscr;
% NofRaw = 2 * floor(Rb/(2*hOfDiscr/sqrt(3))); % 一个波位占用的离散三角行数
% rawNum = length(self.DiscrArea(:,1,1));
% colNum = length(self.DiscrArea(1,:,1));
% 
% %关于信令波束表格的参数
% totalslot = self.subFInSche*self.scheInShot;%波位总的次数
% signalNum = self.Communication.numOfSigBeam;%就从类里面获得这个数吧...
% interval = self.Communication.interOfSigBeam;%信令波束扫描间隔
% 
% %给信令波位点排序，并为每个卫星形成信令点波位
% for i = 1 : NumOfOfSat
%     if ismember(i,tempSignalInfo(:,3))
%         A = find(tempSignalInfo(:,3) == i);%找到属于这个卫星的信令波位点
%     else
%         self.SatObj(i).signaltable = zeros(totalslot,signalNum);  
%         fprintf('第%d快照第%d个卫星信令波束扫描表格生成%f%%\n', IdxOfStep, i, i*100/NumOfOfSat); 
%         continue;
%     end
%     %以下是给A排序，按照经纬度之和的大小排序
%     A = tempSignalInfo(A,1:2);
%     B=zeros();
%     for tt = 1 : length(A)
%         B(tt) = A(tt,1) - A(tt,2);
%     end
%     [~,I] = sort(B);
%     A(I,:);
%     %然后把排好序的波位点存到SatObj里
%     self.SatObj(i).signalbeam = struct( ...
%             'coord', [0,0], ...
%             'servTri', 0 ...
%             );
%     for j = 1 : length(A(:,1))
%         self.SatObj(i).signalbeam(j).coord = A(j,:);%按顺序存储信令波位中心坐标
%         [Ordpos(1),Ordpos(2), ifUpTri] = tools.findPointXY(self, A(j,2),A(j,1));
%         servTri = setBeamFoot(Ordpos, ifUpTri, NofRaw, rawNum, colNum); 
%         self.SatObj(i).signalbeam(j).servTri = servTri;
%     end
%     %还要为每个卫星生成波位点扫描顺序
%     signaltable = zeros(totalslot,signalNum);%建立信令波束表格，是在整个跳波束周期里的
%     totalSerial = length(A(:,1));%总的波位数量
%     %第一个波束的表格，从编号1开始
%     signaltable(1,1) = 1;
%     c = 2;%计数
%     while(c <= totalslot)
%         signaltable(c,1) = signaltable(c - 1,1) + 1;
%         c = c + 1;
%         if mod(signaltable(c - 1,1),totalSerial) == 0%如果已经全部都遍历过了
%             for ii = 1 : interval%填充扫描间隔
%                 signaltable(c,1) = 0;
%                 c = c + 1;
%             end
%             signaltable(c,1) = 1;
%             c = c + 1;
%         end
%     end
%     %第二个波束的表格，编号从所有波位点中间那个开始
%     signaltable(1,2) = floor(length(A)/2) + 1;
%     cc = 2;%计数
%     while(cc <= totalslot)
%         signaltable(cc,2) = signaltable(cc - 1,2) + 1;
%         cc = cc + 1;
%         if mod(signaltable(cc - 1,2),totalSerial) == 0%如果已经全部都遍历过了
%             for ii = 1 : interval%填充扫描间隔
%                 signaltable(cc,2) = 0;
%                 cc = cc + 1;
%             end
%             signaltable(cc,2) = 1;
%             cc = cc + 1;
%         end
%     end    
% 
%     %放到卫星对象里
%     self.SatObj(i).signaltable = signaltable;  
%     fprintf('第%d快照第%d个卫星信令波束扫描表格生成%f%%\n', IdxOfStep, i, i*100/NumOfOfSat); 
% end
% 
% 
% end
% 
% %% 找到距离最近的点
% function Satpos = findShortest(pos, SatposSet)
% % pos 考察坐标
% % SatposSet 卫星坐标集合
%     R = 6371.393e3; % 地球半径
% 
%     lngA = pos(1);
%     alpha1 = lngA * pi / 180;
%     latA = pos(2);
%     beta1 = latA * pi / 180;
% 
%     num = length(SatposSet(:,1));
%     len = zeros(num,1);%可见卫星个数
%     for i = 1 : num
%         lngB = SatposSet(i, 1);
%         alpha2 = lngB * pi / 180;
%         latB = SatposSet(i, 2);
%         beta2 = latB * pi / 180;
%         len(i) = R * acos(cos(pi/2-beta2)*cos(pi/2-beta1) + sin(pi/2-beta2)*sin(pi/2-beta1)*cos(alpha2-alpha1));
%     end
%     Satpos = find(len == min(len), 1);
% end
% 
% 
% %% 已知波位中心三角形在DiscrArea中坐标为Ordpos，找到波位所含所有三角形
% function SeqOfTri = setBeamFoot(Ordpos, ifUpTri, NofRaw, rawNum, colNum)
% % NofRaw 波位含三角形的行数
% % NumOfBeam 波位编号
%     if ifUpTri == false
%         if Ordpos(2) + 1 <= colNum
%             Ordpos(2) = Ordpos(2) + 1;
%         else
%             Ordpos(2) = Ordpos(2) - 1;
%         end
% 
%     end
%     SeqOfTri = [];
%     for ii = 1 : NofRaw/2
%         for jj = 1 : (NofRaw+1)+2*(ii-1)
%             temp_i1 = Ordpos(1) - NofRaw/2 + ii;
%             temp_j1 = Ordpos(2) - NofRaw/2 + 1 - ii + jj;
%             temp_Seq1 = ij2Seq(temp_i1, temp_j1, rawNum, colNum);
%             temp_i2 = Ordpos(1) + NofRaw/2 - ii + 1;
%             temp_j2 = temp_j1;
%             temp_Seq2 = ij2Seq(temp_i2, temp_j2, rawNum, colNum);
%             if temp_Seq1 ~= 0 
%                 SeqOfTri = [SeqOfTri temp_Seq1];
%             end
%             if temp_Seq2 ~= 0
%                 SeqOfTri = [SeqOfTri temp_Seq2];
%             end
%         end
%     end
%     SeqOfTri = sort(SeqOfTri, 'ascend');
% end
% 
% %% DiscrArea中第i行第j列小三角形在SeqDiscrArea中的序号
% function Seq = ij2Seq(DiscrArea_i, DiscrArea_j, rawNum, colNum)
%     if DiscrArea_i <= rawNum && DiscrArea_i > 0 && DiscrArea_j <= colNum && DiscrArea_j > 0
%         Seq = (DiscrArea_j - 1) * rawNum + DiscrArea_i;
%     else
%         Seq = 0;
%     end
% end