classdef ReplayBuffer < handle
    % ReplayBuffer 经验回放缓冲区
    % 用于存储和采样DQN训练所需的(s, a, r, s', done)经验
    
    properties (Access = private)
        capacity        % 缓冲区容量
        buffer          % 存储经验的缓冲区
        size            % 当前大小
        index           % 当前写入位置
    end
    
    methods
        function obj = ReplayBuffer(capacity)
            % 构造函数
            %   capacity: 缓冲区容量（整数）
            
            if nargin == 0
                obj.capacity = 10000; % 默认容量
            else
                obj.capacity = capacity;
            end
            
            obj.buffer = cell(1, obj.capacity);
            obj.size = 0;
            obj.index = 1;
        end
        
        function add(obj, state, action, reward, next_state, done)
            % 添加经验到缓冲区
            %   state: 当前状态
            %   action: 采取的动作
            %   reward: 获得的奖励
            %   next_state: 下一个状态
            %   done: 是否结束
            
            experience = struct(...
                'state', state, ...
                'action', action, ...
                'reward', reward, ...
                'next_state', next_state, ...
                'done', done);
            
            obj.buffer{obj.index} = experience;
            obj.index = mod(obj.index, obj.capacity) + 1;
            
            if obj.size < obj.capacity
                obj.size = obj.size + 1;
            end
        end
        
        function batch = sample(obj, batch_size)
            % 从缓冲区采样一个小批次
            %   batch_size: 批次大小
            %   batch: 采样的经验批次
            
            if obj.size < batch_size
                batch_size = obj.size;
            end
            
            if batch_size == 0
                batch = [];
                return;
            end
            
            indices = randperm(obj.size, batch_size);
            batch = obj.buffer(indices);
        end
        
        function s = get_size(obj)
            % 获取当前缓冲区大小
            s = obj.size;
        end
        
        function clear(obj)
            % 清空缓冲区
            obj.buffer = cell(1, obj.capacity);
            obj.size = 0;
            obj.index = 1;
        end
        
        function display_info(obj)
            % 显示缓冲区信息
            fprintf('=== ReplayBuffer 信息 ===\n');
            fprintf('容量: %d\n', obj.capacity);
            fprintf('当前大小: %d\n', obj.size);
            fprintf('使用率: %.2f%%\n', obj.size / obj.capacity * 100);
        end
    end
end
