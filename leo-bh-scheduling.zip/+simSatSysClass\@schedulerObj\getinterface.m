% 2023/03/07
% 将接口类@simInterface的参数数据interface导入类@schedulerObj中
%%
function getinterface(self,interface)
    self.interface = interface;
end

