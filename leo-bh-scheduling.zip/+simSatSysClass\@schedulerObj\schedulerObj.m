% 2023/03/07
% 调度相关的Class
% 用于间接挂载包括业务生成、波位形成、波束调度、信令轮询各种某仿真空间状态下动态变化的模块
% 上述数据通过本类传输到核心类@simController中
%%
classdef schedulerObj < handle

    properties (Access = public)  
        interface
    end
    
    methods (...
            Access = public,...         % 公有方法
            Static = false...           % 非静态方法
            )% 构造函数
        function self = schedulerObj()
            
        end
        getinterface(self, interface)
        generateUsrsTraffic(self)
        generateBeamFoot(self)
        generateBHST(self, IdxOfStep, NumOfShot)
        generateSigSpan(self)

        %获取当前调度周期下的接入用户
        getCurUsers(self, sche)

        judgeEdgeUsr(self)

        adjustBHST(self)

        %波束间功率分配
        generateBeamPower(self, IdxOfStep, NumOfShot)

        % 频带、功率分配
        generateBPAllocation(self, IdxOfStep, NumOfShot)
    end
end

