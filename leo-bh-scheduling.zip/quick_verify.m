%% 快速验证脚本 - 测试代码是否能正确编译
clear; clc;

addpath(genpath('.'));

fprintf('=== 快速验证测试 ===\n\n');

%% 1. 检查配置
fprintf('[1] 检查配置文件...\n');
try
    setConfig;
    fprintf('   OK 配置加载成功\n');
    fprintf('   - enable_SA = %s\n', Config.enable_SA);
    fprintf('   - L_tabu_mode = %s\n', Config.L_tabu_mode);
    fprintf('   - fixed_L_tabu = %d\n\n', Config.fixed_L_tabu);
catch ME
    fprintf('   ERROR: %s\n\n', ME.message);
    return;
end

%% 2. 检查算法文件
fprintf('[2] 检查算法文件...\n');
files_to_check = {
    '+methods/BHST_MY.m', 'BHST_MY (原始)';
    '+methods/BHST_MY_SA.m', 'BHST_MY_SA (带SA)';
};

all_ok = true;
for i = 1:length(files_to_check)
    file = files_to_check{i};
    name = files_to_check{i};
    if exist(file, 'file')
        fprintf('   OK %s 存在\n', name);
    else
        fprintf('   ERROR %s 不存在\n', name);
        all_ok = false;
    end
end
fprintf('\n');

if ~all_ok
    fprintf('[错误] 部分文件缺失\n\n');
    return;
end

%% 3. 检查generateBHST.m
fprintf('[3] 检查generateBHST.m...\n');
genbhst_file = '+simSatSysClass/@schedulerObj/generateBHST.m';
if exist(genbhst_file, 'file')
    fprintf('   OK generateBHST.m 存在\n\n');
else
    fprintf('   ERROR generateBHST.m 不存在\n\n');
    return;
end

%% 4. 快速测试（不运行完整仿真）
fprintf('[4] 检查DataObj...\n');
if exist('DataObj.mat', 'file')
    fprintf('   OK DataObj.mat 存在\n\n');
else
    fprintf('   WARNING DataObj.mat 不存在，无法进行完整测试\n\n');
end

fprintf('=== 验证完成 ===\n');
fprintf('所有组件检查通过，代码已准备好运行。\n\n');
fprintf('注意: 完整仿真需要较长时间，请在MATLAB GUI中手动运行。\n');
fprintf('建议命令: run_ablation_SA_v3\n\n');
