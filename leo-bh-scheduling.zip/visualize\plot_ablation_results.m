function plot_ablation_results(results_file, save_to_file)
% 绘制消融实验结果对比图
% 
% 输入参数:
%   results_file  - 实验结果MAT文件路径（可选，默认最新的all_experiments_*.mat）
%   save_to_file  - 是否保存图片（可选，默认true）
%
% 输出:
%   生成并显示以下图表:
%   1. SA消融实验对比图
%   2. L_tabu消融实验对比图
%   3. 综合性能对比雷达图
%
% 作者: 2025-03-04
% 版本: 1.0

%% 参数处理
if nargin < 1 || isempty(results_file)
    % 查找最新的实验结果文件
    files = dir('results/all_experiments_*.mat');
    if isempty(files)
        error('未找到实验结果文件，请先运行实验');
    end
    [~, idx] = max([files.datenum]);
    results_file = fullfile('results', files(idx).name);
    fprintf('使用最新结果文件: %s\n', results_file);
end

if nargin < 2 || isempty(save_to_file)
    save_to_file = true;
end

%% 加载实验结果
fprintf('\n加载实验结果...\n');
load(results_file, 'all_results');

%% 检查数据完整性
if ~isfield(all_results, 'baseline') && ~isfield(all_results, 'SA_ablation') && ~isfield(all_results, 'Ltabu_ablation')
    error('结果文件格式不正确，缺少必要的数据');
end

%% 创建图形窗口
fig_main = figure('Position', [50, 50, 1400, 900], 'Color', 'w');

%% 绘图1: SA消融实验对比
if isfield(all_results, 'SA_ablation')
    subplot(2, 2, 1);
    plot_SA_ablation(all_results.SA_ablation);
    title('SA消融实验对比', 'FontSize', 14, 'FontWeight', 'bold');
end

%% 绘图2: L_tabu消融实验对比
if isfield(all_results, 'Ltabu_ablation')
    subplot(2, 2, 2);
    plot_Ltabu_ablation(all_results.Ltabu_ablation);
    title('L_{tabu}消融实验对比', 'FontSize', 14, 'FontWeight', 'bold');
end

%% 绘图3: 基线对比 - 吞吐量和满足率
if isfield(all_results, 'baseline')
    subplot(2, 2, 3);
    plot_baseline_comparison(all_results.baseline);
    title('基线算法对比', 'FontSize', 14, 'FontWeight', 'bold');
end

%% 绘图4: 综合性能雷达图
if isfield(all_results, 'baseline') && isfield(all_results, 'SA_ablation')
    subplot(2, 2, 4);
    plot_radar_chart(all_results);
    title('综合性能雷达图', 'FontSize', 14, 'FontWeight', 'bold');
end

%% 保存图片
if save_to_file
    timestamp = datestr(now, 'yyyy-mm-dd_HH-MM-SS');
    filename = sprintf('results/ablation_results_%s.png', timestamp);
    saveas(fig_main, filename);
    fprintf('\n图片已保存: %s\n', filename);
    
    % 同时保存fig格式
    filename_fig = sprintf('results/ablation_results_%s.fig', timestamp);
    saveas(fig_main, filename_fig);
    fprintf('FIG文件已保存: %s\n', filename_fig);
end

fprintf('\n消融实验结果可视化完成！\n\n');

%% ==================== 辅助绘图函数 ====================

%% 绘制SA消融实验对比
function plot_SA_ablation(SA_data)
    configs = SA_data.configs;
    KPIs = SA_data.KPIs;
    
    % 提取数据
    throughputs = zeros(1, length(KPIs));
    satisfactions = zeros(1, length(KPIs));
    
    for i = 1:length(KPIs)
        throughputs(i) = KPIs{i}.avg_throughput / 1e6;  % Mbps
        satisfactions(i) = KPIs{i}.SS_avg * 100;  %
    end
    
    % 绘制柱状图
    x = 1:length(configs);
    width = 0.35;
    
    yyaxis left;
    b1 = bar(x - width/2, throughputs, width, 'FaceColor', [0.3, 0.6, 0.9]);
    ylabel('吞吐量 (Mbps)', 'FontSize', 11);
    
    yyaxis right;
    b2 = bar(x + width/2, satisfactions, width, 'FaceColor', [0.9, 0.5, 0.3]);
    ylabel('服务满足率 (%)', 'FontSize', 11);
    
    set(gca, 'XTick', x, 'XTickLabel', configs, 'FontSize', 10);
    xlabel('配置', 'FontSize', 11);
    
    legend({'吞吐量', '服务满足率'}, 'Location', 'northwest', 'FontSize', 9);
    grid on;
    
    % 添加数值标签
    for i = 1:length(x)
        text(x(i) - width/2, throughputs(i) + max(throughputs)*0.02, ...
            sprintf('%.2f', throughputs(i)), 'HorizontalAlignment', 'center', 'FontSize', 9);
        text(x(i) + width/2, satisfactions(i) + max(satisfactions)*0.02, ...
            sprintf('%.2f%%', satisfactions(i)), 'HorizontalAlignment', 'center', 'FontSize', 9);
    end
end

%% 绘制L_tabu消融实验对比
function plot_Ltabu_ablation(Ltabu_data)
    configs = Ltabu_data.configs;
    KPIs = Ltabu_data.KPIs;
    
    % 提取数据
    labels = cell(1, length(configs));
    throughputs = zeros(1, length(KPIs));
    satisfactions = zeros(1, length(KPIs));
    
    for i = 1:length(configs)
        labels{i} = configs{i}.label;
        throughputs(i) = KPIs{i}.avg_throughput / 1e6;  % Mbps
        satisfactions(i) = KPIs{i}.SS_avg * 100;  %
    end
    
    % 绘制柱状图
    x = 1:length(configs);
    width = 0.35;
    
    yyaxis left;
    b1 = bar(x - width/2, throughputs, width, 'FaceColor', [0.4, 0.8, 0.4]);
    ylabel('吞吐量 (Mbps)', 'FontSize', 11);
    
    yyaxis right;
    b2 = bar(x + width/2, satisfactions, width, 'FaceColor', [0.8, 0.4, 0.8]);
    ylabel('服务满足率 (%)', 'FontSize', 11);
    
    set(gca, 'XTick', x, 'XTickLabel', labels, 'FontSize', 9, 'XTickLabelRotation', 45);
    xlabel('禁忌长度配置', 'FontSize', 11);
    
    legend({'吞吐量', '服务满足率'}, 'Location', 'northwest', 'FontSize', 9);
    grid on;
    
    % 添加数值标签
    for i = 1:length(x)
        text(x(i) - width/2, throughputs(i) + max(throughputs)*0.02, ...
            sprintf('%.2f', throughputs(i)), 'HorizontalAlignment', 'center', 'FontSize', 8);
        text(x(i) + width/2, satisfactions(i) + max(satisfactions)*0.02, ...
            sprintf('%.2f%%', satisfactions(i)), 'HorizontalAlignment', 'center', 'FontSize', 8);
    end
end

%% 绘制基线对比
function plot_baseline_comparison(baseline_data)
    methods = baseline_data.methods;
    KPIs = baseline_data.KPIs;
    
    % 提取数据
    throughputs = zeros(1, length(KPIs));
    satisfactions = zeros(1, length(KPIs));
    outage_rates = zeros(1, length(KPIs));
    
    for i = 1:length(KPIs)
        throughputs(i) = KPIs{i}.avg_throughput / 1e6;  % Mbps
        satisfactions(i) = KPIs{i}.SS_avg * 100;  %
        outage_rates(i) = KPIs{i}.outage_rate * 100;  %
    end
    
    % 绘制分组柱状图
    x = 1:length(methods);
    data = [throughputs; satisfactions; outage_rates]';
    
    bar(data);
    
    set(gca, 'XTick', x, 'XTickLabel', methods, 'FontSize', 10);
    xlabel('算法', 'FontSize', 11);
    ylabel('性能指标', 'FontSize', 11);
    
    legend({'吞吐量 (Mbps)', '服务满足率 (%)', '中断率 (%)'}, ...
        'Location', 'northoutside', 'FontSize', 9);
    grid on;
end

%% 绘制雷达图
function plot_radar_chart(all_results)
    % 选择关键指标
    metrics = {'吞吐量', '服务满足率', '公平性', 'SINR', '中断率(逆)'};
    num_metrics = length(metrics);
    
    % 归一化到[0, 1]
    % 这里需要根据实际数据计算
    % 简化版本：使用占位符
    
    % Tabu+SA
    if isfield(all_results, 'baseline') && isfield(all_results, 'SA_ablation')
        kpi_tabu = all_results.baseline.KPIs{1};  % 假设第一个是Tabu+SA
        kpi_sa_only = all_results.SA_ablation.KPIs{2};  % without SA
        
        % 归一化指标
        values_tabu = normalize_kpis(kpi_tabu);
        values_sa_only = normalize_kpis(kpi_sa_only);
        
        % 闭合多边形
        values_tabu = [values_tabu, values_tabu(1)];
        values_sa_only = [values_sa_only, values_sa_only(1)];
        
        % 绘制雷达图
        angles = linspace(0, 2*pi, num_metrics+1);
        
        polarplot(angles, values_tabu, 'b-o', 'LineWidth', 2, 'MarkerSize', 8);
        hold on;
        polarplot(angles, values_sa_only, 'r--s', 'LineWidth', 2, 'MarkerSize', 8);
        
        % 设置刻度
        ax = gca;
        ax.ThetaTick = rad2deg(angles(1:end-1));
        ax.ThetaTickLabel = metrics;
        ax.RLim = [0, 1];
        
        legend({'Tabu + SA', 'Tabu only'}, 'Location', 'southoutside', 'FontSize', 9);
    else
        text(0.5, 0.5, '数据不足', 'HorizontalAlignment', 'center', 'FontSize', 12);
    end
end

%% 归一化KPIs到[0, 1]
function normalized = normalize_kpis(kpi)
    % 这里使用简化的归一化方法
    % 实际应用中应该基于所有实验数据的min-max归一化
    
    normalized = [
        min(kpi.avg_throughput / 250e6, 1);  % 吞吐量，假设最大250 Mbps
        kpi.SS_avg;  % 服务满足率，已经是[0, 1]
        kpi.fairness_index;  % 公平性指数，已经是[0, 1]
        min((kpi.avg_SINR + 10) / 30, 1);  % SINR，假设范围[-10, 20] dB
        1 - kpi.outage_rate;  % 中断率（逆），越小越好
    ];
end
