function BHST_MY_SA(interface, enable_SA, L_tabu_mode, fixed_L_tabu)
% 使用禁忌搜索算法 + 模拟退火机制，以提高业务满足程度为目标
% 
% 输入参数:
%   interface      - 数据接口对象
%   enable_SA      - 是否启用SA机制 (true/false)，默认true
%   L_tabu_mode    - 禁忌长度模式 ('adaptive'/'fixed')，默认'adaptive'
%   fixed_L_tabu   - 固定禁忌长度值（仅当L_tabu_mode='fixed'时使用），默认20
%
% 输出:
%   通过interface对象返回BHST调度矩阵
%
% 作者: 基于BHST_MY.m修改，添加SA机制
% 日期: 2025-03-04
% 版本: 1.0

%% 参数默认值
if nargin < 2 || isempty(enable_SA)
    enable_SA = true;  % 默认启用SA
end

if nargin < 3 || isempty(L_tabu_mode)
    L_tabu_mode = 'adaptive';  % 默认自适应禁忌长度
end

if nargin < 4 || isempty(fixed_L_tabu)
    fixed_L_tabu = 20;  % 默认固定禁忌长度
end

%% SA参数
if enable_SA
    T_0 = 1000;       % 初始温度
    alpha = 0.95;     % 冷却率
    T_k = T_0;        % 当前温度
else
    T_0 = 0;
    alpha = 1.0;
    T_k = 0;
end

%% 获取所需参数
Radius = 6371.393e3; % 地球半径
heightOfsat = interface.height;%卫星轨道高度
AngleOf3dB = interface.AngleOf3dB;% 天线3dB张角
Rb = tools.getEarthLength(AngleOf3dB, heightOfsat)/2;% 波位半径
freq = interface.freqOfDownLink;% 下行中心频率
lambdaDown = 3e8/freq;% 波长
SCS = interface.SCS*1e3;% 子载波间隔，单位是Hz

%计算热噪声
BW = interface.BandOfLink*1e6; % 带宽，单位是Hz
T = 300;%开尔文温度，单位是k
k = 1.38e-23;%玻尔兹曼常数
N0 = k*T*BW;%噪声

%用户接收增益
type = 0;

% 关于跳波束的参数
OrderOfServSatCur = interface.OrderOfServSatCur;    % 服务卫星的列表
NumOfServSatCur = length(OrderOfServSatCur);    % 服务卫星的数量
NumOfBeam = interface.numOfServbeam; % 同时工作的波束数量
sche = interface.ScheInShot; % 调度总数
Num_scheme = interface.ScheInShot;  % 快照的调度周期数
bhLength = interface.SlotInSche; % 一次跳波束调度长度
lightTime = interface.timeInSlot;% 波束点亮时间(slot长度），单位是s

% 记录收敛曲线（用于消融实验）
convergence_trace = cell(1, 0);  % 使用cell数组存储每个时隙的收敛曲线

%% 遍历调度周期
for idx = 1 : sche
    % 当前调度用户
    numOfusrs = length(find(interface.usersInLine(idx,:) ~= 0));
    usersInThisSche = interface.usersInLine(idx,interface.usersInLine(idx,:)~=0);
    %总用户
    NumOfSelectedUsrs = interface.NumOfSelectedUsrs;
    OrderOfSelectedUsrs = interface.OrderOfSelectedUsrs;
    
    if idx == 1
        interface.tmp_UsrsTransPort = zeros(NumOfSelectedUsrs, interface.ScheInShot);%最后的时候需要更新一下
    end
    
    TransportedTraffic = zeros(interface.NumOfSelectedUsrs, 1);   % 传输的业务量列表
    %% 请求业务量统计
    requestServAll = zeros(1, NumOfSelectedUsrs);%存储所有用户请求的业务（还没有接入的用户应该还统计不到业务请求吧）
    if idx == 1
        for u = 1 : numOfusrs
            uIndex = find(OrderOfSelectedUsrs == usersInThisSche(u));
            requestServAll(uIndex) = interface.UsrsTraffic(uIndex,1) + interface.UsrsTraffic(uIndex,idx+1);
        end
    else
        for u = 1 : numOfusrs
            uIndex = find(OrderOfSelectedUsrs == usersInThisSche(u));
            requestServAll(uIndex) = interface.UsrsTraffic(uIndex,1) - interface.tmp_UsrsTransPort(uIndex,idx - 1) + interface.UsrsTraffic(uIndex,idx+1);
        end
    end
    
    
    %% 按照卫星遍历
    for satIdx = 1 : length(interface.OrderOfServSatCur)
        curSatPos = interface.SatObj(satIdx).position;
        curSatNextPos = interface.SatObj(satIdx).nextpos;
        %计算卫星总功率
        Pt_sat = interface.SatObj(satIdx).Pt_dBm_serv; % 卫星天线总的发射功率
        Pt_sat = (10.^(Pt_sat/10))/1e3; %单位是W
        
        numOfbeamfoot = interface.tmpSat(satIdx).NumOfBeamFoot(idx);%波位总数
        servOfbeamfoot = zeros(numOfbeamfoot, 1); % 星下各波位的请求业务量
        positionOfbeamfoot = zeros(numOfbeamfoot, 2); % 各波位中心的经纬度坐标
        
        %存储数据
        for bfIdx = 1 : numOfbeamfoot
            orderOfUsrs = interface.tmpSat(satIdx).beamfoot(idx, bfIdx).usrs;
            
            [~, interUsers] = intersect(interface.OrderOfSelectedUsrs, orderOfUsrs);
            servInBeam = requestServAll(interUsers);
            servOfbeamfoot(bfIdx) = sum(servInBeam);
            positionOfbeamfoot(bfIdx, :) = interface.tmpSat(satIdx).beamfoot(idx, bfIdx).position;%获得波位中心的经纬度坐标
        end
        
        %如果根本就没有波位，那就直接返回空的BHST
        if numOfbeamfoot == 0
            BHST = zeros(NumOfBeam, bhLength);
            interface.tmpSat(satIdx).BHST(:, ((idx-1)*bhLength+1):(idx*bhLength)) = BHST(:,:);           
            continue;
        end
        
        % 如果总波位数小于波束个数，那也不必使用算法了
        if numOfbeamfoot <= NumOfBeam 
            BHST = zeros(NumOfBeam, bhLength);%存储跳波束计划表
            for j = 1 : bhLength
                for jj = 1 : numOfbeamfoot
                    BHST(jj, j) = jj;
                end
            end
            interface.tmpSat(satIdx).BHST(:,((idx-1)*bhLength+1):(idx*bhLength)) = BHST(:,:);
            fprintf('第%d个卫星BHST形成\n', satIdx); 
            continue;
        end
        
        % 距离邻接矩阵，判断是否大于干扰裕度
        margin = 2 * Rb; % 相隔大于1个波位直径（和论文里一样）
        distanT = zeros(numOfbeamfoot, numOfbeamfoot);
        for i = 1 : numOfbeamfoot
            for j = 1 : i
                if i ~= j
                    deltaL = tools.LatLngCoordi2Length(positionOfbeamfoot(i, :), positionOfbeamfoot(j, :), Radius);
                    if deltaL >= margin  %如果大于隔离距离，就存这个距离，否则为0
                        distanT(i, j) = 1;
                        distanT(j, i) = 1;
                    end
                end
            end
        end
        
        % 需要使用算法
        BHST = zeros(NumOfBeam, bhLength);%存储跳波束计划表
        serv_need = servOfbeamfoot;%重新存一下需要的业务，用来做减法
        
        %% 开始禁忌搜索
        for slotIdx = 1 : bhLength%遍历每个时隙
            scheIdx = idx;
            if isempty(find(serv_need ~= 0))%如果已经都分配完了，结束
                break;
            end
            % 每一时隙都需要对业务需求量进行排序
            [B,I] = sort(serv_need,'descend');
            I(find(B==0)) = [];%防止剩余业务为负数
            NumOfBeam = min(NumOfBeam,length(I));
            lightPower = Pt_sat / NumOfBeam;
            
            % 相关参数 - 禁忌长度
            if strcmp(L_tabu_mode, 'adaptive')
                % 自适应禁忌长度: L = round(sqrt(N_b) * sqrt(N_m))
                L = round(sqrt(NumOfBeam) * sqrt(numOfbeamfoot));
            else
                % 固定禁忌长度
                L = fixed_L_tabu;
            end
            L = max(L, 5);  % 至少为5
            
            tabu = zeros(NumOfBeam); % 禁忌表
            Ca = NumOfBeam;% 候选集个数/邻域解个数
            CaNum = zeros(Ca, NumOfBeam); % 候选集集合
            
            % 初始解采用贪心生成
            x0 = judgeBeam(NumOfBeam,I,distanT);
            bestsofar = sort(x0);
            xnow = [];
            xnow(1,:) = sort(x0);
            bestsofarValue = funcFit(satIdx, scheIdx, slotIdx, bestsofar, interface, serv_need,curSatPos,curSatNextPos,heightOfsat);
            xnowValue(1,:) = funcFit(satIdx, scheIdx, slotIdx, xnow, interface, serv_need,curSatPos,curSatNextPos,heightOfsat);
            
            % 重置温度
            if enable_SA
                T_k = T_0;
            end
            
            G = 50;% 最大迭代次数
            g = 1;
            trace_this_slot = [];  % 记录当前时隙的收敛曲线
            
            %% 开始迭代
            while g < G
                % 生成Ca个邻域解
                x_near = zeros(Ca, NumOfBeam);
                for q = 1 : Ca
                    % 规则是：首先随机出一个替换个数，然后随机出这么多个数量的波束编号，随机替换
                    randN = randperm(min(numOfbeamfoot - NumOfBeam, NumOfBeam), 1);
                    % 生成需要替换的位置
                    ranpPlace = randperm(NumOfBeam, randN);
                    % 然后替换这些位置
                    randBeam = randperm(numOfbeamfoot - NumOfBeam, randN);
                    % 开始替换
                    x_near(q, :) = x0;
                    for qq = 1 : randN
                        while true
                            randBeam = randperm(numOfbeamfoot, 1);
                            if isempty(find(x_near(q,:) == randBeam))
                                x_near(q, ranpPlace(qq)) = randBeam;
                                break;
                            end
                        end
                    end
                    % 防止重复，需要排序
                    x_near(q, :) = sort(x_near(q, :));
                    fitvalue_near(q) = funcFit(satIdx, scheIdx, slotIdx, x_near(q,:), interface, serv_need,curSatPos,curSatNextPos,heightOfsat);
                end
                
                %%%%%%%%%%%%%%%%%%%%最优邻域解为候选解%%%%%%%%%%%%%%%%%%%
                temp=find(fitvalue_near==min(fitvalue_near));
                candidate(g,:)=x_near(temp(1),:);
                candidateValue(g)=fitvalue_near(temp(1));
                
                %%%%%%%%%%%%%%候选解和当前解的评价函数差%%%%%%%%%%%%%%%%%%
                delta1 = candidateValue(g) - xnowValue(g);  % 候选vs当前
                %%%%%%%%%%%%%%候选解和目前最优解的评价函数差%%%%%%%%%%%%%%%
                delta2 = candidateValue(g) - bestsofarValue; % 候选vs最优
                
                %%%%%%%%%%%%%%%%%%%%%%%%%SA接受机制%%%%%%%%%%%%%%%%%%%%%%%%
                if enable_SA
                    % 计算SA接受概率
                    if delta1 >= 0
                        % 较差解：以概率P接受
                        P_accept = exp(-delta1 / T_k);
                    else
                        % 改进解：直接接受
                        P_accept = 1.0;
                    end
                else
                    % 无SA：改进解接受，较差解拒绝
                    if delta1 < 0
                        P_accept = 1.0;
                    else
                        P_accept = 0.0;
                    end
                end
                
                %%%%%%%%%%%%%%%%%%%%%%%%%禁忌表检查%%%%%%%%%%%%%%%%%%%%%%%%
                [M,N] = size(tabu);
                is_tabu = false;
                for m = 1:M
                    if isequal(candidate(g,:), tabu(m,:))
                        is_tabu = true;
                        break;
                    end
                end
                
                %%%%%%%%%%%%%%%%%%%%%%%%%接受决策%%%%%%%%%%%%%%%%%%%%%%%%
                % 判断是否接受候选解
                % 条件1: 非禁忌
                % 条件2: 满足藐视准则 (优于历史最优)
                % 条件3: SA概率接受
                if (~is_tabu || delta2 < 0) && (rand() < P_accept)
                    % 接受候选解
                    xnow(g+1, :) = candidate(g, :);
                    xnowValue(g+1) = candidateValue(g);
                    
                    % 更新禁忌表
                    tabu = [tabu; xnow(g+1, :)];
                    if size(tabu, 1) > L
                        tabu(1,:) = [];
                    end
                    
                    % 更新历史最优解
                    if delta2 < 0
                        bestsofar = candidate(g, :);
                        bestsofarValue = candidateValue(g);
                    end
                    
                    g = g + 1;
                else
                    % 拒绝候选解，保持当前解
                    xnow(g,:) = xnow(g,:);
                    xnowValue(g,:) = funcFit(satIdx, scheIdx, slotIdx, xnow(g), interface, serv_need,curSatPos,curSatNextPos,heightOfsat);
                end
                
                %%%%%%%%%%%%%%%%%%%%%%%%%温度更新%%%%%%%%%%%%%%%%%%%%%%%%
                if enable_SA
                    T_k = alpha * T_k;
                end
                
                %%%%%%%%%%%%%%%%%%%%%%%%%记录收敛曲线%%%%%%%%%%%%%%%%%%%%%%%%
                trace_this_slot(g) = bestsofarValue;
                
                %%%%%%%%%%%%%%%%%%%%%%%%%收敛判断%%%%%%%%%%%%%%%%%%%%%%%%
                traceFoot(g, :) = bestsofar;
                if length(trace_this_slot) > 10 && g > 10 && all(traceFoot(g, :) == traceFoot(g - 10,:))
                    break;
                end
            end
            
            % 记录结果
            BHST(:,slotIdx) = bestsofar';
            
            % 记录收敛曲线（使用cell数组避免维度不匹配）
            convergence_trace{slotIdx} = trace_this_slot;
            
            % 更新业务
            for cc = 1 : NumOfBeam
                curFoot = bestsofar(cc);
                leftServ = calcuServ(satIdx, scheIdx, slotIdx, bestsofar, curFoot, interface, serv_need, curSatPos, curSatNextPos, heightOfsat);
                if length(leftServ) == 1
                    serv_need(curFoot) = leftServ;
                else
                    fprintf('aaa');
                end
            end  
            fprintf('第%d颗卫星BHST形成%f%%\n',satIdx,slotIdx * 100 /bhLength);
        end
        %% 以下为存数据
        interface.tmpSat(satIdx).BHST(:,((idx-1)*bhLength+1):(idx*bhLength)) = BHST(:,:);
        fprintf('第%d次调度第%d个卫星BHST形成\n', idx, satIdx); 
    end
end

% 注意：收敛曲线无法保存到interface（类属性限制）
% 如需分析收敛曲线，请在函数外部添加全局变量或修改simInterface类

end

%% 根据干扰规避，判断并找当前时隙波位
function curBeam = judgeBeam(maxBeam,I,distanT)
curBeam = zeros(1,maxBeam);
curBeam(1) = I(1);
II = I;%重新存一下I
II(1)=[];

count = 2;%计数
while true       
    if isempty(II)
        %如果II已经空了
        if count ~= maxBeam + 1
            %全都找过一遍了但是还是没法填满
            %那就直接把没被选的里面选满
            III = I;
            [~,ia,~]=intersect(III,curBeam);
            III(ia) = [];
            leftNum = maxBeam - (count - 1);
            if length(III) < leftNum
                curBeam(count:end) = III;
            else
                curBeam(count:end) = III(1:leftNum);
            end            
            return;
        else
            return;
        end        
    elseif count == maxBeam + 1 && ~isempty(II)
        %找完了
        return;       
    end
    curBeam(count) = II(1);
    flag=0;%是否出现干扰的标志
    for k = 1 : count - 1
        if distanT(curBeam(k),curBeam(count)) == 0%根据干扰矩阵发现二者之间存在干扰
            flag = 1;            
            break;
        end
    end
    if flag == 1
        II(1)=[];
        curBeam(count) = 0;
    else
        II(1)=[];
        count = count + 1;
    end
end

end


%% 计算某个波位的剩余业务量
function leftServ = calcuServ(SatIdx, ScheIdx, slotIdx, lightFoot, curFoot, interface, serv_need, curSatPos, curSatNextPos, heightOfsat)
NumOfLightBeamfoot = length(lightFoot);
Pt_sat = interface.SatObj(SatIdx).Pt_dBm_serv; % 卫星天线总的发射功率
Pt_sat = (10.^(Pt_sat/10))/1e3; %单位是W
lightPower = Pt_sat / NumOfLightBeamfoot;
Band = interface.BandOfLink * 1e6;%Hz
freqOfDownLink = interface.freqOfDownLink; % (Hz) 卫星的下行链路中心频点
startOfBand = freqOfDownLink - Band / 2;
lightTime = interface.timeInSlot;% 波束点亮时间(slot长度），单位是s

% 计算所有指向
PosOfBeam = zeros(NumOfLightBeamfoot, 2);    % 点亮波位中心三角形坐标 
for bidx = 1 : NumOfLightBeamfoot
    PosOfBeam(bidx, :) = interface.tmpSat(SatIdx).beamfoot(ScheIdx, lightFoot(bidx)).position; 
end

BeamPoint = zeros(NumOfLightBeamfoot, 2); % varphi(俯仰，偏离x轴),vartheta(方向，偏离xOy平面),天线在zOy平面(右手系)
for j = 1 : NumOfLightBeamfoot
    [outputTheta, outputPhi] = tools.getPointAngleOfUsr(...
        curSatPos, curSatNextPos, PosOfBeam(j, :), heightOfsat);
    BeamPoint(j,1) = outputPhi;
    BeamPoint(j,2) = outputTheta;
end

% 获得当前波位的用户
orderOfUsrs = interface.tmpSat(SatIdx).beamfoot(ScheIdx, curFoot).usrs;
% 然后计算这些波位的h
curSINR = 0;
subBandWidth = Band / length(orderOfUsrs);
for usrIdx = 1 : length(orderOfUsrs)
    curUser = orderOfUsrs(usrIdx);

    tmpBand = [startOfBand + (usrIdx - 1) * subBandWidth, startOfBand + usrIdx * subBandWidth];

    thisSINR = CaculateSINR(SatIdx, ScheIdx, slotIdx, curUser, curFoot, lightFoot, lightPower, BeamPoint, tmpBand, interface);

    curSINR = curSINR + thisSINR;            
end
SINRofBF = curSINR / length(orderOfUsrs);

% 计算这些波位传输了多少
given = Band * log2(1+SINRofBF)*lightTime;
footIdx = find(lightFoot == curFoot);
leftServ = serv_need(footIdx) - given;

end

%% 计算适配值
function fitValue = funcFit(SatIdx, ScheIdx, slotIdx, lightFoot, interface, serv_need, curSatPos, curSatNextPos, heightOfsat)
NumOfLightBeamfoot = length(lightFoot);
SINRofBF = zeros(1, NumOfLightBeamfoot);
Pt_sat = interface.SatObj(SatIdx).Pt_dBm_serv; % 卫星天线总的发射功率
Pt_sat = (10.^(Pt_sat/10))/1e3; %单位是W
lightPower = Pt_sat / NumOfLightBeamfoot;
Band = interface.BandOfLink * 1e6;%Hz
freqOfDownLink = interface.freqOfDownLink; % (Hz) 卫星的下行链路中心频点
startOfBand = freqOfDownLink - Band / 2;
lightTime = interface.timeInSlot;% 波束点亮时间(slot长度），单位是s

% 计算所有指向
PosOfBeam = zeros(NumOfLightBeamfoot, 2);    % 点亮波位中心三角形坐标 
for bidx = 1 : NumOfLightBeamfoot
    PosOfBeam(bidx, :) = interface.tmpSat(SatIdx).beamfoot(ScheIdx, lightFoot(bidx)).position; 
end

BeamPoint = zeros(NumOfLightBeamfoot, 2); % varphi(俯仰，偏离x轴),vartheta(方向，偏离xOy平面),天线在zOy平面(右手系)
for j = 1 : NumOfLightBeamfoot
    [outputTheta, outputPhi] = tools.getPointAngleOfUsr(...
        curSatPos, curSatNextPos, PosOfBeam(j, :), heightOfsat);
    BeamPoint(j,1) = outputPhi;
    BeamPoint(j,2) = outputTheta;
end

% 计算所有波位的SINR
for footIdx = 1 : NumOfLightBeamfoot
    curFoot = lightFoot(footIdx);
    % 获得当前波位的用户
    orderOfUsrs = interface.tmpSat(SatIdx).beamfoot(ScheIdx, curFoot).usrs;
    % 然后计算这些波位的h
    curSINR = 0;
    subBandWidth = Band / length(orderOfUsrs);
    for usrIdx = 1 : length(orderOfUsrs)
        curUser = orderOfUsrs(usrIdx);
    
        tmpBand = [startOfBand + (usrIdx - 1) * subBandWidth, startOfBand + usrIdx * subBandWidth];
    
        thisSINR = CaculateSINR(SatIdx, ScheIdx, slotIdx, curUser, curFoot, lightFoot, lightPower, BeamPoint, tmpBand, interface);
    
        curSINR = curSINR + thisSINR;            
    end
    SINRofBF(footIdx) = curSINR / length(orderOfUsrs);
end

% 计算这些波位传输了多少
serv_left = serv_need;
for footIdx = 1 : NumOfLightBeamfoot
    curFoot = lightFoot(footIdx);
    given = Band * log2(1+SINRofBF(footIdx))*lightTime;
    serv_left(curFoot) = serv_left(curFoot) - given;
end

fitValue = sum(serv_left);

end

%% 计算某个用户的SINR值
function SINR = CaculateSINR(SatIdx, ScheIdx, slotIdx, userIdx, curFoot, lightFoot, lightPower, BeamPoint, thisBand, interface)
Usrs = interface.tmpSat(SatIdx).beamfoot(ScheIdx, curFoot).usrs;% 波位里的用户
footIdx = find(lightFoot == curFoot);% 当前波位在所有波位的编号
Pt = 1 / length(Usrs) * lightPower;   % 每个用户分到的功率
Band = interface.BandOfLink * 1e6;% Hz

Bandwidth = Band / length(Usrs);
freqOfDownLink = interface.freqOfDownLink; % (Hz) 卫星的下行链路中心频点
startOfBand = freqOfDownLink - Band / 2;
userIdxInBeam = find(Usrs == userIdx);  
thisBand = [startOfBand + (userIdxInBeam - 1) * Bandwidth, startOfBand + userIdxInBeam * Bandwidth];
fc = mean(thisBand);

% 计算当前用户的指向角 
userCurPos = interface.UsrsObj(userIdx).position; % 当前用户坐标    
satCurPos = interface.SatObj(SatIdx).position; % 当前卫星星下点坐标
satCurnextPos = interface.SatObj(SatIdx).nextpos; % 当前卫星星下点下一step坐标
[userTheta, userPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, userCurPos, interface.height);%计算方位角和仰角
% 计算用户接收增益
G_usrDown = antenna.getUsrAntennaServG(0, fc, false);
% 计算当前卫星到当前用户的距离
usrCurPos = interface.UsrsObj(userIdx).position;
usrPosInDescartes = LngLat2Descartes(usrCurPos, 0);
satPosInDescartes = LngLat2Descartes(satCurPos, interface.height);
distance = sqrt((satPosInDescartes(1)-usrPosInDescartes(1)).^2 + ...
                (satPosInDescartes(2)-usrPosInDescartes(2)).^2 + ...
                (satPosInDescartes(3)-usrPosInDescartes(3)).^2);  
InterfInSatDown = 0;

%遍历干扰波位，是按照是否已经分配的顺序来的，计算干扰
for bfIdx = 1 : length(lightFoot)
    OrderOfbeam = lightFoot(bfIdx);% 波位的实际编号
    if OrderOfbeam == curFoot % 跳过当前波位
        continue;
    else
        %干扰波位里的用户的编号
        interfUsrs = interface.tmpSat(SatIdx).beamfoot(ScheIdx, OrderOfbeam).usrs;
        % 干扰波位被分配到的功率
        interfBeamPower = lightPower;
        poiBeta = BeamPoint(bfIdx,1);
        poiAlpha = BeamPoint(bfIdx,2);
        AgleOfInv = [userTheta, userPhi];
        AgleOfPoi = [poiAlpha, poiBeta];

        subBandWidth = Band / length(interfUsrs);
        for interfUsrIdx = 1 : length(interfUsrs) % 遍历该波位里用户的干扰
            % 获得这个干扰用户的功率、频带
            thisInterfUser = interfUsrs(interfUsrIdx);
            thisInterfUser_power = 1 / length(interfUsrs)  * interfBeamPower;
            thisInterfUser_band = [startOfBand + (interfUsrIdx - 1) * subBandWidth, startOfBand + interfUsrIdx * subBandWidth];

            % 判断是否有频段重合
            overlap = range_intersection(thisBand, thisInterfUser_band);% 注意检查f的单位是不是Hz
            if length(overlap) == 2
                lambdaDown = 3e8/mean(overlap);
                G_sat_interfDown = antenna.getSatAntennaServG(AgleOfInv, AgleOfPoi, mean(overlap));
                InterfInSatDown = InterfInSatDown + ...
                    thisInterfUser_power * G_sat_interfDown * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
            end

        end
    end

end
%%%%%%%%%%%%%%%%%%%%%
bfIdx = find(lightFoot == curFoot);
poiBeta = BeamPoint(bfIdx,1);
poiAlpha = BeamPoint(bfIdx,2);
AgleOfInv = [userTheta, userPhi];
AgleOfPoi = [poiAlpha, poiBeta];
lambda_c = 3e8/fc;

G_sat_down = antenna.getSatAntennaServG(AgleOfInv, AgleOfPoi, fc);
%%%%%%%%%%%%%%%%%%%%%
Carrier_down = Pt * G_sat_down * G_usrDown * (lambda_c.^2) / (((4*pi).^2)*(distance.^2));
SINR = Carrier_down./(InterfInSatDown + 1.380649e-23 * 300 * Bandwidth);

end

%% 
function PosInDescartes = LngLat2Descartes(CurPos, h)
    tmpPhi = CurPos(1) * pi / 180;
    if tmpPhi < 0
        tmpPhi = tmpPhi + 2*pi;
    end
    tmpTheta = (90 - CurPos(2)) * pi / 180;
    R = 6371.393e3; % 地球半径
    tmpX = (R+h) * sin(tmpTheta) * cos(tmpPhi);
    tmpY = (R+h) * sin(tmpTheta) * sin(tmpPhi);
    tmpZ = (R+h) * cos(tmpTheta); 
    PosInDescartes = [tmpX, tmpY, tmpZ];    
end

%% 求交集
function [ Overlap ] = range_intersection( A,B )
Lower_A = min(A); 
Upper_A = max(A); 

Lower_B = min(B); 
Upper_B = max(B); 

if (Lower_A > Lower_B || Lower_A == Lower_B)
    Lower_Lim = Lower_A;    
else
    Lower_Lim = Lower_B; 
end

if (Upper_A > Upper_B || Upper_A == Upper_B)
    Upper_Lim = Upper_B;    
else
    Upper_Lim = Upper_A; 
end

input_vector = union(A,B); 

Overlap = input_vector(intersect(find(input_vector>=Lower_Lim),find(input_vector<=Upper_Lim)));

end
