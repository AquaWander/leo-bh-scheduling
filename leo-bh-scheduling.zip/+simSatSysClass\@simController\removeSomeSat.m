function removeSomeSat(self, IdxOfStep, MC_idx)
%把更外围的卫星对象清除，还有邻接关系、可见性这些也给改掉

%% 先找到原本考察区域里的那些服务卫星
%首先获得考察区域在wrap里的起止行列号
    [row1,colu1,~] = tools.findPointXY(self,max(self.Config.rangeOfInves(2,:)),self.Config.rangeOfInves(1,1));%找到考察区域左上角第一个三角形的行号列号
    [~,colu2,~] = tools.findPointXY(self,max(self.Config.rangeOfInves(2,:)),self.Config.rangeOfInves(1,2));%找到考察区域右上角的列号
    [row2,~,~] = tools.findPointXY(self,min(self.Config.rangeOfInves(2,:)),self.Config.rangeOfInves(1,1));%找到考察区域最下面一行的行号

%然后对这些行列号里的三角形做一次最短距离判断，找到服务卫星
%以下获得考察区域的服务卫星

    ifDebug = self.ifDebug;

    OrderOfServSatCur = self.OrderOfServSatCur;    % 当前step里整个wrap提供服务的卫星编号
    NumOfOfServSatCur = length(OrderOfServSatCur);    % 当前step里整个wrap提供服务的卫星数量

    orderOfActualSat_1_0 = zeros(1,NumOfOfServSatCur);% 存储考察区域里实际服务卫星，如果可见，置为1
    orderOfActualSat = zeros();%% 存储考察区域里实际服务卫星，存了编号 

    % 生成VisibleSat_s，前两列是可见卫星的经纬度，第三列是其编号
    tempVisibleSat_s = zeros(NumOfOfServSatCur,3);    
    tempVisibleSat_s(:,1:2) = self.VisibleSat(OrderOfServSatCur, IdxOfStep, :);
    tempVisibleSat_s(:,3) = OrderOfServSatCur;

    tempSeqDiscrArea = self.SeqDiscrArea;%离散小三角形的中心点坐标
   
    [rawNum, colNum, ~] = size(self.DiscrArea);%离散三角形的行列数
    hOfDiscr = tools.LatLngCoordi2Length([0 0], [0 1], self.rOfearth)/self.Config.factorOfDiscr;%每个三角形的高度
    interval = ceil(tools.getEarthLength(self.Config.rangeOfBeam(2)*2, self.Config.height)/hOfDiscr/8);%考察间隔

    for i = row1 : row2%遍历行
        last_q = 0;%如果q == last_q说明没找到？
        for j = colu1 : interval : colu2%间隔遍历列
            seq = simSatSysClass.tools.ij2Seq(i, j, rawNum, colNum);%计算当前ij在离散三角形中的编号
            q = findShortest(...
                tempSeqDiscrArea(seq, :),...
                tempVisibleSat_s(:, 1:2)...
                );%找到最近的卫星
            orderOfActualSat_1_0(q) = 1;
            if j ~= colu1%补充计算？
                if q ~= last_q
                    for k = j-interval+1 : j
                        seq = simSatSysClass.tools.ij2Seq(i, k, rawNum, colNum);
                        q = findShortest(...
                            tempSeqDiscrArea(seq, :),...
                            tempVisibleSat_s(:, 1:2)...
                            );%这个q的编号是在可见卫星矩阵里的号，所以要用第三列去获得他在1800里的编号
                        orderOfActualSat_1_0(q) = 1;                        
                    end
                    last_q = q;                   
                end              
            else                              
                last_q = q;
            end
%             if ifDebug == 1
%                 if self.Config.numOfMonteCarlo == 0
%                     fprintf('第%d快照核心考察区域可见卫星判断%f%%\n', IdxOfStep, ((i-1)*colNum+j)*100/(rawNum*colNum));                  
%                 else
%                     fprintf('蒙特卡洛第%d次第%d快照核心考察区域可见卫星判断%f%%\n', MC_idx, IdxOfStep, ((i-1)*colNum+j)*100/(rawNum*colNum));                  
%                 end
%             end
            if colNum - j < interval
                for k = j+1 : colNum
                    seq = simSatSysClass.tools.ij2Seq(i, k, rawNum, colNum);
                    q = findShortest(...
                        tempSeqDiscrArea(seq, :),...
                        tempVisibleSat_s(:, 1:2)...
                        );                
                    orderOfActualSat_1_0(q) = 1;
                    
                end
%                 if ifDebug == 1
%                     if self.Config.numOfMonteCarlo == 0
%                         fprintf('第%d快照核心考察区域可见卫星判断%f%%\n', IdxOfStep, ((i-1)*colNum+colNum)*100/(rawNum*colNum));
%                     else
%                         fprintf('蒙特卡洛第%d次第%d快照核心考察区域可见卫星判断%f%%\n', MC_idx, IdxOfStep, ((i-1)*colNum+colNum)*100/(rawNum*colNum));
%                     end
%                 end
            end
        end 
    end

    for i = 1 : NumOfOfServSatCur
        if orderOfActualSat_1_0(i) ~= 0
            orderOfActualSat(i) = OrderOfServSatCur(i);
        end
    end
    

    % 删除卫星
    if self.Config.WrapAroundLayer == 0
        
        tempDel = find(orderOfActualSat~=0);%考察区域服务卫星
        orderOfActualSat(orderOfActualSat==0) = [];%这就是考察区域的卫星编号
        
        count = 1;%计数
        for i = 1 : length(tempDel)
            self.SatObj(count) = self.SatObj(tempDel(count));
            count = count + 1;
        end
        for i = length(tempDel)+1 : NumOfOfServSatCur
            self.SatObj(length(tempDel)+1) = [];
        end
        
        self.OrderOfServSatCur = orderOfActualSat;
    %     self.NumOfOfServSatCur = length(orderOfActualSat);
        
        %还要从相邻关系中把其他的卫星删掉
        tmpLenNeib = length(self.SatObj(1).Neighbor(:,1));
        for k = 1 : tmpLenNeib
            for i = 1 : length(orderOfActualSat)%遍历所有的星
                temp= zeros(1,length(orderOfActualSat));
                count = 0;
                for j = 1 : length(self.SatObj(i).Neighbor(k,:))%遍历该星所有的邻居                                
                    if self.SatObj(i).Neighbor(k,j) ~= 0 && ismember(self.SatObj(i).Neighbor(k,j),orderOfActualSat)
                        count = count + 1;
                        temp(count) = self.SatObj(i).Neighbor(k,j);                    
                    end
                end
                temp2 = zeros(1, length(self.SatObj(i).Neighbor(k,:)));
                temp2(1:length(temp)) = temp;
                self.SatObj(i).Neighbor(k,:) = temp2;
%                 if ifDebug == 1
%                     if self.Config.numOfMonteCarlo == 0
%                         fprintf('第%d快照更新邻居卫星关系%f%%\n', IdxOfStep, ((k-1)*length(orderOfActualSat)+i)*100/(tmpLenNeib*length(orderOfActualSat)));
%                     else
%                         fprintf('蒙特卡洛第%d次第%d快照更新邻居卫星关系%f%%\n', MC_idx, IdxOfStep, ((k-1)*length(orderOfActualSat)+i)*100/(tmpLenNeib*length(orderOfActualSat)));
%                     end
%                 end                
            end
        end
        
    elseif self.Config.WrapAroundLayer == 1
        
        TempOrderOfActual = orderOfActualSat;
        TempOrderOfActual(TempOrderOfActual == 0) =[];
        
        %获得和考察区域可见卫星相邻的一层卫星，这两部分合计为总的卫星
        for i = 1 : NumOfOfServSatCur
            if ismember(self.SatObj(i).order,TempOrderOfActual)
                temp = self.SatObj(i).Neighbor;%相邻的卫星
                for j = 1 : length(self.SatObj(i).Neighbor)
                    if ~ismember(temp(j),orderOfActualSat)
                        orderOfActualSat(find(OrderOfServSatCur==temp(j))) = temp(j);
                    end
                end            
            end
        end
        
        tempDel = find(orderOfActualSat~=0);%考察区域服务卫星
        orderOfActualSat(orderOfActualSat==0) = [];%这就是考察区域+相邻的卫星编号
        
        count = 1;%计数
        for i = 1 : length(tempDel)
            self.SatObj(count) = self.SatObj(tempDel(count));
            count = count + 1;
        end
        for i = length(tempDel)+1 : NumOfOfServSatCur
            self.SatObj(length(tempDel)+1) = [];
        end
        
        self.OrderOfServSatCur = orderOfActualSat;
    %     self.NumOfOfServSatCur = length(orderOfActualSat);
        
        %还要从相邻关系中把其他的卫星删掉
        tmpLenNeib = length(self.SatObj(1).Neighbor(:,1));
        for k = 1 : tmpLenNeib
            for i = 1 : length(orderOfActualSat)%遍历所有的星
                temp= zeros(1,length(orderOfActualSat));
                count = 0;
                for j = 1 : length(self.SatObj(i).Neighbor(k,:))%遍历该星所有的邻居                                
                    if self.SatObj(i).Neighbor(k,j) ~= 0 && ismember(self.SatObj(i).Neighbor(k,j),orderOfActualSat)
                        count = count + 1;
                        temp(count) = self.SatObj(i).Neighbor(k,j);                    
                    end
                end
                temp2 = zeros(1, length(self.SatObj(i).Neighbor(k,:)));
                temp2(1:length(temp)) = temp;
                self.SatObj(i).Neighbor(k,:) = temp2;
%                 if ifDebug == 1
%                     if self.Config.numOfMonteCarlo == 0
%                         fprintf('第%d快照更新邻居卫星关系%f%%\n', IdxOfStep, ((k-1)*length(orderOfActualSat)+i)*100/(tmpLenNeib*length(orderOfActualSat)));
%                     else
%                         fprintf('蒙特卡洛第%d次第%d快照更新邻居卫星关系%f%%\n', MC_idx, IdxOfStep, ((k-1)*length(orderOfActualSat)+i)*100/(tmpLenNeib*length(orderOfActualSat)));
%                     end
%                 end 
            end
        end
    end


end

%% 找到距离最近的点
function Satpos = findShortest(pos, SatposSet)
% pos 考察坐标
% SatposSet 卫星坐标集合
    R = 6371.393e3; % 地球半径

    lngA = pos(1);
    alpha1 = lngA * pi / 180;
    latA = pos(2);
    beta1 = latA * pi / 180;

    num = length(SatposSet(:,1));
    len = zeros(num,1);%可见卫星个数
    for i = 1 : num
        lngB = SatposSet(i, 1);
        alpha2 = lngB * pi / 180;
        latB = SatposSet(i, 2);
        beta2 = latB * pi / 180;
        len(i) = R * acos(cos(pi/2-beta2)*cos(pi/2-beta1) + sin(pi/2-beta2)*sin(pi/2-beta1)*cos(alpha2-alpha1));
    end
    Satpos = find(len == min(len), 1);
end