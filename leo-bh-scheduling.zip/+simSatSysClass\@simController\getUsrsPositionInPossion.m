% 2023/03/16
% 生成空间泊松点过程（SPPP）撒点时的用户位置
% 分为warpAround和非wrap来生成
% 输出self.UsrsPosition
%%
% self.UsrsPosition
% 矩阵，格式为"全部用户数量×3"
% 如果是wrapAround，矩阵的前self.numOfUsrs_inves行是考察区域内的用户，一共有self.numOfUsrs_all行
% 如果非wrapAround，矩阵一共有self.numOfUsrs_inves行
% UsrsPosition(k, 1)表示k号用户的经度
% UsrsPosition(k, 2)表示k号用户的纬度
% UsrsPosition(k, 3)表示k号用户在SeqDiscrArea中的编号
%%
function getUsrsPositionInPossion(self)
%% 在球面上撒点获得xyz坐标
r = self.rOfearth; %地球半径，单位是m

%泊松过程参数
HeightOfArea = tools.LatLngCoordi2Length( ...
    [0, self.Config.rangeOfInves(2,1)], ...
    [0, self.Config.rangeOfInves(2,2)], ...
    self.rOfearth);
LengthOfArea = self.rOfearth * ...
    cos(self.Config.rangeOfInves(2,2)*pi/180) * ...
    abs(self.Config.rangeOfInves(1,1)-self.Config.rangeOfInves(1,2))*pi/180;
AreaOfInves = HeightOfArea * LengthOfArea;
DensOfUsrs = self.Config.Uniform_NumOfUsrs/AreaOfInves;  % 用户密度即泊松点过程的lambda

possionCofig = 4*pi*self.rOfearth*self.rOfearth*DensOfUsrs; % 泊松点过程的参数为lambda*Area

%以下开始仿真泊松过程，采用的方法是直接xyz
numbPoints=poissrnd(possionCofig);%撒点总数，即获得泊松点过程的全球用户数量

xxRand=normrnd(0,1,numbPoints,3);
normRand=vecnorm(xxRand,2,2); %Euclidean norms (across each row)
xxRandBall=xxRand./normRand; %rescale by Euclidean norms
xxRandBall=r*xxRandBall; %rescale for non-unit sphere

%获得xyz坐标
xx=xxRandBall(:,1);
yy=xxRandBall(:,2);
zz=xxRandBall(:,3);
% markerSize=200;
% scatter3(xx,yy,zz,markerSize,'b.');
% axis square;
% hold on;

% 将xyz坐标转换为经纬度，因为直接是球面撒点，所以不需要H，只需要B和L
%没有用到WGS84坐标系的参数，直接当球体考虑的，这样会有问题吗？

%% 将xyz坐标转化为大地坐标系
longitude = atan2(yy,xx)*180/pi;
latitude = atan2(zz,sqrt(xx .^ 2 + yy .^ 2))*180/pi;

% worldmap('World');
% plotm(latitude,longitude,'.','Color',[0 0 1]);

%% 从这些点里面获得考察区域/框里面的用户点
%e.g.RangeOfInvesArea =[115, 125;32, 42];  第一行是经度，第二行是纬度
if self.Config.ifWrapAround == 1 % 如果启用wrapAround
    minLat = min(self.wrapRange(2,:));
    maxLat = max(self.wrapRange(2,:));
%     关于lon的判断有输入顺序的问题，应该没法直接用大于小于去比较
%     minLon = min(min(self.wrapRange(1,:)),self.DiscrArea(end,1,1));
%     maxLon = max(max(self.wrapRange(1,:)),self.DiscrArea(end,end,1));
    rawNum = length(self.DiscrArea(:,1,1));
else
    minLat = min(self.Config.rangeOfInves(2,:));
    maxLat = max(self.Config.rangeOfInves(2,:));
%     minLon = min(min(self.SimConfig.rangeOfinves(1,:)),self.DiscrArea(end,1,1));
%     maxLon = max(max(self.SimConfig.rangeOfinves(1,:)),self.DiscrArea(end,end,1));
    rawNum = length(self.DiscrArea(:,1,1));
end

count = 1;%给考察区域里的用户计数
user = zeros();

%% 存储经纬度坐标和所属三角形编号
for i = 1 : numbPoints
%     if latitude(i) >= minLat && latitude(i) <= maxLat && longitude(i) >= minLon && longitude(i) <= maxLon
    if latitude(i) >= minLat && latitude(i) <= maxLat    
        [ii,jj,~] = tools.findPointXY(self,latitude(i),longitude(i));
        if ii >0 && jj > 0 && jj <= length(self.DiscrArea(1,:,1))
%             user(count,1:2) = [longitude(i),latitude(i)];
            user(count) = (jj - 1) * rawNum + ii;
            count = count + 1;
        end
    end
end
self.numOfUsrs_all = length(user);
user = user(randperm(self.numOfUsrs_all));
% for ui = 1 : length(user(:,1))
%     self.Usrs(ui).position = user(ui,1:2);%这里获得的用户是整个框里的用户(if wrap的话）
%     self.Usrs(ui).OrdOfDiscr = user(ui,3);
% end
self.UsrsPosition = zeros(self.numOfUsrs_all, 3);
%% 识别出Inves区域的用户，并将其存储在UsrsPosition的前部分
if self.Config.ifWrapAround == 1 % 如果启用wrapAround
    [~, tmpS1, tmpS2] = intersect(user,self.SeqDiscrInNonWrap);    % 找到考察区域内的用户
    tmpUsrsTriOrder = self.SeqDiscrInNonWrap(sort(tmpS2));
    self.numOfUsrs_inves = length(tmpUsrsTriOrder);
    self.InvesUsrsPosition = zeros(self.numOfUsrs_inves, 3);
    user(tmpS1) = []; % 在全部用户里删除核心区域用户
    for k = 1 : self.numOfUsrs_all
        if k <= self.numOfUsrs_inves
            self.UsrsPosition(k, 3) = tmpUsrsTriOrder(k); % 该用户的小三角形在全wrap区域的编号
            self.UsrsPosition(k, 1:2) = self.SeqDiscrArea(self.UsrsPosition(k, 3), :);
            self.InvesUsrsPosition(k, 3) = tmpUsrsTriOrder(k);
            self.InvesUsrsPosition(k, 1:2) = self.SeqDiscrArea(self.InvesUsrsPosition(k, 3), :);
        else
            self.UsrsPosition(k, 3) = user(k-self.numOfUsrs_inves);
            self.UsrsPosition(k, 1:2) = self.SeqDiscrArea(self.UsrsPosition(k, 3), :);
        end
    end
else
    self.numOfUsrs_inves = self.numOfUsrs_all;
    self.InvesUsrsPosition = zeros(self.numOfUsrs_inves, 3);
    for k = 1 : self.numOfUsrs_all
        self.UsrsPosition(k, 3) = user(k);
        self.UsrsPosition(k, 1:2) = self.SeqDiscrArea(self.UsrsPosition(k, 3), :);
        self.InvesUsrsPosition(k, 3) = user(k);
        self.InvesUsrsPosition(k, 1:2) = self.SeqDiscrArea(self.InvesUsrsPosition(k, 3), :);
    end
end

end

