%% 快速测试脚本 - 仅运行1次迭代验证代码正确性
clear; clc;

addpath(genpath('.'));

fprintf('========================================\n');
fprintf('   快速测试 - 验证代码正确性\n');
fprintf('========================================\n\n');

%% 加载配置
fprintf('[1] 加载配置...\n');
setConfig;
Config.enable_SA = true;
Config.L_tabu_mode = 'adaptive';
fprintf('   OK\n\n');

%% 运行1次快速测试
fprintf('[2] 运行快速测试（仅1次调度周期）...\n');
tic;

try
    controller = simSatSysClass.simController(Config, 1, 1, 0);
    
    % 限制调度周期数为1以加快测试
    controller.scheInShot = 1;
    
    DataObj = controller.run();
    
    elapsed_time = toc;
    
    fprintf('\n   OK 测试完成！\n');
    fprintf('   耗时: %.2f 秒\n\n', elapsed_time);
    
    % 检查结果
    if isfield(DataObj, 'InterfFromAll_Down')
        sinr_data = squeeze(DataObj.InterfFromAll_Down(:, :, :, 2));
        avg_sinr = mean(sinr_data(:), 'omitnan');
        fprintf('   平均SINR: %.2f dB\n', avg_sinr);
    end
    
    fprintf('\n========================================\n');
    fprintf('   快速测试通过！代码正确。\n');
    fprintf('========================================\n\n');
    
catch ME
    fprintf('\n   ERROR: %s\n', ME.message);
    fprintf('   错误位置: %s (第%d行)\n', ME.stack(1).name, ME.stack(1).line);
    fprintf('\n========================================\n');
    fprintf('   测试失败！需要调试。\n');
    fprintf('========================================\n\n');
end
