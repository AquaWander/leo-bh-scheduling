function traffic = generateTraffic(num_users, total_demand, mode, params)
% 生成不同分布模式的流量需求
% 
% 输入参数:
%   num_users    - 用户数量
%   total_demand - 总需求量
%   mode         - 分布模式: 'uniform', 'light_skew', 'heavy_skew', 'pareto'
%   params       - 参数结构体:
%                  .skew_factor - 偏斜因子（用于light/heavy skew）
%                  .alpha       - Pareto分布参数
%
% 输出:
%   traffic - 流量需求向量 [num_users × 1]
%
% 作者: 2025-03-04

%% 默认参数
if nargin < 4 || isempty(params)
    params = struct();
end

if ~isfield(params, 'skew_factor')
    params.skew_factor = 2;
end

if ~isfield(params, 'alpha')
    params.alpha = 1.5;
end

%% 根据模式生成流量
switch lower(mode)
    case 'uniform'
        % 均匀分布：所有用户需求相同
        traffic = (total_demand / num_users) * ones(num_users, 1);
        
    case 'light_skew'
        % 轻度偏斜：使用对数正态分布
        skew = params.skew_factor;
        mu = log(total_demand / num_users) - 0.5 * log(1 + skew^2);
        sigma = sqrt(log(1 + skew^2));
        traffic = lognrnd(mu, sigma, num_users, 1);
        % 归一化到总需求
        traffic = traffic * (total_demand / sum(traffic));
        
    case 'heavy_skew'
        % 重度偏斜：使用更偏斜的对数正态分布
        skew = params.skew_factor;
        mu = log(total_demand / num_users) - 0.5 * log(1 + skew^2);
        sigma = sqrt(log(1 + skew^2)) * 1.5;  % 增加方差
        traffic = lognrnd(mu, sigma, num_users, 1);
        % 归一化到总需求
        traffic = traffic * (total_demand / sum(traffic));
        
    case 'pareto'
        % Pareto分布（80/20规则）
        alpha = params.alpha;
        xm = total_demand / num_users * (alpha - 1) / alpha;  % 尺度参数
        traffic = (rand(num_users, 1) .^ (-1/alpha) - 1) * xm;
        % 归一化到总需求
        traffic = traffic * (total_demand / sum(traffic));
        
    otherwise
        warning('未知的流量模式: %s，使用均匀分布', mode);
        traffic = (total_demand / num_users) * ones(num_users, 1);
end

%% 确保所有流量值为正
traffic = max(traffic, eps);

%% 打印统计信息
fprintf('流量生成 [%s模式]:\n', upper(mode));
fprintf('  - 用户数: %d\n', num_users);
fprintf('  - 总需求: %.2f Mbps\n', total_demand/1e6);
fprintf('  - 平均需求: %.2f Mbps\n', mean(traffic)/1e6);
fprintf('  - 最小需求: %.2f Mbps\n', min(traffic)/1e6);
fprintf('  - 最大需求: %.2f Mbps\n', max(traffic)/1e6);
fprintf('  - 标准差: %.2f Mbps\n', std(traffic)/1e6);
fprintf('  - 变异系数: %.2f\n', std(traffic)/mean(traffic));

% 对于Pareto分布，检查80/20规则
if strcmpi(mode, 'pareto')
    sorted_traffic = sort(traffic, 'descend');
    top20_sum = sum(sorted_traffic(1:round(num_users*0.2)));
    total_sum = sum(sorted_traffic);
    ratio_80_20 = top20_sum / total_sum;
    fprintf('  - 80/20比例: %.2f%% (前20%%用户占总需求的%.2f%%)\n', ...
        ratio_80_20*100, ratio_80_20*100);
end
fprintf('\n');

end
