% 不进行波位划分，波位=用户
% （仅作测试用）
function BeamFoot_Method0(interface)
% tmpSat  % 结构体数组，长度为length(OrderOfServSatCur)
%                 % 属性
%                      % NumOfBeamFoot，向量，长度为ScheInShot，储存每一调度时的波位形成数量
%                      % beamfoot，结构体矩阵，格式为" ScheInShot × 所有调度周期里形成的最大波位数"
%                      %         属性position，矩阵，储存当前调度该波位中心经纬坐标
%                      %         属性usrs，向量，储存当前调度该波位服务用户的用户索引

    for satIdx = 1 : length(interface.OrderOfServSatCur)
%         interface.tmpSat(satIdx).NumOfBeamFoot = ...
%             ones(interface.ScheInShot, 1).*interface.SatObj(satIdx).numOfusrs;
        for sche = 1 : interface.ScheInShot
            interface.tmpSat(satIdx).NumOfBeamFoot(sche) = interface.SatObj(satIdx).numOfusrs(sche);
            for bfIdx = 1 : interface.tmpSat(satIdx).NumOfBeamFoot(sche)
%                 interface.tmpSat(satIdx).beamfoot(ScheIdx, bfIdx).position = ...
%                     interface.SeqDiscrArea(interface.SatObj(satIdx).servUsr(bfIdx), :);
                interface.tmpSat(satIdx).beamfoot(sche, bfIdx).position = ...
                    interface.UsrsObj(find(interface.OrderOfSelectedUsrs==interface.SatObj(satIdx).servUsr(sche,bfIdx))).position;

                interface.tmpSat(satIdx).beamfoot(sche, bfIdx).usrs = ...    
                    interface.SatObj(satIdx).servUsr(sche,bfIdx);

                %波位占用的三角形们
                Radius = 6371.393e3;
                Rb = tools.getEarthLength(interface.AngleOf3dB, interface.height)/2;                
                hOfDiscr = tools.LatLngCoordi2Length([0 0], [0 1], Radius)/interface.factorOfDiscr;%离散三角行的行高
                NofRaw = 2 * ceil(Rb/(2*hOfDiscr/sqrt(3))); % 一个波位占用的离散三角行数
                position = interface.tmpSat(satIdx).beamfoot(sche, bfIdx).position;
                [orderOfcetr(1),orderOfcetr(2), orderOfcetr(3)] = tools.findPointXY(interface, position(2),position(1));
                interface.tmpSat(satIdx).beamfoot(sche, bfIdx).servTri = ...
                    simSatSysClass.tools.setBeamFoot(orderOfcetr(1:2), orderOfcetr(3), NofRaw, interface.rowNum, interface.colNum); 
            end
        end
    end
end

