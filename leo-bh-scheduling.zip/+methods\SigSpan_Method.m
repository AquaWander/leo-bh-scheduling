function SigSpan_Method(interface)
%SIGSPAN_METHOD 此处显示有关此函数的摘要

%记录一下已经生成过表格的卫星
tabledSat = [];

    for idxOfSat = 1 : length(interface.OrderOfServSatCur)
        numOfsigbeamfoot = interface.SatObj(idxOfSat).numOfsigbeam; % 星下信令波位数量
        numOfsigbeam = interface.numOfSigbeam; % 信令波束数量
        SpanIDXOfsigbeam = interface.SatObj(idxOfSat).SpanIDXOfsigbeam; % 用于星下信令扫描的信令波位编号
%         ScheOfSig = ceil(interface.SatObj(idxOfSat).ScheOfSig/interface.timeInSlot);   % 信令扫描周期(slot)
%         LightTimeOfSig = ceil(interface.SatObj(idxOfSat).LightTimeOfSig/interface.timeInSlot);   % 信令注视时长(slot)

        totalslot = interface.ScheInShot * interface.SlotInSche;
        signaltable = zeros(numOfsigbeam,totalslot);%建立信令波束表格，是在整个跳波束周期里的

        %思路：两个波束，每个波束只负责一半的波位

        midSerial = ceil(numOfsigbeamfoot/2);

        %第一个波束
        c = 1;%计数
        cc = 1;%用于指向波位编号
        while(c <= totalslot)
            if mod(c - 1,midSerial) == 0 %如果已经全部都遍历过了
                %重新开始
                cc = 1;
            end
            signaltable(1,c) = SpanIDXOfsigbeam(cc);
            c = c + 1;
            cc = cc + 1;            
        end

        %第二个波束
        c = 1;%计数
        cc = midSerial + 1;%用于指向波位编号
        while(c <= totalslot)
            if mod(c - 1,numOfsigbeamfoot - midSerial) == 0 %如果已经全部都遍历过了
                %重新开始
                cc = midSerial + 1;
            end
            signaltable(2,c) = SpanIDXOfsigbeam(cc);
            c = c + 1;
            cc = cc + 1;            
        end

%         SeqInSpanOfsigbeam = zeros(numOfsigbeam, ceil(numOfsigbeamfoot/numOfsigbeam));
%         interval = ceil(numOfsigbeamfoot/numOfsigbeam);
%         for k = 1 : numOfsigbeam
%             if k*interval <= numOfsigbeamfoot
%                 SeqInSpanOfsigbeam(k, :) = SpanIDXOfsigbeam(1+(k-1)*interval : k*interval);
%             else
%                 SeqInSpanOfsigbeam(k, 1 : length(SpanIDXOfsigbeam(1+(k-1)*interval : end))) = SpanIDXOfsigbeam(1+(k-1)*interval : end);
%             end
%         end
%         interface.SatObj(idxOfSat).SeqInSpanOfsigbeam = SeqInSpanOfsigbeam;
%         TableOfSig = zeros(numOfsigbeam, interface.SlotInSche * interface.ScheInShot);
%         count = 1;
%         for j = 1 : LightTimeOfSig : interface.SlotInSche * interface.ScheInShot
%             if count ~= -1 
%                 for k = 1 : numOfsigbeam
%                     if j+LightTimeOfSig-1 <= interface.SlotInSche*interface.ScheInShot
%                         TableOfSig(k, j:j+LightTimeOfSig-1) = SeqInSpanOfsigbeam(k, count); 
%                     else
%                         TableOfSig(k, j:end) = SeqInSpanOfsigbeam(k, count);
%                     end
%                 end
%                 if count == ceil(numOfsigbeamfoot/numOfsigbeam)
%                     count = -1;
%                 else
%                     count = count + 1;
%                 end
%             end
%             if mod(j, ScheOfSig) < 3 && j > ScheOfSig
%                 count = 1;
%             end
%         end

        % 


        interface.SatObj(idxOfSat).TableOfSig = signaltable;
    end
    
    
end

% function SigSpan_Method(interface)
% %SIGSPAN_METHOD 此处显示有关此函数的摘要
% %   此处显示详细说明
%     for idxOfSat = 1 : length(interface.OrderOfServSatCur)
%         numOfsigbeamfoot = interface.SatObj(idxOfSat).numOfsigbeam; % 星下信令波位数量
%         numOfsigbeam = interface.numOfSigbeam; % 信令波束数量
%         SpanIDXOfsigbeam = interface.SatObj(idxOfSat).SpanIDXOfsigbeam; % 用于星下信令扫描的信令波位编号
% %         ScheOfSig = ceil(interface.SatObj(idxOfSat).ScheOfSig/interface.timeInSlot);   % 信令扫描周期(slot)
%         LightTimeOfSig = ceil(interface.SatObj(idxOfSat).LightTimeOfSig/interface.timeInSlot);   % 信令注视时长(slot)
% 
% 
%         SeqInSpanOfsigbeam = zeros(numOfsigbeam, ceil(numOfsigbeamfoot/numOfsigbeam));
%         interval = ceil(numOfsigbeamfoot/numOfsigbeam);
%         for k = 1 : numOfsigbeam
%             if k*interval <= numOfsigbeamfoot
%                 SeqInSpanOfsigbeam(k, :) = SpanIDXOfsigbeam(1+(k-1)*interval : k*interval);
%             else
%                 SeqInSpanOfsigbeam(k, 1 : length(SpanIDXOfsigbeam(1+(k-1)*interval : end))) = SpanIDXOfsigbeam(1+(k-1)*interval : end);
%             end
%         end
%         interface.SatObj(idxOfSat).SeqInSpanOfsigbeam = SeqInSpanOfsigbeam;
%         TableOfSig = zeros(numOfsigbeam, interface.SlotInSche * interface.ScheInShot);
%         count = 1;
%         for j = 1 : LightTimeOfSig : interface.SlotInSche * interface.ScheInShot
%             if count ~= -1 
%                 for k = 1 : numOfsigbeam
%                     if j+LightTimeOfSig-1 <= interface.SlotInSche*interface.ScheInShot
%                         TableOfSig(k, j:j+LightTimeOfSig-1) = SeqInSpanOfsigbeam(k, count); 
%                     else
%                         TableOfSig(k, j:end) = SeqInSpanOfsigbeam(k, count);
%                     end
%                 end
%                 if count == ceil(numOfsigbeamfoot/numOfsigbeam)
%                     count = -1;
%                 else
%                     count = count + 1;
%                 end
%             end
%             if mod(j, ScheOfSig) < 3 && j > ScheOfSig
%                 count = 1;
%             end
%         end
%         interface.SatObj(idxOfSat).TableOfSig = TableOfSig;
%     end
%     
%     
% end


% function SigSpan_Method(interface)
% %SIGSPAN_METHOD 此处显示有关此函数的摘要
% %   此处显示详细说明
%     for idxOfSat = 1 : length(interface.OrderOfServSatCur)
%         numOfsigbeamfoot = interface.SatObj(idxOfSat).numOfsigbeam; % 星下信令波位数量
%         numOfsigbeam = interface.numOfSigbeam; % 信令波束数量
%         SpanIDXOfsigbeam = interface.SatObj(idxOfSat).SpanIDXOfsigbeam; % 用于星下信令扫描的信令波位编号
%         ScheOfSig = ceil(interface.SatObj(idxOfSat).ScheOfSig/interface.timeInSlot);   % 信令扫描周期(slot)
%         LightTimeOfSig = ceil(interface.SatObj(idxOfSat).LightTimeOfSig/interface.timeInSlot);   % 信令注视时长(slot)
% 
% 
%         SeqInSpanOfsigbeam = zeros(numOfsigbeam, ceil(numOfsigbeamfoot/numOfsigbeam));
%         interval = ceil(numOfsigbeamfoot/numOfsigbeam);
%         for k = 1 : numOfsigbeam
%             if k*interval <= numOfsigbeamfoot
%                 SeqInSpanOfsigbeam(k, :) = SpanIDXOfsigbeam(1+(k-1)*interval : k*interval);
%             else
%                 SeqInSpanOfsigbeam(k, 1 : length(SpanIDXOfsigbeam(1+(k-1)*interval : end))) = SpanIDXOfsigbeam(1+(k-1)*interval : end);
%             end
%         end
%         interface.SatObj(idxOfSat).SeqInSpanOfsigbeam = SeqInSpanOfsigbeam;
%         TableOfSig = zeros(numOfsigbeam, interface.SlotInSche * interface.ScheInShot);
%         count = 1;
%         for j = 1 : LightTimeOfSig : interface.SlotInSche * interface.ScheInShot
%             if count ~= -1 
%                 for k = 1 : numOfsigbeam
%                     if j+LightTimeOfSig-1 <= interface.SlotInSche*interface.ScheInShot
%                         TableOfSig(k, j:j+LightTimeOfSig-1) = SeqInSpanOfsigbeam(k, count); 
%                     else
%                         TableOfSig(k, j:end) = SeqInSpanOfsigbeam(k, count);
%                     end
%                 end
%                 if count == ceil(numOfsigbeamfoot/numOfsigbeam)
%                     count = -1;
%                 else
%                     count = count + 1;
%                 end
%             end
%             if mod(j, ScheOfSig) < 3 && j > ScheOfSig
%                 count = 1;
%             end
%         end
%         interface.SatObj(idxOfSat).TableOfSig = TableOfSig;
%     end
%     
%     
% end

