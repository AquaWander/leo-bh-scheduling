% visualize/plot_Throughput_Comparison.m
% 绘制禁忌搜索 vs DQN 的吞吐量对比图

clear; clc;

fprintf('=== 吞吐量对比分析 ===\n\n');

% 加载结果文件
try
    load('results/results_TabuSearch.mat');
    fprintf('[✓] 禁忌搜索结果已加载\n');
catch
    fprintf('[✗] 禁忌搜索结果文件不存在\n');
    fprintf('    请先运行 run_TabuSearch.m\n');
    return;
end

try
    load('results/results_DQN.mat');
    fprintf('[✓] DQN结果已加载\n');
catch
    fprintf('[✗] DQN结果文件不存在\n');
    fprintf('    请先运行 run_DQN.m\n');
    return;
end

fprintf('\n');

% 统计有效数据
valid_Tabu = ~isnan(throughputs_Tabu);
valid_DQN = ~isnan(throughputs_DQN);

num_valid_Tabu = sum(valid_Tabu);
num_valid_DQN = sum(valid_DQN);

fprintf('有效数据统计:\n');
fprintf('  - 禁忌搜索: %d/%d\n', num_valid_Tabu, length(throughputs_Tabu));
fprintf('  - DQN: %d/%d\n\n', num_valid_DQN, length(throughputs_DQN));

if num_valid_Tabu == 0 || num_valid_DQN == 0
    fprintf('[✗] 有效数据不足，无法绘制对比图\n');
    return;
end

% 计算统计量
mean_Tabu = mean(throughputs_Tabu(valid_Tabu));
std_Tabu = std(throughputs_Tabu(valid_Tabu));
mean_DQN = mean(throughputs_DQN(valid_DQN));
std_DQN = std(throughputs_DQN(valid_DQN));

% 计算提升百分比
improvement = (mean_Tabu - mean_DQN) / mean_DQN * 100;

% 绘制柱状图
figure('Color', 'w', 'Position', [100, 100, 800, 500]);

data = [mean_Tabu, mean_DQN];
errors = [std_Tabu, std_DQN];

b = bar(data, 'FaceColor', 'flat', 'BarWidth', 0.6);
b.CData(1,:) = [0, 0.4470, 0.7410]; % 蓝色（禁忌搜索）
b.CData(2,:) = [0.8500, 0.3250, 0.0980]; % 红色（DQN）

hold on;

% 添加误差棒
errorbar(1:2, data, errors, 'k.', 'LineWidth', 2, 'CapSize', 10);

% 添加数值标签
for i = 1:length(data)
    text(i, data(i) + errors(i), sprintf('%.2f', data(i)), ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'bottom', ...
        'FontSize', 12, ...
        'FontWeight', 'bold');
end

% 添加提升百分比标记
if improvement > 0
    text(2, data(2) + errors(2) * 2, ...
        sprintf('+%.2f%%', improvement), ...
        'HorizontalAlignment', 'center', ...
        'Color', [0, 0.5, 0], ...
        'FontSize', 14, ...
        'FontWeight', 'bold');
end

% 设置图形属性
grid on;
xlabel('算法', 'FontSize', 14, 'FontName', 'Times New Roman');
ylabel('系统吞吐量 (Mbps)', 'FontSize', 14, 'FontName', 'Times New Roman');
title('系统吞吐量对比：禁忌搜索 vs DQN', 'FontSize', 16, 'FontName', 'Times New Roman');
set(gca, 'XTickLabel', {'禁忌搜索', 'DQN'}, 'FontSize', 12, 'FontName', 'Times New Roman');
set(gca, 'YGrid', 'on', 'XGrid', 'on', 'LineWidth', 1.5);
ylim([0, max(data + errors) * 1.2]);

% 添加图例
legend('平均值', '标准差', 'Location', 'best', 'FontSize', 10);

% 保存图像
dateStr = datestr(now, 'yyyy-mm-dd_HH-MM-SS');
filename_fig = sprintf('visualize/Throughput_Comparison_%s.fig', dateStr);
filename_png = sprintf('visualize/Throughput_Comparison_%s.png', dateStr);

try
    saveas(gcf, filename_fig);
    fprintf('[✓] FIG图像已保存: %s\n', filename_fig);
catch ME
    fprintf('[✗] FIG图像保存失败: %s\n', ME.message);
end

try
    saveas(gcf, filename_png);
    fprintf('[✓] PNG图像已保存: %s\n', filename_png);
catch ME
    fprintf('[✗] PNG图像保存失败: %s\n', ME.message);
end

% 打印统计结果
fprintf('\n=== 统计结果 ===\n');
fprintf('禁忌搜索:\n');
fprintf('  - 平均吞吐量: %.2f ± %.2f Mbps\n', mean_Tabu, std_Tabu);
fprintf('  - 最小值: %.2f Mbps\n', min(throughputs_Tabu(valid_Tabu)));
fprintf('  - 最大值: %.2f Mbps\n', max(throughputs_Tabu(valid_Tabu)));
fprintf('\n');

fprintf('DQN:\n');
fprintf('  - 平均吞吐量: %.2f ± %.2f Mbps\n', mean_DQN, std_DQN);
fprintf('  - 最小值: %.2f Mbps\n', min(throughputs_DQN(valid_DQN)));
fprintf('  - 最大值: %.2f Mbps\n', max(throughputs_DQN(valid_DQN)));
fprintf('\n');

fprintf('性能对比:\n');
fprintf('  - 禁忌搜索提升: %.2f%%\n', improvement);
fprintf('\n');

% 显著性检验（t检验）
try
    [h, p] = ttest2(throughputs_Tabu(valid_Tabu), throughputs_DQN(valid_DQN));
    fprintf('t检验结果:\n');
    fprintf('  - h = %d (h=1表示有显著差异)\n', h);
    fprintf('  - p = %.4f\n', p);
    if p < 0.01
        fprintf('  - 结论: 差异极其显著 (p < 0.01)\n');
    elseif p < 0.05
        fprintf('  - 结论: 差异显著 (p < 0.05)\n');
    else
        fprintf('  - 结论: 差异不显著 (p >= 0.05)\n');
    end
catch ME
    fprintf('显著性检验失败: %s\n', ME.message);
end

fprintf('\n=== 分析完成 ===\n');
