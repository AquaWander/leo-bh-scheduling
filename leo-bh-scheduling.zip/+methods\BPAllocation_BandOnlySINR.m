function BPAllocation_BandOnlySINR(interface)
% 本函数用于对波位内用户分配频带和功率，提出的算法

%% 获得数据
OrderOfServSatCur = interface.OrderOfServSatCur;    % 服务卫星的列表
NumOfServSatCur = length(OrderOfServSatCur);    % 服务卫星的数量
NumOfSche = interface.ScheInShot;  % 快照的调度周期数
Num_slot = interface.SlotInSche;    % 调度周期的slot数量
BW = interface.BandOfLink*1e6; % 带宽，单位是Hz
freqOfDownLink = interface.freqOfDownLink; % (Hz) 卫星的下行链路中心频点
startOfBand = freqOfDownLink - BW / 2;% (Hz) 卫星的下行链路开始频点
heightOfsat = interface.height;%卫星轨道高度
maxPower = 10^(interface.Pt_dBm_serv/10)/1000/interface.numOfServbeam;% 每个波束的总功率，单位是w
K = 1.38e-23;  % 玻尔兹曼常量
Ta_usr = interface.Config.Usr_T_noise;
F_usr = interface.Config.Usr_F_noise;
% 是否需要考虑每个首先每个波束的功率并不平均？
% 考虑的话也是个凸优化问题，应该可以同样使用拉格朗日+注水，考虑与否可以作为两个曲线结果
%% 遍历
for SatIdx = 1 : NumOfServSatCur % 遍历卫星
    curSatPos = interface.SatObj(SatIdx).position;
    satPosInDescartes = LngLat2Descartes(curSatPos, heightOfsat);
    curSatNextPos = interface.SatObj(SatIdx).nextpos;
    BHST = interface.tmpSat(SatIdx).BHST;
    powerTable = interface.tmpSat(SatIdx).Pt_Antenna;
    NumOfSlotPerShot = length(BHST(1,:));
    
    for slotIdx = 1 : NumOfSlotPerShot %遍历时隙
        scheIdx = ceil(slotIdx / Num_slot);
        % 获得当前卫星当前时隙的点亮波位
        notzero = BHST(:, slotIdx) ~= 0;
        LightBeamfoot = BHST(notzero, slotIdx);
        NumOfLightBeamfoot = length(LightBeamfoot);
        LightPower = powerTable(notzero, slotIdx);
        % 遍历波位，开始用匈牙利做第一步的分配，这一步按照和卫星距离从近到远开始分配
        % step1：计算距离
        foot2SatDist = zeros(1, length(LightBeamfoot));
        for footIdx = 1 : length(LightBeamfoot)
            curFoot = LightBeamfoot(footIdx);
            % 波位的位置
            footPosition = interface.tmpSat(SatIdx).beamfoot(scheIdx, curFoot).position;
            % 计算到卫星的距离
            footPosInDescartes = LngLat2Descartes(footPosition, 0);
            foot2SatDist(footIdx) = sqrt((satPosInDescartes(1)-footPosInDescartes(1)).^2 + ...
                            (satPosInDescartes(2)-footPosInDescartes(2)).^2 + ...
                            (satPosInDescartes(3)-footPosInDescartes(3)).^2);  
        end
        % step2：排序
        [~, sortList] = sort(foot2SatDist, 'ascend');
        LightBeamfoot = LightBeamfoot(sortList);
        LightPower = LightPower(sortList);
        
        % step3：根据排序顺序开始分配
        for footIdx = 1 : length(LightBeamfoot)
            curFoot = LightBeamfoot(footIdx);
            % 获得波位信息
            orderOfUsrs = interface.tmpSat(SatIdx).beamfoot(scheIdx, curFoot).usrs;
            numOfUserInFoot = length(orderOfUsrs);
            subBandWidth = BW/numOfUserInFoot;% 每个子带的宽度
            if numOfUserInFoot == 1
                %如果只有一个用户，那就不用那么费劲了
                tmp = find(interface.OrderOfSelectedUsrs == orderOfUsrs);
                interface.UsrsObj(tmp).Band(slotIdx, :) = [startOfBand, startOfBand + BW];
                interface.UsrsObj(tmp).BandWidth(slotIdx) = BW;
                interface.UsrsObj(tmp).PowerPercent(slotIdx) = 1;
            else                

                % 计算所有指向
                PosOfBeam = zeros(NumOfLightBeamfoot, 2);    % 点亮波位中心三角形坐标 
                for bidx = 1 : NumOfLightBeamfoot
                    PosOfBeam(bidx, :) = interface.tmpSat(SatIdx).beamfoot(scheIdx, LightBeamfoot(bidx)).position; 
                end

                BeamPoint = zeros(NumOfLightBeamfoot, 2); % varphi(俯仰，偏离x轴),vartheta(方向，偏离xOy平面),天线在zOy平面(右手系)
                for j = 1 : NumOfLightBeamfoot
                    [outputTheta, outputPhi] = tools.getPointAngleOfUsr(...
                        curSatPos, curSatNextPos, PosOfBeam(j, :), heightOfsat);
                    BeamPoint(j,1) = outputPhi;
                    BeamPoint(j,2) = outputTheta;
                end

                %% 分配频段：匈牙利
                % 计算用户的矩阵
                n = numOfUserInFoot;% 矩阵维度
                HungMat = zeros(n, n);
                hMat = zeros(n,n);
                for i = 1 : n % 用户
                    curUser = orderOfUsrs(i);
                    for j = 1 : n % band
                        % 计算award
                        tmpBand = [startOfBand + subBandWidth * (j - 1), startOfBand + subBandWidth * j];
                        [SINR, hhh] = CaculateR(SatIdx, scheIdx, slotIdx, curUser, curFoot, LightBeamfoot, LightPower, BeamPoint, tmpBand, interface, 0);
                        HungMat(i,j) = SINR;
                        hMat(i, j) = hhh;
                    end
                end
                % 因为匈牙利是求最小化问题，但是我需要最大化，所以转换问题
                % 当面对最大化指派问题，可以从系数矩阵C中，找出最大元素m，用m减去矩阵C中所有元素得到系数矩阵B，则以B为系数矩阵的最小化指派问题和以C为系数矩阵的原最大化指派问题有相同最优解。
                NewHungMat = max(max(HungMat)) - HungMat;
                [assignment,~] = munkres(NewHungMat);

                % 当前
                allocBand = zeros(n,2);
                for i = 1 : n
                    res = assignment(i);
                    allocBand(i, 1) = startOfBand + (res - 1) * subBandWidth;
                    allocBand(i, 2) = startOfBand + res * subBandWidth;              
                end

                %% 分配功率：拉格朗日+注水
                % 获得的结果应该是一个波位内每个用户之于总功率的占比
                h = zeros(1, n);
                for i = 1 : n % 用户
%                     curUser = orderOfUsrs(i);
%     
%                     tmpBand = allocBand(i, :);
%                     
%                     [~, curH] = CaculateR(SatIdx, scheIdx, slotIdx, curUser, curFoot, LightBeamfoot, LightPower, BeamPoint, tmpBand, interface, 1);
    
                    h(i) = hMat(i, assignment(i));
                end
                [~, allocPercentage] = water_filling2(1./h, maxPower);


%                 %% 分配频段：优化
%                 % 迭代求解，参考动态跳波束策略中的自适应波束功率分配算法这篇里的功率分配方法，自适应分配
%                 while true
%                     % 计算平均C
%                     a = zeros(1,n);
%                     for ii = 1 : n % 用户
%                         tmpBand = allocBand(ii, :);
%                         [SINR, ~] = CaculateR(SatIdx, scheIdx, slotIdx, curUser, curFoot, LightBeamfoot, LightPower, BeamPoint, tmpBand, interface,0);
% 
%                         a(ii) = (tmpBand(2) - tmpBand(1)) * log2(1 + SINR);                                        
%                     end
%     
%                     %按比例更新
%                     tempAllocBand = zeros(n, 2);
%                     for ii = 1 : n % 用户
%                         cur = assignment(ii);%按照assignment的顺序进行分配
%                         tempbandWidth = BW * a(cur) / sum(a);
%                         if ii == 1
%                             tempAllocBand(cur, 1) = startOfBand;
%                             tempAllocBand(cur, 2) = startOfBand + tempbandWidth;
%                         else
%                             tempAllocBand(cur, 1) = tempAllocBand(assignment(ii - 1), 2);
%                             tempAllocBand(cur, 2) = tempAllocBand(cur, 1) + tempbandWidth;
%                         end                    
%                     end
%     
%                     %计算更新后的结果
%                     temp_a = zeros(1, n);
%                     for ii = 1 : n % 用户
%                         tmpBand = tempAllocBand(ii, :);
%                         [SINR, ~] = CaculateR(SatIdx, scheIdx, slotIdx, curUser, curFoot, LightBeamfoot, LightPower, BeamPoint, tmpBand, interface,0);
% 
%                         temp_a(ii) = (tmpBand(2) - tmpBand(1)) * log2(1 + SINR);
%     %                     temp_a(ii) = (tempAllocBand(ii, 2) - tempAllocBand(ii, 1)) * log2(1 + avgPower * (3e8/curFc /(4 * pi * d(ii)))^2 * Gsat * Gusr / N_noise_usr);                    
%                     end
%     
%                     %比较两次结果,如果不是更优，就break，不然就下一次更新
%                     if mean(temp_a) - mean(a) < 1
%                         break;
%                     else
% %                         mean(temp_a)
% %                         mean(a)
%                         for ii = 1 : n
%                             allocBand(ii, 1) = tempAllocBand(ii, 1);
%                             allocBand(ii, 2) = tempAllocBand(ii, 2);              
%                         end
%                     end
%                 end

                %存结果
                for i = 1 : n
    %                 res = assignment(i);
                    tmp = find(interface.OrderOfSelectedUsrs == orderOfUsrs(i));
                    interface.UsrsObj(tmp).Band(slotIdx, :) = [allocBand(i,1), allocBand(i,2)];
                    interface.UsrsObj(tmp).BandWidth(slotIdx) =  allocBand(i,2) - allocBand(i,1);
                end

                %% 分配功率：拉格朗日+注水
                % 获得的结果应该是一个波位内每个用户之于总功率的占比
                h = zeros(1, n);
                for i = 1 : n % 用户
                    curUser = orderOfUsrs(i);

%                     if curUser == 39
%                         fprintf('aaa')
%                     end
    
                    tmpBand = allocBand(i, :);
                    
                    [~, curH] = CaculateR(SatIdx, scheIdx, slotIdx, curUser, curFoot, LightBeamfoot, LightPower, BeamPoint, tmpBand, interface, 1);
    
                    h(i) = curH;
                end
                [~, allocPercentage] = water_filling3(1./h, maxPower);
    
                %存结果
                for i = 1 : n
                    tmp = find(interface.OrderOfSelectedUsrs == orderOfUsrs(i));
%                     interface.UsrsObj(orderOfUsrs(i)).PowerPercent(slotIdx) = h(i) / sum(h);
                    interface.UsrsObj(tmp).PowerPercent(slotIdx) = allocPercentage(i);
                end

                

            end
        end
  

    fprintf('第%d颗卫星波束内资源调度计算已完成%f%%\n',SatIdx,slotIdx * 100 /NumOfSlotPerShot);
    end
    
end
end


%% 匈牙利
function [assignment,cost] = munkres(costMat)
% MUNKRES   Munkres (Hungarian) Algorithm for Linear Assignment Problem. 
%
% [ASSIGN,COST] = munkres(COSTMAT) returns the optimal column indices,
% ASSIGN assigned to each row and the minimum COST based on the assignment
% problem represented by the COSTMAT, where the (i,j)th element represents the cost to assign the jth
% job to the ith worker.
%
% Partial assignment: This code can identify a partial assignment is a full
% assignment is not feasible. For a partial assignment, there are some
% zero elements in the returning assignment vector, which indicate
% un-assigned tasks. The cost returned only contains the cost of partially
% assigned tasks.

% This is vectorized implementation of the algorithm. It is the fastest
% among all Matlab implementations of the algorithm.

% Examples
% Example 1: a 5 x 5 example
%{
[assignment,cost] = munkres(magic(5));
disp(assignment); % 3 2 1 5 4
disp(cost); %15
%}
% Example 2: 400 x 400 random data
%{
n=400;
A=rand(n);
tic
[a,b]=munkres(A);
toc                 % about 2 seconds 
%}
% Example 3: rectangular assignment with inf costs
%{
A=rand(10,7);
A(A>0.7)=Inf;
[a,b]=munkres(A);
%}
% Example 4: an example of partial assignment
%{
A = [1 3 Inf; Inf Inf 5; Inf Inf 0.5]; 
[a,b]=munkres(A)
%}
% a = [1 0 3]
% b = 1.5
% Reference:
% "Munkres' Assignment Algorithm, Modified for Rectangular Matrices", 
% http://csclab.murraystate.edu/bob.pilgrim/445/munkres.html

% version 2.3 by Yi Cao at Cranfield University on 11th September 2011

assignment = zeros(1,size(costMat,1));
cost = 0;

validMat = costMat == costMat & costMat < Inf;
bigM = 10^(ceil(log10(sum(costMat(validMat))))+1);
costMat(~validMat) = bigM;

% costMat(costMat~=costMat)=Inf;
% validMat = costMat<Inf;
validCol = any(validMat,1);
validRow = any(validMat,2);

nRows = sum(validRow);
nCols = sum(validCol);
n = max(nRows,nCols);
if ~n
    return
end

maxv=10*max(costMat(validMat));

dMat = zeros(n) + maxv;
dMat(1:nRows,1:nCols) = costMat(validRow,validCol);

%*************************************************
% Munkres' Assignment Algorithm starts here
%*************************************************

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   STEP 1: Subtract the row minimum from each row.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
minR = min(dMat,[],2);
minC = min(bsxfun(@minus, dMat, minR));

%**************************************************************************  
%   STEP 2: Find a zero of dMat. If there are no starred zeros in its
%           column or row start the zero. Repeat for each zero
%**************************************************************************
zP = dMat == bsxfun(@plus, minC, minR);

starZ = zeros(n,1);
while any(zP(:))
    [r,c]=find(zP,1);
    starZ(r)=c;
    zP(r,:)=false;
    zP(:,c)=false;
end

while 1
%**************************************************************************
%   STEP 3: Cover each column with a starred zero. If all the columns are
%           covered then the matching is maximum
%**************************************************************************
    if all(starZ>0)
        break
    end
    coverColumn = false(1,n);
    coverColumn(starZ(starZ>0))=true;
    coverRow = false(n,1);
    primeZ = zeros(n,1);
    [rIdx, cIdx] = find(dMat(~coverRow,~coverColumn)==bsxfun(@plus,minR(~coverRow),minC(~coverColumn)));
    while 1
        %**************************************************************************
        %   STEP 4: Find a noncovered zero and prime it.  If there is no starred
        %           zero in the row containing this primed zero, Go to Step 5.  
        %           Otherwise, cover this row and uncover the column containing 
        %           the starred zero. Continue in this manner until there are no 
        %           uncovered zeros left. Save the smallest uncovered value and 
        %           Go to Step 6.
        %**************************************************************************
        cR = find(~coverRow);
        cC = find(~coverColumn);
        rIdx = cR(rIdx);
        cIdx = cC(cIdx);
        Step = 6;
        while ~isempty(cIdx)
            uZr = rIdx(1);
            uZc = cIdx(1);
            primeZ(uZr) = uZc;
            stz = starZ(uZr);
            if ~stz
                Step = 5;
                break;
            end
            coverRow(uZr) = true;
            coverColumn(stz) = false;
            z = rIdx==uZr;
            rIdx(z) = [];
            cIdx(z) = [];
            cR = find(~coverRow);
            z = dMat(~coverRow,stz) == minR(~coverRow) + minC(stz);
            rIdx = [rIdx(:);cR(z)];
            cIdx = [cIdx(:);stz(ones(sum(z),1))];
        end
        if Step == 6
            % *************************************************************************
            % STEP 6: Add the minimum uncovered value to every element of each covered
            %         row, and subtract it from every element of each uncovered column.
            %         Return to Step 4 without altering any stars, primes, or covered lines.
            %**************************************************************************
            [minval,rIdx,cIdx]=outerplus(dMat(~coverRow,~coverColumn),minR(~coverRow),minC(~coverColumn));            
            minC(~coverColumn) = minC(~coverColumn) + minval;
            minR(coverRow) = minR(coverRow) - minval;
        else
            break
        end
    end
    %**************************************************************************
    % STEP 5:
    %  Construct a series of alternating primed and starred zeros as
    %  follows:
    %  Let Z0 represent the uncovered primed zero found in Step 4.
    %  Let Z1 denote the starred zero in the column of Z0 (if any).
    %  Let Z2 denote the primed zero in the row of Z1 (there will always
    %  be one).  Continue until the series terminates at a primed zero
    %  that has no starred zero in its column.  Unstar each starred
    %  zero of the series, star each primed zero of the series, erase
    %  all primes and uncover every line in the matrix.  Return to Step 3.
    %**************************************************************************
    rowZ1 = find(starZ==uZc);
    starZ(uZr)=uZc;
    while rowZ1>0
        starZ(rowZ1)=0;
        uZc = primeZ(rowZ1);
        uZr = rowZ1;
        rowZ1 = find(starZ==uZc);
        starZ(uZr)=uZc;
    end
end

% Cost of assignment
rowIdx = find(validRow);
colIdx = find(validCol);
starZ = starZ(1:nRows);
vIdx = starZ <= nCols;
assignment(rowIdx(vIdx)) = colIdx(starZ(vIdx));
pass = assignment(assignment>0);
pass(~diag(validMat(assignment>0,pass))) = 0;
assignment(assignment>0) = pass;
cost = trace(costMat(assignment>0,assignment(assignment>0)));
end

function [minval,rIdx,cIdx]=outerplus(M,x,y)

ny=size(M,2);
minval=inf;
for c=1:ny
    M(:,c)=M(:,c)-(x+y(c));
    minval = min(minval,min(M(:,c)));
end
[rIdx,cIdx]=find(M==minval);
end

%%
function PosInDescartes = LngLat2Descartes(CurPos, h)
    tmpPhi = CurPos(1) * pi / 180;
    if tmpPhi < 0
        tmpPhi = tmpPhi + 2*pi;
    end
    tmpTheta = (90 - CurPos(2)) * pi / 180;
    R = 6371.393e3; % 地球半径
    tmpX = (R+h) * sin(tmpTheta) * cos(tmpPhi);
    tmpY = (R+h) * sin(tmpTheta) * sin(tmpPhi);
    tmpZ = (R+h) * cos(tmpTheta); 
    PosInDescartes = [tmpX, tmpY, tmpZ];    
end

%% 计算SINR值和h值
function [SINR, h] = CaculateR(SatIdx, ScheIdx, slotIdx, userIdx, curFoot, lightFoot, lightPower, BeamPoint, thisBand, interface, ifH)
% 输入：SatIdx卫星编号；ScheIdx调度周期编号；userIdx当前用户编号；footIdx当前波位编号；
% lightFoot所有点亮波位编号；lightPower所有点亮波位的功率分配编号；BeamPoint指向；
% thisBand当前频带
    
    Usrs = interface.tmpSat(SatIdx).beamfoot(ScheIdx, curFoot).usrs;% 波位里的用户
    footIdx = find(lightFoot == curFoot);
    Pt = lightPower(footIdx) / length(Usrs);   % 每个用户分到的功率

    T_noise = interface.UsrsObj(1).T_noise;
    F_noise_dB = interface.UsrsObj(1).F_noise;
    F_noise = 10.^(F_noise_dB./10);
    N0_noise = 1.380649e-23*(T_noise + (F_noise-1)*300);

    Bandwidth = thisBand(2) - thisBand(1);
    fc = mean(thisBand);

    % 计算当前用户的指向角 
    userIdx = find(interface.OrderOfSelectedUsrs == userIdx);
    userCurPos = interface.UsrsObj(userIdx).position; % 当前用户坐标    
    satCurPos = interface.SatObj(SatIdx).position; % 当前卫星星下点坐标
    satCurnextPos = interface.SatObj(SatIdx).nextpos; % 当前卫星星下点下一step坐标
    [userTheta, userPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, userCurPos, interface.height);%计算方位角和仰角
    % 计算用户接收增益
    G_usrDown = antenna.getUsrAntennaServG(0, fc, false);
    % 计算当前卫星到当前用户的距离
    usrCurPos = interface.UsrsObj(userIdx).position;
    usrPosInDescartes = LngLat2Descartes(usrCurPos, 0);
    satPosInDescartes = LngLat2Descartes(satCurPos, interface.height);
    distance = sqrt((satPosInDescartes(1)-usrPosInDescartes(1)).^2 + ...
                    (satPosInDescartes(2)-usrPosInDescartes(2)).^2 + ...
                    (satPosInDescartes(3)-usrPosInDescartes(3)).^2);  
    InterfInSatDown = 0;

    %遍历干扰波位，是按照是否已经分配的顺序来的，计算干扰
    index = find(lightFoot == curFoot);% 找到所处的分配顺序
    if index > 1 %
        for bfIdx = 1 : index - 1 % 计算和前面已经分配过的波位的干扰
            OrderOfbeam = lightFoot(bfIdx);% 波位的实际编号
            %干扰波位里的用户的编号
            interfUsrs = interface.tmpSat(SatIdx).beamfoot(ScheIdx, OrderOfbeam).usrs;
            % 干扰波位被分配到的功率
            interfBeamPower = lightPower(bfIdx);
            poiBeta = BeamPoint(bfIdx,1);
            poiAlpha = BeamPoint(bfIdx,2);
            AgleOfInv = [userTheta, userPhi];
            AgleOfPoi = [poiAlpha, poiBeta];
            for interfUsrIdx = 1 : length(interfUsrs) % 遍历该波位里用户的干扰
                % 获得这个干扰用户的功率、频带
                thisInterfUser = interfUsrs(interfUsrIdx);
                thisInterfUser = find(interface.OrderOfSelectedUsrs == thisInterfUser);
                if ifH == 0
                    thisInterfUser_power = interfBeamPower / length(interfUsrs);
                else
                    thisInterfUser_power = interface.UsrsObj(thisInterfUser).PowerPercent(slotIdx) * interfBeamPower;
                end
                thisInterfUser_band = interface.UsrsObj(thisInterfUser).Band(slotIdx, :);

                % 判断是否有频段重合
                overlap = range_intersection(thisBand, thisInterfUser_band);% 注意检查f的单位是不是Hz
                if length(overlap) == 2
                    lambdaDown = 3e8/mean(overlap);
                    G_sat_interfDown = antenna.getSatAntennaServG(AgleOfInv, AgleOfPoi, mean(overlap));
                    InterfInSatDown = InterfInSatDown + ...
                        thisInterfUser_power * G_sat_interfDown * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
                end

            end 

        end
        % 第一次分配，只需SNR，所以无需计算干扰

    end
    %%%%%%%%%%%%%%%%%%%%%
    bfIdx = find(lightFoot == curFoot);
    poiBeta = BeamPoint(bfIdx,1);
    poiAlpha = BeamPoint(bfIdx,2);
    AgleOfInv = [userTheta, userPhi];
    AgleOfPoi = [poiAlpha, poiBeta];
    lambda_c = 3e8/fc;

    G_sat_down = antenna.getSatAntennaServG(AgleOfInv, AgleOfPoi, fc);
    %%%%%%%%%%%%%%%%%%%%%
    Carrier_down = Pt * G_sat_down * G_usrDown * (lambda_c.^2) / (((4*pi).^2)*(distance.^2));
    SINR = Carrier_down./(InterfInSatDown + Bandwidth*N0_noise);
    h = SINR/Pt;
%     SNR = Carrier_down./(Bandwidth*N0_noise);
end

%% 求交集
function [ Overlap ] = range_intersection( A,B )

%A and B is a vector 
%for example A = [1 2 3]; B = [2 2.5 3 4]; 

%find lower and upper limit for vector A and B
Lower_A = min(A); 
Upper_A = max(A); 

Lower_B = min(B); 
Upper_B = max(B); 

%check condition of lower and upper limit both vector
%this part is to determine lower limit 
if (Lower_A > Lower_B || Lower_A == Lower_B)
    Lower_Lim = Lower_A;    
else
    Lower_Lim = Lower_B; 
end

%this part is to determine upper limit
if (Upper_A > Upper_B || Upper_A == Upper_B)
    Upper_Lim = Upper_B;    
else
    Upper_Lim = Upper_A; 
end

%merge all vectors
input_vector = union(A,B); 

Overlap = input_vector(intersect(find(input_vector>=Lower_Lim),find(input_vector<=Upper_Lim)));

end


function [palloc_matrix, allocPercentage] = water_filling2(loss, P)
% loss, Kx1向量，即L
% P, 要分配的总功率
% A, 对角阵，即权重alpha
% palloc_matrix, 对角阵，功率分配结果，迹等于P

	K = length(loss);
    
	w = 1/log(2) + zeros(1, K); % 台阶宽度
	h = loss./w; % 台阶高度
	
	[h_sorted, h_idx] = sort(h); % 根据台阶高度升序排序
	w_sorted = w(h_idx);
    
    % 线性搜索，从后往前确定最后一个需要注水的台阶
    for i = K:-1:1
        
        w_tmp = sum(w_sorted(1:i-1)); % 当前台阶前面所有台阶的宽度之和
        h_tmp = h_sorted(i); % 当前台阶的高度
        
        % 把当前台阶之前的台阶注水到与当前台阶同高还有剩余水
        if w_tmp*h_tmp-sum(h_sorted(1:i-1).*w_sorted(1:i-1))<P
            idx = i;
            break;
        end
        
    end
    
    w_filled = sum(w_sorted(1:idx)); % 需要注水的所有台阶的总宽度
    h_filled = (P+sum(h_sorted(1:idx).*w_sorted(1:idx)))/w_filled; % 最终的水位线
	
	p_allocate = zeros(1, K);
    p_allocate(1:idx) = w_sorted(1:idx).*(h_filled-h_sorted(1:idx));
	
    % 恢复原来顺序
    [~, back_idx] = sort(h_idx);
    p_allocate = p_allocate(back_idx);
    
    palloc_matrix = diag(p_allocate);

    %我要获得的是比例
    allocPercentage = zeros(1, K);
    for k = 1 : K
        allocPercentage(k) = palloc_matrix(k, k) / P;
    end
    
end

function [palloc_matrix, allocPercentage] = water_filling3(loss, P)
    %% 初始化
    N= length(loss) ;                    %信道个数
    [noise_sorted,index]=sort(loss); 
    for p=length(noise_sorted):-1:1 
        T_P=(P+sum(noise_sorted(1:p)))/p; 
        Input_Power=T_P-noise_sorted; 
        Pt=Input_Power(1:p); 
        if(Pt(:)>=0)
            break 
        end 
    end 
    power_alloc=zeros(1,N); 
    power_alloc(index(1:p))=Pt;                                %分配的功率
    
    palloc_matrix = diag(power_alloc);

    %我要获得的是比例
    allocPercentage = zeros(1, N);
    for k = 1 : N
        allocPercentage(k) = palloc_matrix(k, k) / P;
    end

end

