% 2023/03/14
% 依据波束扫描范围self.Config.rangeOfBeam计算仿真区域self.DiscrArea的可见卫星
% 输出self.VisibleSat
%%
function calcuVisibleSat(self)
%使用的
%self.SatPosition是每一时刻卫星经纬度信息,第一个是经度，第二个是纬度
%self.Config.rangeOfBeam 波束扫描范围，第一个是前后，第二个是左右
%self.SeqDiscrArea 存了三角形中心的坐标，（k,1)是经度，(k,2)是纬度
%生成的
%self.VisibleSat 可见卫星位置矩阵，VisibleSat(k, j, 1:2)表示编号k卫星在第j步长的经纬坐标，不可见卫星编号下坐标写(500, 500) 

if self.Config.ifWrapAround == 1
    lat1 = self.wrapRange(2,1);lat2 = self.wrapRange(2,2);
    lon1 = self.wrapRange(1,1);lon2 = self.wrapRange(1,2);
else
    %测试地点的范围
    lat1 = self.Config.rangeOfInves(2,1);lat2 = self.Config.rangeOfInves(2,2);
    lon1 = self.Config.rangeOfInves(1,1);lon2 = self.Config.rangeOfInves(1,2); 
    %保证lat2存的那个是高纬度，这里的高是数值上的大，是用来划定大区域的
    if lat2 < lat1
        t = lat2;
        lat2 = lat1;
        lat1 = t;
    end
end

h = self.Config.height;                   %轨道高度,单位是m
beamForward = self.Config.rangeOfBeam(1);                 %大的那个角度 
beamLeft = self.Config.rangeOfBeam(2);                    %小的那个角度
halfForward = h * tan(beamForward);                 %卫星照射长方形的长的一半
halfLeft = h * tan(beamLeft);                       %卫星照射长方形的宽的一半

[satNum,timeNum,~] = size(self.SatPosition);        %获得一下时间总数和卫星总数
tempVisibleSat = zeros(satNum,timeNum - 1,2);       %赋值到卫星的坐标
[triNum,~] = size(self.SeqDiscrArea);               %获得三角形总数

%用flag来分情况,一共2种情况：1正常计算；0对称法
if lon2 < lon1                                      %区域跨过180的话要对称
    flag = 0;                                       %flag为0的情况表示要使用对称法
else
    flag = 1;                                       %flag为1的话就正常计算
end

tempCrust = sqrt(halfForward^2+halfLeft^2)*0.00001;
if lon1 - tempCrust <-180 || lon2 +tempCrust>180
    if lon1 - tempCrust <-180 && lon2 +tempCrust>180    %排除考察区域很长的情况
    else
        flag =0;                                        %大区域过180线了，也用对称法
    end
end

% %算一下中间线的经度
% if lon1 < lon2                             %没有跨过180
%     midLon = (lon1+lon2)/2;
% else
%     deltaLon = 360 - lon1 + lon2;          %跨过了180
%     if 180-lon1 > lon2-(-180)
%         midLon = lon1 + deltaLon/2;
%     else 
%         midLon = lon2- deltaLon/2;
%     end
% end

% R=self.rOfearth;                         %地球半径
% N=self.FactorOfDiscr;                         %区域总行数
% triH = tools.LatLngCoordi2Length([midLon,lat1],[midLon,lat2],R)/N;%三角形的高度，单位是m
% interval = ceil( 2 * halfLeft/triH);          %间隔，计算方法：卫星照射长方形的宽/三角形高度
hOfDiscr = tools.LatLngCoordi2Length([0 0], [0 1], self.rOfearth)/self.Config.factorOfDiscr;
interval = ceil(2*tools.getEarthLength(self.Config.rangeOfBeam(2)*2, h)/hOfDiscr);

tempSatNum = zeros(satNum,1);                   %暂时存一下卫星编号,如果已经是找到可见了，补充计算的时候就不考虑这个卫星了

%% flag = 1正常计算情况下的可见卫星
if flag == 1
    bjLarge = [lon1 - tempCrust,lon2 + tempCrust;
    lat1 - tempCrust/1.1,lat2 + tempCrust/1.1];     %有可能会被可见的大区域
    for i = 1 : timeNum - 1                         %遍历所有时刻，还要用下一时刻判断卫星运行方向，所以timeNum-1 
        triDot = zeros(ceil(triNum/interval),1);    %用来存当前时刻考察三角形的可见卫星
        for j = 1 : satNum                          %遍历卫星
            if self.SatPosition(j,i,1) ~= 500
                if self.SatPosition(j,i,1) >= bjLarge(1,1) && self.SatPosition(j,i,1) <= bjLarge(1,2) && self.SatPosition(j,i,2) >= bjLarge(2,1) && self.SatPosition(j,i,2) <= bjLarge(2,2)
                    satRec = findSatRec(beamForward, beamLeft, self.SatPosition(j,i,2), self.SatPosition(j,i+1,2), self.SatPosition(j,i,1),self.SatPosition(j,i+1,1));%获得卫星覆盖的那个矩形
                       for m = 1 : interval : triNum
                        dotCoord = self.SeqDiscrArea(m,:);
                        in= calcuIN(satRec,dotCoord);
                            if in ==1
                                triDot(1 + (m-1)/interval,1) = j;
                                tempSatNum(j,1) = 1;
                                tempVisibleSat(j,i,1) = self.SatPosition(j,i,1);
                                tempVisibleSat(j,i,2) = self.SatPosition(j,i,2);
                                %fprintf('%d\n',j);
                                %在的话就存坐标
                                break;
                            else
                                tempVisibleSat(j,i,1) = 500;
                                tempVisibleSat(j,i,2) = 500;
                            end                        
                       end
                else
                    tempVisibleSat(j,i,1) = 500;
                    tempVisibleSat(j,i,2) = 500;
                end
            else
                    tempVisibleSat(j,i,1) = 500;
                    tempVisibleSat(j,i,2) = 500;                
            end
        end
        %补充计算
        for k = 2 : ceil(triNum/interval)
            if(triDot(k-1,1)==0 && triDot(k,1)>0) || (triDot(k-1,1)>0 && triDot(k,1) > 0 && triDot(k-1,1) ~= triDot(k,1))%满足了补充判断的条件
                for j = 1 : satNum
                    if self.SatPosition(j,i,1) ~= 500
                        if tempSatNum(j,1) == 0 %刚刚找下来可见的，就不用再判断了
                            if self.SatPosition(j,i,1) >= bjLarge(1,1) && self.SatPosition(j,i,1) <= bjLarge(1,2) && self.SatPosition(j,i,2) >= bjLarge(2,1) && self.SatPosition(j,i,2) <= bjLarge(2,2)
                            satRec = findSatRec(beamForward, beamLeft, self.SatPosition(j,i,2), self.SatPosition(j,i+1,2), self.SatPosition(j,i,1),self.SatPosition(j,i+1,1));%获得卫星覆盖的那个矩形
                                for m = (k-2)*interval +2  : (k-1)*interval
                                    dotCoord = self.SeqDiscrArea(m,:);
                                    in= calcuIN(satRec,dotCoord);
                                    if in ==1
                                        %fprintf('other:%d\n',j);
                                        tempVisibleSat(j,i,1) = self.SatPosition(j,i,1);
                                        tempVisibleSat(j,i,2) = self.SatPosition(j,i,2);
                                        break;
                                    end                        
                                end
                            end
                        end
                    else
                        tempVisibleSat(j,i,1) = 500;
                        tempVisibleSat(j,i,2) = 500;
                    end
                end
            end
        end
%         if ifDebug == 1
%             fprintf('计算每快照可视卫星%f%%\n',i*100/(timeNum - 1));            
%         end
        %fprintf('计算每快照可视卫星%f%%\n',((i-1)*satNum+j)*100/(satNum*(timeNum - 1)));
    end
end

%% flag = 0 用对称法计算可见卫星
if flag == 0
    lon1 = sign(lon1)*180 - lon1;lon2 = sign(lon2)*180 - lon2;%将测试区域对称，对称规则：纬度不变，经度对称到0°线，直接正常对称，不交叉
    bjLarge = [lon1 + tempCrust,lon2 - tempCrust;
    lat1 - tempCrust/1.1,lat2 + tempCrust/1.1];               %有可能会被可见的大区域
    SatPosition(:,:,1) = sign(self.SatPosition(:,:,1))*180 - self.SatPosition(:,:,1);%把卫星运行的星下点对称
    SatPosition(:,:,2) = self.SatPosition(:,:,2);
    for i = 1 : timeNum - 1                                   %还要用下一时刻判断卫星运行方向，所以timeNum-1
        SeqDiscrArea(:,1) = sign(self.SeqDiscrArea(:,1))*180 - self.SeqDiscrArea(:,1);%把离散三角形的中心点都对称
        SeqDiscrArea(:,2) = self.SeqDiscrArea(:,2);
        triDot = zeros(ceil(triNum/interval),1);              %用来存当前时刻每个三角形的可见卫星
        for j = 1 : satNum                                    %遍历卫星
            if self.SatPosition(j,i,1) ~= 500            
                if SatPosition(j,i,1) <= bjLarge(1,1) && SatPosition(j,i,1) >= bjLarge(1,2) && SatPosition(j,i,2) >= bjLarge(2,1) && SatPosition(j,i,2) <= bjLarge(2,2)
                    satRec = findSatRec(beamForward, beamLeft, SatPosition(j,i,2), SatPosition(j,i+1,2), SatPosition(j,i,1),SatPosition(j,i+1,1));%获得卫星覆盖的那个矩形                   
                        for m = 1 : interval : triNum                       
                        dotCoord = SeqDiscrArea(m,:);
                        in= calcuIN(satRec,dotCoord);
                            if in ==1
                                triDot(1 + (m-1)/interval,1) = j;
                                tempSatNum(j,1) = 1;
                                tempVisibleSat(j,i,1) = self.SatPosition(j,i,1);
                                tempVisibleSat(j,i,2) = self.SatPosition(j,i,2);
                                %在的话就存坐标
                                break;
                            else
                                tempVisibleSat(j,i,1) = 500;
                                tempVisibleSat(j,i,2) = 500;
                            end                        
                        end
                else
                    tempVisibleSat(j,i,1) = 500;
                    tempVisibleSat(j,i,2) = 500;
                end
            else
                    tempVisibleSat(j,i,1) = 500;
                    tempVisibleSat(j,i,2) = 500;
            end
        end 
        %补充计算
        for k = 2 : ceil(triNum/interval)
            if(triDot(k-1,1)==0 && triDot(k,1)>0) || (triDot(k-1,1)>0 && triDot(k,1) > 0 && triDot(k-1,1) ~= triDot(k,1))%满足了补充判断的条件
                for j = 1 : satNum
                    if self.SatPosition(j,i,1) ~= 500
                        if tempSatNum(j,1) ~= 0 %刚刚找下来可见的，就不用再判断,关键是要去补充
                        else
                            if SatPosition(j,i,1) <= bjLarge(1,1) && SatPosition(j,i,1) >= bjLarge(1,2) && SatPosition(j,i,2) >= bjLarge(2,1) && SatPosition(j,i,2) <= bjLarge(2,2)
                            satRec = findSatRec(beamForward, beamLeft, SatPosition(j,i,2), SatPosition(j,i+1,2), SatPosition(j,i,1),SatPosition(j,i+1,1));%获得卫星覆盖的那个矩形
                                for m = (k-2)*interval +2  : (k-1)*interval
                                    dotCoord = SeqDiscrArea(m,:);
                                    in= calcuIN(satRec,dotCoord);
                                    if in ==1
                                        tempVisibleSat(j,i,1) = self.SatPosition(j,i,1);
                                        tempVisibleSat(j,i,2) = self.SatPosition(j,i,2);
                                        %fprintf('%d\n',j);
                                        %在的话就存坐标
                                        break;
                                    end                        
                                end
                            end
                        end
                    else
                        tempVisibleSat(j,i,1) = 500;
                        tempVisibleSat(j,i,2) = 500;
                    end
                end
            end
        end
%         if ifDebug == 1
%            fprintf('计算每快照可视卫星%f%%\n',i*100/(timeNum - 1));
%         else
% %             tmpStr = num2str(i*100/(timeNum - 1));
% %             tmpstr_s = '计算每快照可视卫星';
% %             tmpStr = strcat(tmpStr, '%');
% %             tmpStr = strcat(tmpstr_s, tmpStr);
% %             app.MonitorPrint(2, tmpStr); 
%         end
        %fprintf('计算每快照可视卫星%f%%\n',((i-1)*satNum+j)*100/(satNum*(timeNum - 1)));
    end

end

self.VisibleSat = tempVisibleSat;

end

%% 该函数用于查找卫星照射矩形的四个顶点的坐标
function satRec = findSatRec(Forward, Left, satLat1, satLat2, satLon1, satLon2)

beamForward = Forward + 10*pi/180; 
beamLeft = Left + 10*pi/180;%波束扫描角
h = 508*1000;%轨道高度

halfForward = h * tan(beamForward);
halfLeft = h * tan(beamLeft);

satMove = [satLat2 - satLat1, satLon2 - satLon1];%卫星运行方向向量
latVecRight = [1,0];%纬线方向向量，向右的
latVecLeft = [-1,0];%纬线方向向量，向左的

alpha = min(acos(dot(satMove,latVecRight)/norm( satMove)/norm(latVecRight)),acos(dot(satMove,latVecLeft)/norm( satMove)/norm(latVecLeft)));%纬线和卫星运行方向角度
beta = pi/2-alpha;

satDiamd = zeros(4,2);%存卫星那个内接菱形的顶点坐标，1是纬度，反掉了
satDiamd(1,:) = [satLat1 + sign(satMove(1))*halfForward*sin(alpha)/1.1*0.00001, satLon1 + sign(satMove(2))*halfForward*cos(alpha)*0.00001];%前向的坐标
satDiamd(3,:) = [2*satLat1 - satDiamd(1,1), 2*satLon1 - satDiamd(1,2)];%1,3行是前后项的坐标
satDiamd(2,:) = [satLat1 + (-1)*sign(satMove(1))*halfLeft*sin(beta)/1.1*0.00001,satLon2 + sign(satMove(2))*halfLeft*cos(beta)*0.00001];
satDiamd(4,:) = [2*satLat1 - satDiamd(2,1), 2*satLon1 - satDiamd(2,2)];%2，4行是左右向的坐标

satRec = zeros(4,2);%存卫星波束矩形范围的顶点坐标
for i = 1 : 4
    if  i == 4
        satRec(i,2) = satDiamd(i,1) + satDiamd(1,1) - satLat1;%这时候是用1存的是经度
        satRec(i,1) = satDiamd(i,2) + satDiamd(1,2) - satLon1;
    else
        satRec(i,2) = satDiamd(i,1) + satDiamd(i+1,1) - satLat1;
        satRec(i,1) = satDiamd(i,2) + satDiamd(i+1,2) - satLon1;
    end
end

end

%% 判断点是否在某矩形内
function in= calcuIN(satRec,dotCoord)

if getCross(satRec(1,:),satRec(2,:),dotCoord) * getCross(satRec(3,:),satRec(4,:),dotCoord) >= 0 && getCross(satRec(2,:),satRec(3,:),dotCoord) * getCross(satRec(4,:),satRec(1,:),dotCoord) >= 0
    in = 1;
else
    in = 0;
end

%in = inpolygon(dotLat,dotLon,[satRec(1,1),satRec(2,1),satRec(3,1),satRec(4,1)],[satRec(1,1),satRec(2,2),satRec(3,2),satRec(4,2)]);

end

%% 叉乘
function result = getCross(p1,p2,p)
%利用利用叉乘的方向性，来判断夹角是否超过了180度以判断是否在矩形内
result = (p2(1,1) - p1(1,1)) * (p(1,2) - p1(1,2)) -(p(1,1) - p1(1,1)) * (p2(1,2) - p1(1,2));
end