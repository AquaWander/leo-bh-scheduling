function generateUsrsTraffic(self)
%GENERATEUSRSTRAFFIC 生成用户业务
    methods.UsrsTraffic_Method(self.interface);
end

