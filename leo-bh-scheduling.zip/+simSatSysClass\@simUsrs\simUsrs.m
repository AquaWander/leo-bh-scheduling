% Author:Zhang
% 2022/9/14
%%
classdef ( ...
        Abstract = false,...            % 不是抽象类
        ConstructOnLoad = true,...      % 必须要有构造函数
        HandleCompatible = false,...    % 值型的类
        Sealed = false...               % 可以被子类继承
          ) simUsrs
%% 公有属性    
    properties
        position    % 位置
        ordOfDiscr  % 所属三角形在SeqDiscrArea的编号
        homeSat     % 归属卫星
        homeSig     % 归属信令波位在signalOfArea的编号
    
%         measureSINR % 接入时测量的SINR（dB）,向量，长度为一个快照下的调度周期数量
        SCS         % 子载波间隔（kHz）
        
        % 多域资源需要优化的
        BandWidth   % 被分配到的带宽（MHz）
        Band %被分配到的频带，1*2数组（MHz）
%         Power % 被分到的功率
        PowerPercent % 分配功率的比例

        SlotInSche  % 调度周期的时隙数
        timeInSlot  % 时隙的时长（s）

        CurLinkRate % 当前链路速率（bps）
        CurLinkNRB  % 当前链路一个slot（且一个波束）可传输最大NRB数

        Buffer      % 剩余总排队业务量（bit）,向量，长度为一个快照下的调度周期数量
        GenerTraffic  % 当次生成业务量（bit）,向量，长度为一个快照下的调度周期数量
        TransTraffic  % 当次调度传输业务量（bit）,向量，长度为一个快照下的调度周期数量

        Pt_dBm  % dBm
        T_noise % K
        F_noise % dB
    end
%% 方法签名
    methods
        function self = simUsrs()
            %SIMUSRS 构造函数
            %
%             self.BandWidth = BandWidth;
%             self.SCS = SCS;
        end
        getCurLinkRate(self, measureSINR) % 获得当前链路速率（香农公式计算）
        self = getCurLinkNRB(self)  % 获得当前链路可传输最大NRB数（全链路的总容量,一个slot内）
%         getCurTransRB(self)  % 获得当前调度周期传输的业务RB数
        
    end
end

