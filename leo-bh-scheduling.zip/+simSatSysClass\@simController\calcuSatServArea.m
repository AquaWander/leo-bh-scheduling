% 2023/03/16
% 计算self.DiscrArea区域内可见卫星服务范围并判断用户所属
%%
function calcuSatServArea(self, OrderOfVisibleSat, IdxOfStep, MC_idx)
    ifDebug = self.ifDebug;

    numOfusrs = self.numOfUsrs_all;%获得大区域里所有的用户数

    % 生成VisibleSat_s，前两列是可见卫星的经纬度，第三列是其编号
    NumOfVisibleSat = length(OrderOfVisibleSat);
    tempVisibleSat_s = zeros(NumOfVisibleSat,3);    
    tempVisibleSat_s(:,1:2) = self.VisibleSat(OrderOfVisibleSat, IdxOfStep, :);
    tempVisibleSat_s(:,3) = OrderOfVisibleSat;

    % 生成SatServCur
    tempOfNum = zeros(NumOfVisibleSat, 1); % 统计各星下小三角形数量
    tempSeqDiscrArea = self.SeqDiscrArea;%离散小三角形的中心点坐标
    tempSatServCur = zeros(length(self.SeqDiscrArea(:,1)), 3);%存储离散小三角形所属得卫星
    tempSatServCur(:,1:2) = self.SeqDiscrArea;%前两列是经纬度，第三列是卫星编号
   
    [rawNum, colNum, ~] = size(self.DiscrArea);%离散三角形的行列数
    hOfDiscr = tools.LatLngCoordi2Length([0 0], [0 1], self.rOfearth)/self.Config.factorOfDiscr;%每个三角形的高度
    interval = ceil(2*tools.getEarthLength(self.Config.rangeOfBeam(2)*2, self.Config.height)/hOfDiscr/8);%考察间隔

    ServSatOfDiscrAreaCur = zeros(rawNum, colNum);%每个小三角形的所属卫星

    for i = 1 : rawNum%遍历行
        last_q = 0;%如果q == last_q说明没找到？
        for j = 1 : interval : colNum%间隔遍历列
            seq = simSatSysClass.tools.ij2Seq(i, j, rawNum, colNum);%计算当前ij在离散三角形中的编号
            q = findShortest(...
                tempSeqDiscrArea(seq, :),...
                tempVisibleSat_s(:, 1:2)...
                );%找到最近的卫星
            if j ~= 1%补充计算？
                if q ~= last_q
                    for k = j-interval+1 : j
                        seq = simSatSysClass.tools.ij2Seq(i, k, rawNum, colNum);
                        q = findShortest(...
                            tempSeqDiscrArea(seq, :),...
                            tempVisibleSat_s(:, 1:2)...
                            );%这个q的编号是在可见卫星矩阵里的号，所以要用第三列去获得他在1800里的编号
                        tempSatServCur(seq, 3) = tempVisibleSat_s(q, 3);%在第三列存入卫星编号
                        tempOfNum(q) = tempOfNum(q) + 1; 
                    end
                    last_q = q;
                else
                    for k = j-interval+1 : j
                        seq = simSatSysClass.tools.ij2Seq(i, k, rawNum, colNum);
                        tempSatServCur(seq, 3) = tempVisibleSat_s(q, 3);
                        tempOfNum(q) = tempOfNum(q) + 1; 
                    end                    
                end              
            else
                tempSatServCur(seq, 3) = tempVisibleSat_s(q, 3);
                tempOfNum(q) = tempOfNum(q) + 1;
                last_q = q;
            end
            if colNum - j < interval
                for k = j+1 : colNum
                    seq = simSatSysClass.tools.ij2Seq(i, k, rawNum, colNum);
                    q = findShortest(...
                        tempSeqDiscrArea(seq, :),...
                        tempVisibleSat_s(:, 1:2)...
                        );                
                    tempSatServCur(seq, 3) = tempVisibleSat_s(q, 3);
                    tempOfNum(q) = tempOfNum(q) + 1;
                end
            end
        end 
    end
    for j = 1:colNum
        for i = 1:rawNum
            ServSatOfDiscrAreaCur(i, j) = tempSatServCur((j-1)*rawNum+i, 3);
        end
    end
    self.ServSatOfDiscrAreaCur = ServSatOfDiscrAreaCur;    
    if ifDebug == 1
        if self.Config.numOfMonteCarlo == 0
            fprintf('第%d快照可见卫星服务范围判定已完成\n', IdxOfStep);        
        else
            fprintf('蒙特卡洛第%d次第%d快照可见卫星服务范围判定已完成\n', MC_idx, IdxOfStep);     
        end
    end  
    % 创建服务卫星对象数组            
    tempNumOfVisibleSat = NumOfVisibleSat;
    for p = 1 : NumOfVisibleSat
        if tempOfNum(p) == 0
            tempNumOfVisibleSat = tempNumOfVisibleSat - 1;
        end
    end 
    NumOfServSat = tempNumOfVisibleSat;
    OrderOfServSat = OrderOfVisibleSat(tempOfNum ~= 0);
    self.OrderOfServSatCur = OrderOfServSat;
    self.SatObj = simSatSysClass.simSatellite.empty(NumOfServSat, 0); 
    for i = 1 : NumOfServSat
        self.SatObj(i).position = self.VisibleSat(OrderOfServSat(i), IdxOfStep, :);       
        self.SatObj(i).nextpos = self.SatPosition(OrderOfServSat(i),IdxOfStep+1,:);
        self.SatObj(i).order = OrderOfServSat(i);   
        self.SatObj(i).Pt_dBm_serv = self.Config.Pt_dBm_serv;
        self.SatObj(i).Pt_dBm_signal = self.Config.Pt_dBm_signal;
        self.SatObj(i).T_noise = self.Config.SAT_T_noise;
        self.SatObj(i).F_noise = self.Config.SAT_F_noise;
%         self.SatObj(i).ScheOfSig = self.Config.ScheOfSig;
%         self.SatObj(i).LightTimeOfSig = self.Config.LightTimeOfSig;
%         self.SatObj(i).SatAntenna = self.Communication.SatAntenna;
%         self.SatObj(i).freqOfServ = self.Communication.freqOfServ;
%         self.SatObj(i) = self.SatObj(i).initialAntenna();
    end
    % 告知卫星自己的服务范围
    for k = 1 : NumOfServSat
        self.SatObj(k).servTri = find(tempSatServCur(:,3) == OrderOfServSat(k));  
    end
    if ifDebug == 1
        if self.Config.numOfMonteCarlo == 0
            fprintf('第%d快照各卫星对象创建已完成\n', IdxOfStep); 
        else
            fprintf('蒙特卡洛第%d次第%d快照各卫星对象创建已完成\n', MC_idx, IdxOfStep);
        end
    end 
    % 判断用户归属卫星Usr2SatCur
    self.Usr2SatCur = zeros(numOfusrs, 1+self.numOfMethods_BeamGenerate,self.scheInShot);
    tempS2U = zeros(NumOfServSat, numOfusrs);
    for g = 1 : numOfusrs
        self.Usr2SatCur(g, 1, :) = tempSatServCur(self.UsrsPosition(g,3), 3);
%         self.Usr2SatCur(g) = tempSatServCur(self.UsrsObj(g).ordOfDiscr, 3); 
%         self.UsrsObj(g).homeSat = self.Usr2SatCur(g, 1);
        tempS2U(OrderOfServSat==self.Usr2SatCur(g,1,1), g) = 1;
    end
    % 告知卫星其服务用户是哪些
    for k = 1 : NumOfServSat
        temp = tempS2U(k, :);
        self.SatObj(k).servUsr = find(temp == 1);
        self.SatObj(k).numOfusrs = length(self.SatObj(k).servUsr);
    end
    if ifDebug == 1
        if self.Config.numOfMonteCarlo == 0
            fprintf('第%d快照建立用户与卫星的映射已完成\n', IdxOfStep); 
        else
            fprintf('蒙特卡洛第%d次第%d快照建立用户与卫星的映射已完成\n', MC_idx, IdxOfStep); 
        end 
    end
end

%% 找到距离最近的点
function Satpos = findShortest(pos, SatposSet)
% pos 考察坐标
% SatposSet 卫星坐标集合
    R = 6371.393e3; % 地球半径

    lngA = pos(1);
    alpha1 = lngA * pi / 180;
    latA = pos(2);
    beta1 = latA * pi / 180;

    num = length(SatposSet(:,1));
    len = zeros(num,1);%可见卫星个数
    for i = 1 : num
        lngB = SatposSet(i, 1);
        alpha2 = lngB * pi / 180;
        latB = SatposSet(i, 2);
        beta2 = latB * pi / 180;
        len(i) = R * acos(cos(pi/2-beta2)*cos(pi/2-beta1) + sin(pi/2-beta2)*sin(pi/2-beta1)*cos(alpha2-alpha1));
    end
    Satpos = find(len == min(len), 1);
end
