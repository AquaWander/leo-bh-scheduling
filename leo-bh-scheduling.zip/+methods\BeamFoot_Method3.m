function BeamFoot_Method3(interface)
%BEAMFOOT_METHOD2 
%   

end

