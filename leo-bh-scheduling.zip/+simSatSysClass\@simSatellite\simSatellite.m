% Author:Zhang
% 2021/12/21
%%
classdef ( ...
        Abstract = false,...            % 不是抽象类
        ConstructOnLoad = true,...      % 必须要有构造函数
        HandleCompatible = false,...    % 值型的类
        Sealed = false...               % 可以被子类继承
          ) simSatellite
%% 公有属性
    properties (Access = public)  
        order % 编号
        position % 经纬坐标
        nextpos % 下一step坐标
        servTri % 所服务的三角形编号，size是星下三角形总数

        servUsr % 星下用户编号
        numOfusrs % 星下用户数量
        Neighbor % 相邻卫星编号，Neighbor(k,:)表示当前卫星的第k层邻居卫星的编号集合

        numOfsigbeam % 星下信令波位数量
        IdxOfsigbeam % 星下信令波位在signalOfArea的目录索引 
        SeqOfsigbeam % 星下信令波位在全球的原始编号
        SpanIDXOfsigbeam % 用于星下信令扫描的信令波位编号
        SeqInSpanOfsigbeam  % 信令波位的扫描顺序，矩阵，格式为"numOfsigbeam × ceil(length(SpanIDXOfsigbeam)/numOfsigbeam)"
        ScheOfSig   % 信令扫描周期
        LightTimeOfSig   % 信令注视时长
        SignalBeamfoot % 信令波位
            % SignalBeamfoot(k).servTri 波位k下的三角形编号，size是波位三角形总数
            % SignalBeamfoot(k).centerTri 波位k的中心三角形编号
            % Signaleamfoot(k).usrs 波位k的用户编号  
        TableOfSig  % 矩阵，格式为"信令波束数量×一快照有多少slot"

        egdeSig  % 当前step的边缘信令波位序列，格式为"numOfSat × numOfSigInSat"
                 % egdeSig(k,j)=1表示当前卫星的第j个信令波位与SatObj(k)卫星交叉
        egdeSigSeq  % 储存边缘信令波位的signalOfArea编号
            
        numOfbeam  % 星下波位数量，向量，长度为NumOfSche，numOfbeam(p)表示第p次调度的波位数量
        beamfoot   % 结构体矩阵，格式为"NumOfSche × MAXNumOfBeamFoot" 

        BHST % 矩阵，格式为"NumOfServBeam × SlotInShot"
    
        numOfbeam_method0   % 星下波位数量，向量，长度为NumOfSche，numOfbeam(p)表示第p次调度的波位数量
        beamfoot_method0    % 结构体矩阵，格式为"NumOfSche × MAXNumOfBeamFoot"
                            % beamfoot(p, k).position 第p次调度波位k的中心坐标
                            % beamfoot(p, k).usrs 第p次调度波位k的用户编号
                            % beamfoot(p, k).servTri 第p次调度波位k的三角形们
        
        numOfbeam_method1   % 可加载波位形成算法1
        beamfoot_method1    % 可加载波位形成算法1

        numOfbeam_method2   % 可加载波位形成算法2
        beamfoot_method2    % 可加载波位形成算法2

        numOfbeam_method3   % 可加载波位形成算法3
        beamfoot_method3    % 可加载波位形成算法3

        numOfbeam_method4   % 可加载波位形成算法4
        beamfoot_method4    % 可加载波位形成算法4 

        BHST_combi_0    % 跳波束计划表，矩阵"NumOfServBeam × SlotInShot"
        BHST_combi1_0
        
        BHST_combi_5    % 可加载BHST形成算法1与波位形成算法0的组合
        BHST_combi_10   % 可加载BHST形成算法2与波位形成算法0的组合
        BHST_combi_15   % 可加载BHST形成算法3与波位形成算法0的组合
        BHST_combi_20   % 可加载BHST形成算法4与波位形成算法0的组合
        Pt_Antenna_combi_0    % 功率分配计划表，矩阵"NumOfServBeam × SlotInShot"
        Pt_Antenna_combi_5   
        Pt_Antenna_combi_10   
        Pt_Antenna_combi_15    
        Pt_Antenna_combi_20         

        BHST_combi_1     % 可加载BHST形成算法0与波位形成算法1的组合
        BHST_combi_6     % 可加载BHST形成算法1与波位形成算法1的组合
        BHST_combi_11    % 可加载BHST形成算法2与波位形成算法1的组合
        BHST_combi_16    % 可加载BHST形成算法3与波位形成算法1的组合
        BHST_combi_21    % 可加载BHST形成算法4与波位形成算法1的组合
        Pt_Antenna_combi_1    
        Pt_Antenna_combi_6   
        Pt_Antenna_combi_11   
        Pt_Antenna_combi_16    
        Pt_Antenna_combi_21 

        BHST_combi_2     % 可加载BHST形成算法0与波位形成算法2的组合
        BHST_combi_7     % 可加载BHST形成算法1与波位形成算法2的组合
        BHST_combi_12    % 可加载BHST形成算法2与波位形成算法2的组合
        BHST_combi_17    % 可加载BHST形成算法3与波位形成算法2的组合
        BHST_combi_22    % 可加载BHST形成算法4与波位形成算法2的组合
        Pt_Antenna_combi_2    
        Pt_Antenna_combi_7   
        Pt_Antenna_combi_12  
        Pt_Antenna_combi_17    
        Pt_Antenna_combi_22 

        BHST_combi_3     % 可加载BHST形成算法0与波位形成算法3的组合
        BHST_combi_8     % 可加载BHST形成算法1与波位形成算法3的组合
        BHST_combi_13    % 可加载BHST形成算法2与波位形成算法3的组合
        BHST_combi_18    % 可加载BHST形成算法3与波位形成算法3的组合
        BHST_combi_23    % 可加载BHST形成算法4与波位形成算法3的组合
        Pt_Antenna_combi_3   
        Pt_Antenna_combi_8  
        Pt_Antenna_combi_13  
        Pt_Antenna_combi_18    
        Pt_Antenna_combi_23

        BHST_combi_4     % 可加载BHST形成算法0与波位形成算法4的组合
        BHST_combi_9     % 可加载BHST形成算法1与波位形成算法4的组合
        BHST_combi_14    % 可加载BHST形成算法2与波位形成算法4的组合
        BHST_combi_19    % 可加载BHST形成算法3与波位形成算法4的组合
        BHST_combi_24    % 可加载BHST形成算法4与波位形成算法4的组合
        Pt_Antenna_combi_4   
        Pt_Antenna_combi_9  
        Pt_Antenna_combi_14  
        Pt_Antenna_combi_19   
        Pt_Antenna_combi_24

        Pt_dBm_serv     % dBm 
        Pt_dBm_signal   % dBm 
        T_noise         % K
        F_noise         % dB

        BeamPoint % 波束指向角
        LightBeamfoot % 点亮的波位编号
        LightSig % 点亮的信令波位编号

        % 新增
        PowerTable % 功率分配表
        LightPower %当前时隙的功率分配

    end
%% 公有方法
    methods (Access = public)
        % 构造函数
        function self = simSatellite()
            
        end
        % 方法签名       
        
        G = getSatAntennaServG(self, varTheta, varPhi, BfIdx, freq) % 天线增益
        G = getSatSigServG(self, varTheta, varPhi, BfIdx, freq) % 天线增益
    end


end