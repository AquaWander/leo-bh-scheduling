% 2023/03/14
% 根据参数WrapExtendValue和WrapAroundLayer寻找wrapAround大区域的边界坐标
% 输出self.wrapRange
%%
function findWrap(self)
% 根据考察区域范围和边缘效应系数，找到大框的坐标
% 是根据我设定的那个经纬度
% 不是直接经纬度相加减，而是利用考察区域中心点的距离获得wrap左上角和右下角的经纬度坐标

%% 找纬度
index = self.Config.WrapAroundLayer + 1;

h = self.Config.height;                   %轨道高度,单位是m
beamForward = self.Config.rangeOfBeam(1);  %大的那个角度 
halfForward = h * tan(beamForward);                 %卫星照射长方形的长的一半
deltaLat = acos(1-2*(sin(halfForward/2/6371.393e3))^2)*180/pi;

lat1 = min(self.Config.rangeOfInves(2,:)) - index*self.Config.WrapExtendValue;%第一个纬度是小的
lat2 = max(self.Config.rangeOfInves(2,:)) + index*self.Config.WrapExtendValue;%第二个纬度是大的
% 防止因为扩充框导致超出了卫星的一定覆盖范围纬度范围
if lat2 > min(max(max(self.SatPosition(:,:,2)))+deltaLat,90)%这个纬度范围怎么设置比较好？
    lat2 = min(max(max(self.SatPosition(:,:,2)))+deltaLat,90);
end
if lat1 < (-1) * min(max(max(self.SatPosition(:,:,2)))+10,90)
    lat1 = (-1) * min(max(max(self.SatPosition(:,:,2)))+10,90);
end

%% 找经度

% 先进行预计算
lon1 = self.Config.rangeOfInves(1,1) - index*self.Config.WrapExtendValue;
lon2 = self.Config.rangeOfInves(1,2) + index*self.Config.WrapExtendValue;
%一些更正
if lon1 < -180 && lon2 > 180
    lon1 = -180;
    lon2 = 180;
elseif lon1 < -180
    lon1 = 180 - (-180 - lon1);
elseif lon2 > 180
    lon2 = -180 + (lon2 - 180);%好像不需要交换lon1和lon2
end

% 获得考察区域中心点的经纬度坐标，第一个是经度，第二个是纬度
Range = self.Config.rangeOfInves';
if Range(1,1) < Range(2,1) %经度增大的正方向，不会跨过180
    midLon = (Range(1,1)+Range(2,1))/2;
else
    deltaLon = 360 - Range(1,1) + Range(2,1);%跨过180
    if 180-Range(1,1) > Range(2,1)-(-180)
        midLon = Range(1,1) + deltaLon/2;
    else 
        midLon = Range(2,1) - deltaLon/2;
    end 
end

midLat = (Range(1,2) + Range(2,2))/2;

% 根据距离获得wrap的起止经度
dist = tools.LatLngCoordi2Length([midLon midLat], [lon1 midLat], self.rOfearth);%举行横长的一半

lon11 = tools.d2Lon(lat2,midLon,-dist);
lon22 = tools.d2Lon(lat2,midLon,dist);

self.wrapRange = [lon11,lon22;lat1,lat2];

end

