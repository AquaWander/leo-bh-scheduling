function PowerAllocation_Method(interface)
% 本函数用于根据BHST，对波束间注水分配功率
bhLength = interface.SlotInSche; % 一次跳波束调度长度
heightOfsat = interface.height;%卫星轨道高度
BW = interface.BandOfLink*1e6; % 带宽，单位是Hz
freqOfDownLink = interface.freqOfDownLink; % (Hz) 卫星的下行链路中心频点，波束间全频复用
startOfBand = freqOfDownLink - BW / 2;% (Hz) 卫星的下行链路开始频点
K = 1.38e-23;  % 玻尔兹曼常量
Ta_usr = interface.Config.Usr_T_noise;
F_usr = interface.Config.Usr_F_noise;
for satIdx = 1 : length(interface.OrderOfServSatCur)
    % 卫星位置
    curSatPos = interface.SatObj(satIdx).position;
    satPosInDescartes = LngLat2Descartes(curSatPos, heightOfsat);
    curSatNextPos = interface.SatObj(satIdx).nextpos;
    %计算卫星总功率
    Pt_sat = interface.SatObj(satIdx).Pt_dBm_serv; % 卫星天线总的发射功率
    Pt_sat = (10.^(Pt_sat/10))/1e3; %单位是W

    BHST = interface.tmpSat(satIdx).BHST;
    totalSlots = length(BHST(1,:));
    maxBeam = length(BHST(:,1));

    PtTable = zeros(maxBeam, totalSlots);

    for slotIdx = 1 : totalSlots
        % 当前调度周期编号
        scheIdx = ceil(slotIdx / bhLength);
        % 看当前点亮了哪些波位
        allBeamfoot = (BHST(: , slotIdx) ~= 0);
        allBeamfoot = BHST(allBeamfoot , slotIdx);
        NumOfLightBeamfoot = length(allBeamfoot);
        if ~isempty(allBeamfoot)
            h = zeros(1, NumOfLightBeamfoot);
            lightPower = Pt_sat / NumOfLightBeamfoot;

            % 计算所有指向
            PosOfBeam = zeros(NumOfLightBeamfoot, 2);    % 点亮波位中心三角形坐标 
            for bidx = 1 : NumOfLightBeamfoot
                PosOfBeam(bidx, :) = interface.tmpSat(satIdx).beamfoot(scheIdx, allBeamfoot(bidx)).position; 
            end

            BeamPoint = zeros(NumOfLightBeamfoot, 2); % varphi(俯仰，偏离x轴),vartheta(方向，偏离xOy平面),天线在zOy平面(右手系)
            for j = 1 : NumOfLightBeamfoot
                [outputTheta, outputPhi] = tools.getPointAngleOfUsr(...
                    curSatPos, curSatNextPos, PosOfBeam(j, :), heightOfsat);
                BeamPoint(j,1) = outputPhi;
                BeamPoint(j,2) = outputTheta;
            end

            for footIdx = 1 : length(allBeamfoot)
                curFoot = allBeamfoot(footIdx);
                % 获得当前波位的用户
                orderOfUsrs = interface.tmpSat(satIdx).beamfoot(scheIdx, curFoot).usrs;
                % 然后计算这些波位的h
                curH = 0;
                for usrIdx = 1 : length(orderOfUsrs)
                    curUser = orderOfUsrs(usrIdx);

                    tmpBand = interface.UsrsObj(find(interface.OrderOfSelectedUsrs == curUser)).Band(slotIdx, :);

                    [~, thisH] = CaculateR(satIdx, scheIdx, slotIdx, curUser, curFoot, allBeamfoot, lightPower, BeamPoint, tmpBand, interface);

                    curH = curH + thisH;            
                end
                h(footIdx) = curH / length(orderOfUsrs);
            end

%             for footIdx = 1 : length(allBeamfoot)
%                 curFoot = allBeamfoot(footIdx);
%                 % 获得当前波位的用户
%                 orderOfUsrs = interface.tmpSat(satIdx).beamfoot(scheIdx, curFoot).usrs;
%                 % 当前波位的指向
%                 BeamPoint = zeros(1,2);
%                 curBeamPos = interface.tmpSat(satIdx).beamfoot(scheIdx, curFoot).position;
%                 [outputTheta, outputPhi] = tools.getPointAngleOfUsr(...
%                         curSatPos, curSatNextPos, curBeamPos, heightOfsat);
%                 BeamPoint(1) = outputPhi;
%                 BeamPoint(2) = outputTheta;
%                 % 然后计算这些波位的h
%                 curH = 0;
%                 subBandWidth = BW/length(orderOfUsrs);% 每个子带的宽度
%                 for usrIdx = 1 : length(orderOfUsrs)
%                     curUser = orderOfUsrs(usrIdx);
%                     curUserPos = interface.UsrsObj(curUser).position;
%                     usrPosInDescartes = LngLat2Descartes(curUserPos, 0);
%                     distance = sqrt((satPosInDescartes(1)-usrPosInDescartes(1)).^2 + ...
%                                     (satPosInDescartes(2)-usrPosInDescartes(2)).^2 + ...
%                                     (satPosInDescartes(3)-usrPosInDescartes(3)).^2);
% 
%                     tmpBand = interface.UsrsObj(curUser).Band(slotIdx, :);
% %                     tmpBand = [startOfBand + subBandWidth * (usrIdx - 1), startOfBand + subBandWidth * usrIdx];
%                     tmpFc = mean(tmpBand(1,:));
%     
%                     [UsrTheta, UsrPhi] = tools.getPointAngleOfUsr(curSatPos, curSatNextPos, curUserPos, heightOfsat);%计算方位角和仰角
%                     Gsat = antenna.getSatAntennaServG([UsrTheta, UsrPhi], [BeamPoint(2), BeamPoint(1)], tmpFc);
%                     Gusr = antenna.getUsrAntennaServG(0, tmpFc, false);                    
%     
%                     tempLambda = 3e8/tmpFc;
%                     N_noise_usr = (tmpBand(2) - tmpBand(1))*K*(Ta_usr+(F_usr-1)*300);                
%                     curH = curH + Gsat * Gusr * (tempLambda/(4*pi*distance))^2 / N_noise_usr;% Gt*Gr*(lambda/(4*pi*d))^2/N            
%                 end
%                 h(footIdx) = curH / length(orderOfUsrs);
%             end
    
            % 然后注水
            [allocPower, ~] = water_filling2(1./h, Pt_sat);

            % 然后获得这个时隙的PTable
            temp = find(BHST(: , slotIdx) ~= 0);
            for iii = 1 : length(allBeamfoot)
                PtTable(temp(iii), slotIdx) = allocPower(iii, iii);
            end
   
        end
        fprintf('第%d颗卫星波束内资源调度计算已完成%f%%\n',satIdx,slotIdx * 100 /totalSlots);
    end

    interface.tmpSat(satIdx).Pt_Antenna = PtTable;

    

end



end


%% 注水
function [palloc_matrix, allocPercentage] = water_filling1(loss, P)
% loss, Kx1向量，即L
% P, 要分配的总功率
% A, 对角阵，即权重alpha
% palloc_matrix, 对角阵，功率分配结果，迹等于P

	K = length(loss); % 用户数

    w = log(2) + zeros(1, K);
    
% 	w = diag(A); % width, 台阶宽度
	h = loss./w; % height, 台阶高度
%     h = loss;
	
    allo_set = 1:K; % 初始化要注水用户的索引集合
    level = (P+sum(loss(allo_set>0)))/sum(w(allo_set>0)); % “虚拟”水位线
    [h_hat, k_hat] = max(h(allo_set>0));
    
    while h_hat>=level
        
        allo_set(k_hat) = -1;
        level = (P+sum(loss(allo_set>0)))/sum(w(allo_set>0)); % “虚拟”水位线
        [h_hat, k_hat] = max(h(allo_set>0));
    
    end
    
    palloc_matrix = zeros(K);
    for k = 1:K
        if allo_set(k)>0
            palloc_matrix(k, k) = (level - h(k))*w(k);
        end
    end

    %我要获得的是比例
    allocPercentage = zeros(1, K);
    for k = 1 : K
        allocPercentage(k) = palloc_matrix(k, k) / P;
    end
    
end

function [palloc_matrix, allocPercentage] = water_filling2(loss, P)
% loss, Kx1向量，即L
% P, 要分配的总功率
% A, 对角阵，即权重alpha
% palloc_matrix, 对角阵，功率分配结果，迹等于P

	K = length(loss);
    
	w = 1/log(2) + zeros(1, K); % 台阶宽度
	h = loss./w; % 台阶高度
	
	[h_sorted, h_idx] = sort(h); % 根据台阶高度升序排序
	w_sorted = w(h_idx);
    
    % 线性搜索，从后往前确定最后一个需要注水的台阶
    for i = K:-1:1
        
        w_tmp = sum(w_sorted(1:i-1)); % 当前台阶前面所有台阶的宽度之和
        h_tmp = h_sorted(i); % 当前台阶的高度
        
        % 把当前台阶之前的台阶注水到与当前台阶同高还有剩余水
        if w_tmp*h_tmp-sum(h_sorted(1:i-1).*w_sorted(1:i-1))<P
            idx = i;
            break;
        end
        
    end
    
    w_filled = sum(w_sorted(1:idx)); % 需要注水的所有台阶的总宽度
    h_filled = (P+sum(h_sorted(1:idx).*w_sorted(1:idx)))/w_filled; % 最终的水位线
	
	p_allocate = zeros(1, K);
    p_allocate(1:idx) = w_sorted(1:idx).*(h_filled-h_sorted(1:idx));
	
    % 恢复原来顺序
    [~, back_idx] = sort(h_idx);
    p_allocate = p_allocate(back_idx);
    
    palloc_matrix = diag(p_allocate);

    %我要获得的是比例
    allocPercentage = zeros(1, K);
    for k = 1 : K
        allocPercentage(k) = palloc_matrix(k, k) / P;
    end
    
end

function [palloc_matrix, allocPercentage] = water_filling3(loss, P)
    %% 初始化
    N= length(loss) ;                    %信道个数
    [noise_sorted,index]=sort(loss); 
    for p=length(noise_sorted):-1:1 
        T_P=(P+sum(noise_sorted(1:p)))/p; 
        Input_Power=T_P-noise_sorted; 
        Pt=Input_Power(1:p); 
        if(Pt(:)>=0)
            break 
        end 
    end 
    power_alloc=zeros(1,N); 
    power_alloc(index(1:p))=Pt;                                %分配的功率
    
    palloc_matrix = diag(power_alloc);

    %我要获得的是比例
    allocPercentage = zeros(1, N);
    for k = 1 : N
        allocPercentage(k) = palloc_matrix(k, k) / P;
    end

end

function PosInDescartes = LngLat2Descartes(CurPos, h)
    tmpPhi = CurPos(1) * pi / 180;
    if tmpPhi < 0
        tmpPhi = tmpPhi + 2*pi;
    end
    tmpTheta = (90 - CurPos(2)) * pi / 180;
    R = 6371.393e3; % 地球半径
    tmpX = (R+h) * sin(tmpTheta) * cos(tmpPhi);
    tmpY = (R+h) * sin(tmpTheta) * sin(tmpPhi);
    tmpZ = (R+h) * cos(tmpTheta); 
    PosInDescartes = [tmpX, tmpY, tmpZ];    
end

%% 计算SINR值和h值
function [SINR, h] = CaculateR(SatIdx, ScheIdx, slotIdx, userIdx, curFoot, lightFoot, lightPower, BeamPoint, thisBand, interface)
% 输入：SatIdx卫星编号；ScheIdx调度周期编号；userIdx当前用户编号；footIdx当前波位编号；
% lightFoot所有点亮波位编号；lightPower所有点亮波位的功率分配编号；BeamPoint指向；
% thisBand当前频带
    userIdx = find(interface.OrderOfSelectedUsrs == userIdx);
    
    Usrs = interface.tmpSat(SatIdx).beamfoot(ScheIdx, curFoot).usrs;% 波位里的用户
    footIdx = find(lightFoot == curFoot);
    Pt = interface.UsrsObj(userIdx).PowerPercent(slotIdx) * lightPower;   % 每个用户分到的功率

    T_noise = interface.UsrsObj(1).T_noise;
    F_noise_dB = interface.UsrsObj(1).F_noise;
    F_noise = 10.^(F_noise_dB./10);
    N0_noise = 1.380649e-23*(T_noise + (F_noise-1)*300);

    Bandwidth = thisBand(2) - thisBand(1);
    fc = mean(thisBand);

    % 计算当前用户的指向角 
    userCurPos = interface.UsrsObj(userIdx).position; % 当前用户坐标    
    satCurPos = interface.SatObj(SatIdx).position; % 当前卫星星下点坐标
    satCurnextPos = interface.SatObj(SatIdx).nextpos; % 当前卫星星下点下一step坐标
    [userTheta, userPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, userCurPos, interface.height);%计算方位角和仰角
    % 计算用户接收增益
    G_usrDown = antenna.getUsrAntennaServG(0, fc, false);
    % 计算当前卫星到当前用户的距离
    usrCurPos = interface.UsrsObj(userIdx).position;
    usrPosInDescartes = LngLat2Descartes(usrCurPos, 0);
    satPosInDescartes = LngLat2Descartes(satCurPos, interface.height);
    distance = sqrt((satPosInDescartes(1)-usrPosInDescartes(1)).^2 + ...
                    (satPosInDescartes(2)-usrPosInDescartes(2)).^2 + ...
                    (satPosInDescartes(3)-usrPosInDescartes(3)).^2);  
    InterfInSatDown = 0;

    %遍历干扰波位，是按照是否已经分配的顺序来的，计算干扰
    for bfIdx = 1 : length(lightFoot)
        OrderOfbeam = lightFoot(bfIdx);% 波位的实际编号
        if OrderOfbeam == curFoot % 跳过当前波位
            continue;
        else
            %干扰波位里的用户的编号
            interfUsrs = interface.tmpSat(SatIdx).beamfoot(ScheIdx, OrderOfbeam).usrs;
            % 干扰波位被分配到的功率
            interfBeamPower = lightPower;
            poiBeta = BeamPoint(bfIdx,1);
            poiAlpha = BeamPoint(bfIdx,2);
            AgleOfInv = [userTheta, userPhi];
            AgleOfPoi = [poiAlpha, poiBeta];
            for interfUsrIdx = 1 : length(interfUsrs) % 遍历该波位里用户的干扰
                % 获得这个干扰用户的功率、频带
                thisInterfUser = interfUsrs(interfUsrIdx);
                thisInterfUser = find(interface.OrderOfSelectedUsrs == thisInterfUser);
                thisInterfUser_power = interface.UsrsObj(thisInterfUser).PowerPercent(slotIdx) * interfBeamPower;
                thisInterfUser_band = interface.UsrsObj(thisInterfUser).Band(slotIdx, :);

                % 判断是否有频段重合
                overlap = range_intersection(thisBand, thisInterfUser_band);% 注意检查f的单位是不是Hz
                if length(overlap) == 2
                    lambdaDown = 3e8/mean(overlap);
                    G_sat_interfDown = antenna.getSatAntennaServG(AgleOfInv, AgleOfPoi, mean(overlap));
                    InterfInSatDown = InterfInSatDown + ...
                        thisInterfUser_power * G_sat_interfDown * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
                end

            end
        end

    end
    %%%%%%%%%%%%%%%%%%%%%
    bfIdx = find(lightFoot == curFoot);
    poiBeta = BeamPoint(bfIdx,1);
    poiAlpha = BeamPoint(bfIdx,2);
    AgleOfInv = [userTheta, userPhi];
    AgleOfPoi = [poiAlpha, poiBeta];
    lambda_c = 3e8/fc;

    G_sat_down = antenna.getSatAntennaServG(AgleOfInv, AgleOfPoi, fc);
    %%%%%%%%%%%%%%%%%%%%%
    Carrier_down = Pt * G_sat_down * G_usrDown * (lambda_c.^2) / (((4*pi).^2)*(distance.^2));
    SINR = Carrier_down./(InterfInSatDown + Bandwidth*N0_noise);
    h = SINR/Pt;
%     SNR = Carrier_down./(Bandwidth*N0_noise);
end

%% 求交集
function [ Overlap ] = range_intersection( A,B )

%A and B is a vector 
%for example A = [1 2 3]; B = [2 2.5 3 4]; 

%find lower and upper limit for vector A and B
Lower_A = min(A); 
Upper_A = max(A); 

Lower_B = min(B); 
Upper_B = max(B); 

%check condition of lower and upper limit both vector
%this part is to determine lower limit 
if (Lower_A > Lower_B || Lower_A == Lower_B)
    Lower_Lim = Lower_A;    
else
    Lower_Lim = Lower_B; 
end

%this part is to determine upper limit
if (Upper_A > Upper_B || Upper_A == Upper_B)
    Upper_Lim = Upper_B;    
else
    Upper_Lim = Upper_A; 
end

%merge all vectors
input_vector = union(A,B); 

Overlap = input_vector(intersect(find(input_vector>=Lower_Lim),find(input_vector<=Upper_Lim)));

end


