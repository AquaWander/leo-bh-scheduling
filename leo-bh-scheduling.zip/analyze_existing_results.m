%% 分析现有实验结果
% 从已保存的结果文件中提取性能指标
%
% 作者: 2025-03-04

clear; clc; close all;

addpath(genpath('.'));

fprintf('========================================\n');
fprintf('   分析现有实验结果\n');
fprintf('========================================\n\n');

%% 加载TabuSearch结果
fprintf('[1] 加载TabuSearch结果...\n');
try
    load('results/results_TabuSearch.mat', 'results_Tabu', 'throughputs_Tabu', 'satisfactions_Tabu');
    fprintf('   OK TabuSearch结果加载成功\n');
    
    if exist('throughputs_Tabu', 'var')
        fprintf('   - 吞吐量数据: %d 次运行\n', length(throughputs_Tabu));
        fprintf('   - 平均吞吐量: %.2f Mbps\n', mean(throughputs_Tabu(~isnan(throughputs_Tabu))));
    end
    if exist('satisfactions_Tabu', 'var')
        fprintf('   - 平均满足率: %.2f%%\n', mean(satisfactions_Tabu(~isnan(satisfactions_Tabu)))*100);
    end
catch ME
    fprintf('   ERROR: %s\n', ME.message);
end

fprintf('\n');

%% 加载DQN结果
fprintf('[2] 加载DQN结果...\n');
try
    load('results/results_DQN.mat', 'results_DQN', 'throughputs_DQN', 'satisfactions_DQN');
    fprintf('   OK DQN结果加载成功\n');
    
    if exist('throughputs_DQN', 'var')
        fprintf('   - 吞吐量数据: %d 次运行\n', length(throughputs_DQN));
        fprintf('   - 平均吞吐量: %.2f Mbps\n', mean(throughputs_DQN(~isnan(throughputs_DQN))));
    end
    if exist('satisfactions_DQN', 'var')
        fprintf('   - 平均满足率: %.2f%%\n', mean(satisfactions_DQN(~isnan(satisfactions_DQN)))*100);
    end
catch ME
    fprintf('   ERROR: %s\n', ME.message);
end

fprintf('\n');

%% 加载DataObj结果
fprintf('[3] 加载DataObj结果...\n');
try
    load('DataObj.mat', 'DataObj');
    fprintf('   OK DataObj加载成功\n');
    
    % 分析DataObj
    if isfield(DataObj, 'InterfFromAll_Down')
        [num_methods, num_slots, num_users, ~] = size(DataObj.InterfFromAll_Down);
        fprintf('   - 方法数: %d\n', num_methods);
        fprintf('   - 时隙数: %d\n', num_slots);
        fprintf('   - 用户数: %d\n', num_users);
        
        % 计算平均SINR
        sinr_data = squeeze(DataObj.InterfFromAll_Down(:, :, :, 2));
        avg_sinr = mean(sinr_data(:), 'omitnan');
        fprintf('   - 平均SINR: %.2f dB\n', avg_sinr);
    end
    
    if isfield(DataObj, 'UsrsTraffic') && isfield(DataObj, 'UsrsTransPort')
        % 计算业务满足率
        demand = DataObj.UsrsTraffic(:, 1) + sum(DataObj.UsrsTraffic(:, 2:end), 2);
        transport = squeeze(sum(DataObj.UsrsTransPort, 3));
        
        if ~isempty(transport)
            satisfaction = mean(transport ./ demand', 'omitnan');
            fprintf('   - 平均业务满足率: %.2f%%\n', satisfaction * 100);
        end
    end
    
catch ME
    fprintf('   ERROR: %s\n', ME.message);
end

fprintf('\n');

%% 生成对比图表
fprintf('[4] 生成对比图表...\n');

figure('Position', [100, 100, 1200, 400]);

% 子图1: 吞吐量对比
subplot(1, 2, 1);
if exist('throughputs_Tabu', 'var') && exist('throughputs_DQN', 'var')
    bar_data = [mean(throughputs_Tabu(~isnan(throughputs_Tabu))), ...
                mean(throughputs_DQN(~isnan(throughputs_DQN)))];
    bar(bar_data);
    set(gca, 'XTickLabel', {'Tabu Search', 'DQN'});
    ylabel('吞吐量 (Mbps)');
    title('算法吞吐量对比');
    grid on;
    
    % 添加数值标签
    text(1, bar_data(1)*1.02, sprintf('%.2f', bar_data(1)), 'HorizontalAlignment', 'center');
    text(2, bar_data(2)*1.02, sprintf('%.2f', bar_data(2)), 'HorizontalAlignment', 'center');
else
    text(0.5, 0.5, '数据不足', 'HorizontalAlignment', 'center');
end

% 子图2: 服务满足率对比
subplot(1, 2, 2);
if exist('satisfactions_Tabu', 'var') && exist('satisfactions_DQN', 'var')
    bar_data = [mean(satisfactions_Tabu(~isnan(satisfactions_Tabu)))*100, ...
                mean(satisfactions_DQN(~isnan(satisfactions_DQN)))*100];
    bar(bar_data, 'FaceColor', [0.8, 0.4, 0.4]);
    set(gca, 'XTickLabel', {'Tabu Search', 'DQN'});
    ylabel('服务满足率 (%)');
    title('算法服务满足率对比');
    grid on;
    
    text(1, bar_data(1)*1.02, sprintf('%.2f%%', bar_data(1)), 'HorizontalAlignment', 'center');
    text(2, bar_data(2)*1.02, sprintf('%.2f%%', bar_data(2)), 'HorizontalAlignment', 'center');
else
    text(0.5, 0.5, '数据不足', 'HorizontalAlignment', 'center');
end

% 保存图表
saveas(gcf, 'results/existing_results_comparison.png');
fprintf('   OK 图表已保存: results/existing_results_comparison.png\n');

fprintf('\n========================================\n');
fprintf('   分析完成！\n');
fprintf('========================================\n\n');
