function BeamFoot_Method4(interface)
%BEAMFOOT_METHOD2 
%   

end

