%% SA消融实验脚本 - 修正版
% 对比有/无模拟退火(SA)机制的性能差异
% 
% 实验设计:
%   实验1: Tabu + SA (完整版，enable_SA=true)
%   实验2: Tabu only (无SA，enable_SA=false)
%
% 作者: 2025-03-04
% 版本: 2.0 (修正版)

clear; clc; close all;

%% 添加路径
addpath(genpath('.'));

%% 实验配置
fprintf('========================================\n');
fprintf('   SA消融实验: Tabu+SA vs Tabu-only\n');
fprintf('========================================\n\n');

num_runs = 2;  % 每组实验运行次数（减少以节省时间）
save_results = true;  % 是否保存结果

%% 加载配置
fprintf('[1/5] 加载配置...\n');
setConfig;  % 加载Config结构体
fprintf('   OK 配置加载成功\n');
fprintf('   - 用户数: %d\n', Config.meanUsrsNum);
fprintf('   - 波束数: %d\n', Config.numOfServbeam);
fprintf('   - 调度周期: %.2f ms\n\n', Config.bhTime * 1000);

%% 初始化结果存储
results = struct();
results.with_SA = [];
results.without_SA = [];

%% 实验1: Tabu + SA (完整版)
fprintf('[2/5] 运行实验1: Tabu + SA...\n');
for run = 1:num_runs
    fprintf('   运行第 %d/%d 次...\n', run, num_runs);
    
    tic;
    try
        % 创建控制器并运行仿真
        controller = simSatSysClass.simController(Config, 1, 1, 0);
        
        % 保存原始方法
        orig_method = controller.generateBHST;
        
        % 修改为使用SA版本的算法
        % 注意：需要在controller中设置SA参数
        controller.enable_SA = true;
        
        % 运行仿真
        DataObj = controller.run();
        
        elapsed_time = toc;
        
        % 计算性能指标
        throughput = calcuThroughput(DataObj);
        satisfaction = calcuSatis(DataObj);
        
        metrics = struct();
        metrics.throughput = throughput;
        metrics.satisfaction = satisfaction;
        metrics.time = elapsed_time;
        
        results.with_SA = [results.with_SA; metrics];
        
        fprintf('     - 吞吐量: %.2f Mbps\n', throughput/1e6);
        fprintf('     - 满足率: %.2f%%\n', satisfaction*100);
        fprintf('     - 耗时: %.2f 秒\n\n', elapsed_time);
        
    catch ME
        fprintf('   [错误] 运行失败: %s\n\n', ME.message);
        fprintf('   错误堆栈:\n');
        disp(getReport(ME));
    end
end

%% 实验2: Tabu only (无SA) - 使用原始BHST_MY
fprintf('[3/5] 运行实验2: Tabu only (无SA)...\n');
for run = 1:num_runs
    fprintf('   运行第 %d/%d 次...\n', run, num_runs);
    
    tic;
    try
        % 创建控制器并运行仿真
        controller = simSatSysClass.simController(Config, 1, 1, 0);
        
        % 使用原始方法（无SA）
        controller.enable_SA = false;
        
        % 运行仿真
        DataObj = controller.run();
        
        elapsed_time = toc;
        
        % 计算性能指标
        throughput = calcuThroughput(DataObj);
        satisfaction = calcuSatis(DataObj);
        
        metrics = struct();
        metrics.throughput = throughput;
        metrics.satisfaction = satisfaction;
        metrics.time = elapsed_time;
        
        results.without_SA = [results.without_SA; metrics];
        
        fprintf('     - 吞吐量: %.2f Mbps\n', throughput/1e6);
        fprintf('     - 满足率: %.2f%%\n', satisfaction*100);
        fprintf('     - 耗时: %.2f 秒\n\n', elapsed_time);
        
    catch ME
        fprintf('   [错误] 运行失败: %s\n\n', ME.message);
        fprintf('   错误堆栈:\n');
        disp(getReport(ME));
    end
end

%% 统计分析
fprintf('[4/5] 统计分析...\n');

if ~isempty(results.with_SA) && ~isempty(results.without_SA)
    avg_with_SA = mean([results.with_SA.throughput]);
    avg_without_SA = mean([results.without_SA.throughput]);
    avg_sat_with_SA = mean([results.with_SA.satisfaction]);
    avg_sat_without_SA = mean([results.without_SA.satisfaction]);
    
    improvement_throughput = (avg_with_SA - avg_without_SA) / avg_without_SA * 100;
    improvement_satisfaction = (avg_sat_with_SA - avg_sat_without_SA) / avg_sat_without_SA * 100;
    
    fprintf('\n========================================\n');
    fprintf('            实验结果汇总\n');
    fprintf('========================================\n\n');
    
    fprintf('%-25s %15s %15s %15s\n', '指标', 'Tabu+SA', 'Tabu-only', '提升');
    fprintf('%-25s %15s %15s %15s\n', '----------------------', '---------------', '---------------', '---------------');
    fprintf('%-25s %12.2f Mbps %12.2f Mbps %+14.2f%%\n', '平均吞吐量', ...
        avg_with_SA/1e6, avg_without_SA/1e6, improvement_throughput);
    fprintf('%-25s %14.2f%% %14.2f%% %+14.2f%%\n', '平均服务满足率', ...
        avg_sat_with_SA*100, avg_sat_without_SA*100, improvement_satisfaction);
    fprintf('\n========================================\n\n');
else
    fprintf('[警告] 实验数据不完整，无法进行统计分析\n\n');
end

%% 保存实验结果
if save_results && (~isempty(results.with_SA) || ~isempty(results.without_SA))
    fprintf('[5/5] 保存实验结果...\n');
    
    if ~exist('results', 'dir')
        mkdir('results');
    end
    
    timestamp = datestr(now, 'yyyy-mm-dd_HH-MM-SS');
    save(sprintf('results/ablation_SA_%s.mat', timestamp), 'results', 'Config');
    fprintf('   OK 结果已保存: results/ablation_SA_%s.mat\n', timestamp);
end

fprintf('\n========================================\n');
fprintf('   SA消融实验完成！\n');
fprintf('========================================\n\n');
