% run_TabuSearch.m
% 运行禁忌搜索算法的基线测试
% 目标：多次运行以获取稳定的统计结果

clear; clc;

fprintf('========================================\n');
fprintf('  禁忌搜索算法基线测试\n');
fprintf('========================================\n\n');

% 加载配置
setConfig;

% 配置为禁忌搜索方法（使用BHST_MY）
Config.numOfMethods_BeamGenerate = 1;
Config.numOfMethods_BeamHopping = 1;

% 修改generateBHST.m以使用禁忌搜索
% 注意：需要在generateBHST.m中调用methods.BHST_MY

% 多次运行
num_runs = 5;
results_Tabu = cell(num_runs, 1);
times_Tabu = zeros(num_runs, 1);
throughputs_Tabu = zeros(num_runs, 1);
satisfactions_Tabu = zeros(num_runs, 1);

fprintf('运行配置:\n');
fprintf('  - 用户数: %d\n', Config.meanUsrsNum);
fprintf('  - 波束数: %d\n', Config.numOfServbeam);
fprintf('  - 调度周期: %.2f ms\n', Config.bhTime * 1000);
fprintf('  - 运行次数: %d\n\n', num_runs);

% 运行实验
for run = 1 : num_runs
    fprintf('===== 禁忌搜索 第%d/%d次运行 =====\n', run, num_runs);
    tic;
    
    try
        % 运行仿真
        controller = simSatSysClass.simController(Config, 1, 1, 0);
        DataObj = controller.run();
        
        times_Tabu(run) = toc;
        results_Tabu{run} = DataObj;
        
        % 计算性能指标
        throughputs_Tabu(run) = calcuThroughput(DataObj);
        satisfactions_Tabu(run) = calcuSatis(DataObj);
        
        fprintf('禁忌搜索 第%d次运行完成，耗时%.2f秒\n', run, times_Tabu(run));
        fprintf('  - 吞吐量: %.2f Mbps\n', throughputs_Tabu(run));
        fprintf('  - 满足率: %.2f%%\n', satisfactions_Tabu(run) * 100);
        fprintf('\n');
        
    catch ME
        fprintf('[✗] 第%d次运行失败: %s\n', run, ME.message);
        times_Tabu(run) = NaN;
        throughputs_Tabu(run) = NaN;
        satisfactions_Tabu(run) = NaN;
    end
end

% 统计分析
fprintf('========================================\n');
fprintf('  禁忌搜索统计结果\n');
fprintf('========================================\n\n');

valid_runs = ~isnan(throughputs_Tabu);
num_valid = sum(valid_runs);

if num_valid == 0
    fprintf('[✗] 所有运行均失败\n');
    return;
end

fprintf('有效运行次数: %d/%d\n\n', num_valid, num_runs);

% 吞吐量统计
mean_throughput = mean(throughputs_Tabu(valid_runs));
std_throughput = std(throughputs_Tabu(valid_runs));
ci_throughput = 1.96 * std_throughput / sqrt(num_valid);

fprintf('=== 系统吞吐量 ===\n');
fprintf('平均值: %.2f Mbps\n', mean_throughput);
fprintf('标准差: %.2f Mbps\n', std_throughput);
fprintf('95%%置信区间: [%.2f, %.2f] Mbps\n', ...
    mean_throughput - ci_throughput, mean_throughput + ci_throughput);
fprintf('\n');

% 满足率统计
mean_satisfaction = mean(satisfactions_Tabu(valid_runs));
std_satisfaction = std(satisfactions_Tabu(valid_runs));
ci_satisfaction = 1.96 * std_satisfaction / sqrt(num_valid);

fprintf('=== 业务满足率 ===\n');
fprintf('平均值: %.2f%%\n', mean_satisfaction * 100);
fprintf('标准差: %.2f%%\n', std_satisfaction * 100);
fprintf('95%%置信区间: [%.2f%%, %.2f%%]\n', ...
    (mean_satisfaction - ci_satisfaction) * 100, ...
    (mean_satisfaction + ci_satisfaction) * 100);
fprintf('\n');

% 运行时间统计
mean_time = mean(times_Tabu(valid_runs));
std_time = std(times_Tabu(valid_runs));

fprintf('=== 运行时间 ===\n');
fprintf('平均值: %.2f 秒\n', mean_time);
fprintf('标准差: %.2f 秒\n', std_time);
fprintf('\n');

% 保存结果
fprintf('保存结果...\n');
dateStr = datestr(now, 'yyyy-mm-dd_HH-MM-SS');
results_filename = sprintf('results/results_TabuSearch_%s.mat', dateStr);

try
    save(results_filename, 'results_Tabu', 'times_Tabu', ...
        'throughputs_Tabu', 'satisfactions_Tabu', 'Config', '-v7.3');
    fprintf('[✓] 结果已保存到: %s\n', results_filename);
catch ME
    fprintf('[✗] 保存失败: %s\n', ME.message);
end

fprintf('\n========================================\n');
fprintf('  禁忌搜索基线测试完成\n');
fprintf('========================================\n');
