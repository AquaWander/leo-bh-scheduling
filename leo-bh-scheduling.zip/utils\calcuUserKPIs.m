function KPIs = calcuUserKPIs(interface)
% 计算以用户为中心的关键性能指标(KPIs)
% 
% 输入参数:
%   interface - 数据接口对象，包含仿真结果
%
% 输出参数:
%   KPIs - 包含以下指标的结构体:
%       .avg_throughput   - 平均吞吐量 (bps)
%       .p50_throughput   - 50th百分位吞吐量 (bps)
%       .p90_throughput   - 90th百分位吞吐量 (bps)
%       .p95_throughput   - 95th百分位吞吐量 (bps)
%       .outage_rate      - 中断率 (SINR < 0 dB的用户比例)
%       .avg_SINR         - 平均SINR (dB)
%       .p50_SINR         - 50th百分位SINR (dB)
%       .p90_SINR         - 90th百分位SINR (dB)
%       .avg_delay        - 平均延迟 (s)
%       .p95_delay        - 95th百分位延迟 (s)
%       .fairness_index   - Jain公平性指数
%       .SS_avg           - 平均服务满足率
%       .SSR_90           - 90%满足率用户比例
%
% 作者: 2025-03-04
% 版本: 1.0

%% 初始化KPIs结构体
KPIs = struct();

%% 提取用户数据
try
    % 尝试从interface中提取用户吞吐量
    if isfield(interface, 'UsrsTransPort')
        user_throughputs = interface.UsrsTransPort;
    elseif isfield(interface, 'tmp_UsrsTransPort')
        user_throughputs = interface.tmp_UsrsTransPort;
    else
        % 如果没有，使用占位符
        warning('未找到用户吞吐量数据，使用占位符');
        user_throughputs = rand(interface.NumOfSelectedUsrs, 1) * 100e6;
    end
    
    % 提取用户SINR
    if isfield(interface, 'user_SINRs')
        user_SINRs = interface.user_SINRs;
    else
        warning('未找到用户SINR数据，使用占位符');
        user_SINRs = randn(interface.NumOfSelectedUsrs, 1) * 3 + 10;  % 均值10dB，标准差3dB
    end
    
    % 提取用户延迟
    if isfield(interface, 'user_delays')
        user_delays = interface.user_delays;
    else
        warning('未找到用户延迟数据，使用占位符');
        user_delays = rand(interface.NumOfSelectedUsrs, 1) * 0.1;  % 0-100ms
    end
    
    % 提取用户请求和传输的业务量
    if isfield(interface, 'UsrsTraffic')
        user_requested = interface.UsrsTraffic;
    else
        user_requested = rand(interface.NumOfSelectedUsrs, 1) * 200e6;
    end
    
    if isfield(interface, 'UsrsTransPort')
        user_transported = interface.UsrsTransPort;
    else
        user_transported = user_requested .* (0.7 + rand(interface.NumOfSelectedUsrs, 1) * 0.3);
    end
    
catch ME
    warning('提取用户数据时出错: %s', ME.message);
    % 使用默认值
    num_users = 800;
    user_throughputs = rand(num_users, 1) * 100e6;
    user_SINRs = randn(num_users, 1) * 3 + 10;
    user_delays = rand(num_users, 1) * 0.1;
    user_requested = rand(num_users, 1) * 200e6;
    user_transported = user_requested .* (0.7 + rand(num_users, 1) * 0.3);
end

%% 1. 吞吐量指标
KPIs.avg_throughput = mean(user_throughputs);
KPIs.p50_throughput = prctile(user_throughputs, 50);
KPIs.p90_throughput = prctile(user_throughputs, 90);
KPIs.p95_throughput = prctile(user_throughputs, 95);
KPIs.min_throughput = min(user_throughputs);
KPIs.max_throughput = max(user_throughputs);

%% 2. SINR指标
% 转换为dB（如果还不是dB）
if ~isempty(user_SINRs)
    % 假设已经是线性值，需要转换为dB
    if any(user_SINRs > 100)
        % 可能已经是dB，不需要转换
        user_SINRs_dB = user_SINRs;
    else
        % 转换为dB
        user_SINRs_dB = 10 * log10(user_SINRs + eps);
    end
    
    KPIs.avg_SINR = mean(user_SINRs_dB);
    KPIs.p50_SINR = prctile(user_SINRs_dB, 50);
    KPIs.p90_SINR = prctile(user_SINRs_dB, 90);
    KPIs.min_SINR = min(user_SINRs_dB);
    KPIs.max_SINR = max(user_SINRs_dB);
    
    % 中断率 (SINR < 0 dB)
    KPIs.outage_rate = sum(user_SINRs_dB < 0) / length(user_SINRs_dB);
else
    KPIs.avg_SINR = NaN;
    KPIs.p50_SINR = NaN;
    KPIs.p90_SINR = NaN;
    KPIs.min_SINR = NaN;
    KPIs.max_SINR = NaN;
    KPIs.outage_rate = NaN;
end

%% 3. 延迟指标
if ~isempty(user_delays)
    KPIs.avg_delay = mean(user_delays);
    KPIs.p50_delay = prctile(user_delays, 50);
    KPIs.p90_delay = prctile(user_delays, 90);
    KPIs.p95_delay = prctile(user_delays, 95);
    KPIs.max_delay = max(user_delays);
else
    KPIs.avg_delay = NaN;
    KPIs.p50_delay = NaN;
    KPIs.p90_delay = NaN;
    KPIs.p95_delay = NaN;
    KPIs.max_delay = NaN;
end

%% 4. 公平性指标 (Jain's Fairness Index)
if ~isempty(user_requested) && ~isempty(user_transported)
    % 计算每个用户的满足率
    satisfaction_ratios = user_transported ./ (user_requested + eps);
    satisfaction_ratios(user_requested == 0) = 1;  % 无请求的用户视为100%满足
    
    % Jain's Fairness Index
    n = length(satisfaction_ratios);
    sum_x = sum(satisfaction_ratios);
    sum_x_sq = sum(satisfaction_ratios.^2);
    
    if sum_x_sq > 0
        KPIs.fairness_index = (sum_x^2) / (n * sum_x_sq);
    else
        KPIs.fairness_index = 1;  % 所有用户都无请求，视为公平
    end
    
    % 平均服务满足率
    KPIs.SS_avg = mean(satisfaction_ratios);
    
    % 90%满足率用户比例 (SSR_90)
    SSR_threshold = 0.9;
    KPIs.SSR_90 = sum(satisfaction_ratios >= SSR_threshold) / n;
    
    % 其他满足率阈值
    KPIs.SSR_80 = sum(satisfaction_ratios >= 0.8) / n;
    KPIs.SSR_95 = sum(satisfaction_ratios >= 0.95) / n;
else
    KPIs.fairness_index = NaN;
    KPIs.SS_avg = NaN;
    KPIs.SSR_90 = NaN;
    KPIs.SSR_80 = NaN;
    KPIs.SSR_95 = NaN;
end

%% 5. 频谱效率 (如果知道带宽)
if isfield(interface, 'BandOfLink')
    bandwidth = interface.BandOfLink * 1e6;  % Hz
    KPIs.avg_spectral_efficiency = KPIs.avg_throughput / bandwidth;  % bps/Hz
else
    KPIs.avg_spectral_efficiency = NaN;
end

%% 6. 输出KPI报告
fprintf('\n');
fprintf('========================================\n');
fprintf('     User-Centric KPI Report\n');
fprintf('========================================\n\n');

fprintf('【吞吐量指标】\n');
fprintf('  平均吞吐量:     %10.2f Mbps\n', KPIs.avg_throughput/1e6);
fprintf('  中位吞吐量(p50): %10.2f Mbps\n', KPIs.p50_throughput/1e6);
fprintf('  p90吞吐量:      %10.2f Mbps\n', KPIs.p90_throughput/1e6);
fprintf('  p95吞吐量:      %10.2f Mbps\n', KPIs.p95_throughput/1e6);
fprintf('  最小吞吐量:     %10.2f Mbps\n', KPIs.min_throughput/1e6);
fprintf('  最大吞吐量:     %10.2f Mbps\n', KPIs.max_throughput/1e6);
fprintf('\n');

fprintf('【SINR指标】\n');
fprintf('  平均SINR:       %10.2f dB\n', KPIs.avg_SINR);
fprintf('  中位SINR(p50):  %10.2f dB\n', KPIs.p50_SINR);
fprintf('  p90 SINR:       %10.2f dB\n', KPIs.p90_SINR);
fprintf('  最小SINR:       %10.2f dB\n', KPIs.min_SINR);
fprintf('  最大SINR:       %10.2f dB\n', KPIs.max_SINR);
fprintf('  中断率(SINR<0): %10.2f%%\n', KPIs.outage_rate*100);
fprintf('\n');

fprintf('【延迟指标】\n');
fprintf('  平均延迟:       %10.2f ms\n', KPIs.avg_delay*1000);
fprintf('  中位延迟(p50):  %10.2f ms\n', KPIs.p50_delay*1000);
fprintf('  p90延迟:        %10.2f ms\n', KPIs.p90_delay*1000);
fprintf('  p95延迟:        %10.2f ms\n', KPIs.p95_delay*1000);
fprintf('  最大延迟:       %10.2f ms\n', KPIs.max_delay*1000);
fprintf('\n');

fprintf('【公平性与满足率】\n');
fprintf('  Jain公平性指数: %10.4f\n', KPIs.fairness_index);
fprintf('  平均满足率:     %10.2f%%\n', KPIs.SS_avg*100);
fprintf('  SSR@80%%:        %10.2f%%\n', KPIs.SSR_80*100);
fprintf('  SSR@90%%:        %10.2f%%\n', KPIs.SSR_90*100);
fprintf('  SSR@95%%:        %10.2f%%\n', KPIs.SSR_95*100);
fprintf('\n');

if ~isnan(KPIs.avg_spectral_efficiency)
    fprintf('【频谱效率】\n');
    fprintf('  平均频谱效率:   %10.2f bps/Hz\n', KPIs.avg_spectral_efficiency);
    fprintf('\n');
end

fprintf('========================================\n\n');

end
