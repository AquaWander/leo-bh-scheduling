function PowerAllocation_Average(interface)
% 本函数用于根据BHST，对波束间用户平均分配功率

for satIdx = 1 : length(interface.OrderOfServSatCur)
    %计算卫星总功率
    Pt_sat = interface.SatObj(satIdx).Pt_dBm_serv; % 卫星天线总的发射功率
    Pt_sat = (10.^(Pt_sat/10))/1e3; %单位是W

    BHST = interface.tmpSat(satIdx).BHST;
    totalSlots = interface.SlotInSche; % 一次跳波束调度长度
    maxBeam = length(BHST(:,1));

    PtTable = zeros(maxBeam, totalSlots);

    for slotIdx = 1 : totalSlots
        curIllu = find(BHST(:,slotIdx) ~= 0);
        curBeamNum = length(curIllu);
        curAvgPower = Pt_sat / curBeamNum;
        for beamIdx = 1 : curBeamNum
            PtTable(curIllu(beamIdx), slotIdx) = curAvgPower;
        end
    end

    interface.tmpSat(satIdx).Pt_Antenna = PtTable;

end

end

