function DataObj = calcuInterference(self, DataObj, IdxOfStep, MC_idx)
%CALCUINTERFERENCE 计算干扰
    ifDebug = self.ifDebug;

    NumOfSlotPerShot = self.slotInShot;
    NumOfSlotPerSche = self.subFInSche * self.slotInSubF;
    NumOfShot = length(self.SatPosition(1,:,1)) - 1; % 仿真快照总数(最后一张快照不计算)

    NumOfSat = length(self.OrderOfServSatCur);
    NumOfInvesUsrs = self.numOfUsrs_inves;

    heightOfsat = self.Config.height;
    lightVelocity = self.vOfray;

    freqOfDownLink = self.Config.freqOfDownLink;
    lambdaDown = lightVelocity/freqOfDownLink;
    freqOfUpLink = self.Config.freqOfUpLink;
    lambdaUp = lightVelocity/freqOfUpLink;

    UsrAntennaConfig = antenna.initialUsrAntenna();
    IfUsrAntennaDeGravity = UsrAntennaConfig.ifDeGravity;

    

    %% 遍历所有算法
    for MethodIdx = 1 : self.numOfMethods_BeamGenerate * self.numOfMethods_BeamHopping

        %% 遍历所有时隙
        for slotIdx = 1 : NumOfSlotPerShot
            %% 获得当前时隙卫星的波束指向
            self.getBeamPoint(slotIdx,MethodIdx);
            % self.SatObj(SatIdx).BeamPoint的前NumOfLightBeamfoot个是业务波束，后NumOfLightSig个是信令波束
            %% 遍历所有卫星
            dpIdx = ceil(slotIdx/NumOfSlotPerSche); % 第几次调度
            for SatIdx = 1 : NumOfSat %遍历卫星
                servUsr = self.SatObj(SatIdx).servUsr(dpIdx, self.SatObj(SatIdx).servUsr(dpIdx,:)~=0);
                tmpNo = find(servUsr <= NumOfInvesUsrs);
                UsrsOfSatCur = self.SatObj(SatIdx).servUsr(dpIdx, tmpNo); % 当前星下考察区域内用户集合
                NumOfUsrs = length(tmpNo); % 星下用户数量

                Pt_SAT_dBm_serv = self.SatObj(SatIdx).Pt_dBm_serv;
                %%%%%%%%%%%%%%%%% 业务波束功率均分 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                Pt_SAT_serv = (10.^(Pt_SAT_dBm_serv/10))/1e3/self.Config.numOfServbeam; % W
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                if self.Config.numOfSigbeam > 0
                    Pt_SAT_dBm_signal = self.SatObj(SatIdx).Pt_dBm_signal;
                    Pt_SAT_signal = (10.^(Pt_SAT_dBm_signal/10))/1e3/self.Config.numOfSigbeam; % W
                end
                LightBeamfoot = self.SatObj(SatIdx).LightBeamfoot; % 当前点亮的波位编号
%                 if MethodIdx == 2
%                     1;
%                 end
                %% 遍历星下用户
                for UsrIdx = 1 : NumOfUsrs %遍历用户
                    UsrOrderCur = UsrsOfSatCur(UsrIdx); % 当前用户编号
%                     BeamfootOrderOfUsrCur = self.Usr2SatCur(UsrOrderCur, 1+mod(MethodIdx-1, 3)+1, dpIdx); % 当前用户归属波位
                    BeamfootOrderOfUsrCur = self.Usr2SatCur(UsrOrderCur, 1+ceil(MethodIdx/self.numOfMethods_BeamHopping), dpIdx); % 当前用户归属波位        
                    Pt_Usr_dBm = self.UsrsObj(find(self.OrderOfSelectedUsrs==UsrOrderCur)).Pt_dBm;
                    Pt_Usr = (10.^(Pt_Usr_dBm/10))/1e3; % W

                    InterfInSatDown = 0; % 星内下行干扰
                    InterfWithSatDown = 0; % 星间下行干扰
                    InterfInSatUp = 0; % 星内上行干扰
                    InterfWithSatUp = 0; % 星间上行干扰
                    %% 判断用户在当前时隙是否点亮
                    IdxInLightBeamfoot = find(LightBeamfoot == BeamfootOrderOfUsrCur);
                    %% 如果点亮，计算干扰
                    if ~isempty(IdxInLightBeamfoot)
                        % 计算当前用户的指向角 
                        usrCurPos = self.UsrsObj(find(self.OrderOfSelectedUsrs==UsrOrderCur)).position; % 当前用户坐标
                        satCurPos = self.SatObj(SatIdx).position; % 当前卫星星下点坐标
                        satCurnextPos = self.SatObj(SatIdx).nextpos; % 当前卫星星下点下一step坐标
                        [UsrTheta, UsrPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, usrCurPos, heightOfsat);%计算方位角和仰角
    
                        % 计算用户接收增益
                        if IfUsrAntennaDeGravity == 1
                            [tmp_angle, ~, ~] = simSatSysClass.tools.getAngleOfInterfSat(usrCurPos, satCurPos, usrCurPos, heightOfsat);
                            G_usrDown = antenna.getUsrAntennaServG(tmp_angle, freqOfDownLink, false);
                        else
                            G_usrDown = antenna.getUsrAntennaServG(0, freqOfDownLink, false);
                        end
                            
                        % 计算当前卫星到当前用户的距离
                        usrPosInDescartes = LngLat2Descartes(usrCurPos, 0);
                        satPosInDescartes = LngLat2Descartes(satCurPos, heightOfsat);
                        distance = sqrt((satPosInDescartes(1)-usrPosInDescartes(1)).^2 + ...
                                        (satPosInDescartes(2)-usrPosInDescartes(2)).^2 + ...
                                        (satPosInDescartes(3)-usrPosInDescartes(3)).^2);  

                        %% 星内干扰
                        % 遍历所有下行干扰波位
                        interfLightBeamfoot = LightBeamfoot(LightBeamfoot~=BeamfootOrderOfUsrCur); % 干扰波位的编号集合
                        NumOfInterfInSat = length(interfLightBeamfoot); % 干扰波位的数量
                        interfUsrsOfSatCur = []; % 上行干扰用户的编号集合

                        %% 计算下行干扰
                        if ~isempty(self.SatObj(SatIdx).LightSig)    
                        % 如果存在信令波束             
                            tmpOrderOfSig = self.SatObj(SatIdx).LightSig;
                            % 计算业务波位的干扰
                            for interfIdx = 1 : NumOfInterfInSat  
                                % 计算下行干扰 
                                tmpOrderOfbeam = find(LightBeamfoot == interfLightBeamfoot(interfIdx));
                                G_sat_interfDown = self.SatObj(SatIdx).getAntennaServG(UsrTheta, UsrPhi, tmpOrderOfbeam, freqOfDownLink); % 天线发射增益
                                InterfInSatDown = InterfInSatDown + ...
                                    Pt_SAT_serv * G_sat_interfDown * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
                                % 计算所有的上行干扰用户
                                if ~isempty(self.SatObj(SatIdx).beamfoot(dpIdx,:))
                                    interfUsrsOfSatCur = [interfUsrsOfSatCur self.SatObj(SatIdx).beamfoot(dpIdx, interfLightBeamfoot(interfIdx)).usrs];
                                end
                            end
                            % 补充计算信令波位的干扰
                            for interfIdx = 1 : length(tmpOrderOfSig)  
                                tmpOrderOfbeam = NumOfInterfInSat + interfIdx;
                                G_sat_interfDown = self.SatObj(SatIdx).getSatSigServG(UsrTheta, UsrPhi, tmpOrderOfbeam, freqOfDownLink); % 天线发射增益
                                InterfInSatDown = InterfInSatDown + ...
                                    Pt_SAT_signal * G_sat_interfDown * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
                            end
                        else
                        %如果没有信令波束    
                            for interfIdx = 1 : NumOfInterfInSat  
                                % 计算下行干扰 
                                tmpOrderOfbeam = find(LightBeamfoot == interfLightBeamfoot(interfIdx));
                                G_sat_interfDown = self.SatObj(SatIdx).getAntennaServG(UsrTheta, UsrPhi, tmpOrderOfbeam, freqOfDownLink); % 天线发射增益
                                InterfInSatDown = InterfInSatDown + ...
                                    Pt_SAT_serv * G_sat_interfDown * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
                                % 计算所有的上行干扰用户
                                if ~isempty(self.SatObj(SatIdx).beamfoot(dpIdx,:))
                                    interfUsrsOfSatCur = [interfUsrsOfSatCur self.SatObj(SatIdx).beamfoot(dpIdx, interfLightBeamfoot(interfIdx)).usrs];
                                end
                            end
                        end
    
                        %% 计算上行干扰, 遍历所有上行干扰用户
                        NumOfinterfUsrs = length(interfUsrsOfSatCur);
                        for interfusrIdx = 1 : NumOfinterfUsrs 
                            % 获得干扰用户的指向角
                            usrInterfPos = self.UsrsObj(find(self.OrderOfSelectedUsrs==interfUsrsOfSatCur(interfusrIdx))).position; % 干扰用户坐标
                            [UsrInterfTheta, UsrInterfPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, usrInterfPos, heightOfsat);
                            
                            % 计算干扰用户的发射增益
                            if IfUsrAntennaDeGravity == 1
                                [tmp_angle, ~, ~] = simSatSysClass.tools.getAngleOfInterfSat(usrInterfPos, satCurPos, usrInterfPos, heightOfsat);
                                G_usr_interfUp = antenna.getUsrAntennaServG(tmp_angle, freqOfUpLink, true);
                            else
                                G_usr_interfUp = antenna.getUsrAntennaServG(0, freqOfUpLink, true);
                            end
                            
                            % 计算干扰用户到卫星的距离
                            usrInterfPosInDescartes = LngLat2Descartes(usrInterfPos, 0);
                            distance_interf = sqrt((satPosInDescartes(1)-usrInterfPosInDescartes(1)).^2 + ...
                                                   (satPosInDescartes(2)-usrInterfPosInDescartes(2)).^2 + ...
                                                   (satPosInDescartes(3)-usrInterfPosInDescartes(3)).^2);
    
                            % 计算上行干扰
                            G_sat_Up = self.SatObj(SatIdx).getAntennaServG(UsrInterfTheta, UsrInterfPhi, IdxInLightBeamfoot, freqOfUpLink); % 天线接收增益
                            InterfInSatUp = InterfInSatUp + ...
                                Pt_Usr * G_usr_interfUp * G_sat_Up * (lambdaUp.^2) / (((4*pi).^2)*(distance_interf.^2));
                        end

                        %% 星间干扰, 遍历所有邻居卫星  
                        for NofLayer = 1 : self.Config.layerOfinterf
                        % 按层遍历
                            OrderOfNeighborSat = self.SatObj(SatIdx).Neighbor(NofLayer, :);
                            NofNeiSatCur = find(OrderOfNeighborSat == 0, 1) - 1; % 当前层的邻居卫星个数
                            OrderOfNeighborSat((NofNeiSatCur + 1) : length(self.OrderOfServSatCur)) = []; % 删除0
                            for NoOfSat = 1 : NofNeiSatCur
                            % 按同层邻居星遍历
                                interfSatIdx = find(self.OrderOfServSatCur == OrderOfNeighborSat(NoOfSat));
                                % 计算用户相对干扰星的指向角
                                satInterfPos = self.SatObj(interfSatIdx).position; % 干扰星坐标
                                satInterfnextPos = self.SatObj(interfSatIdx).nextpos;
                                [UsrThetaInOtherSat, UsrPhiInOtherSat] = ...
                                    tools.getPointAngleOfUsr(satInterfPos, satInterfnextPos, usrCurPos, heightOfsat);
    
                                % 计算干扰星相对用户天线指向的偏轴角
                                interfsatPosInDescartes = LngLat2Descartes(satInterfPos, heightOfsat);
                                vectorOfUsr2curSat = [ ...
                                    satPosInDescartes(1) - usrPosInDescartes(1), ...
                                    satPosInDescartes(2) - usrPosInDescartes(2), ...
                                    satPosInDescartes(3) - usrPosInDescartes(3) ...
                                    ];
                                vectorOfUsr2interfSat = [ ...
                                    interfsatPosInDescartes(1) - usrPosInDescartes(1), ...
                                    interfsatPosInDescartes(2) - usrPosInDescartes(2), ...
                                    interfsatPosInDescartes(3) - usrPosInDescartes(3) ...
                                    ];
                                OffAxisAngle = acos(abs(dot(vectorOfUsr2curSat, vectorOfUsr2interfSat))/...
                                    (sqrt(vectorOfUsr2curSat(1)^2 + vectorOfUsr2curSat(2)^2 + vectorOfUsr2curSat(3)^2) * ...
                                    sqrt(vectorOfUsr2interfSat(1)^2 + vectorOfUsr2interfSat(2)^2 + vectorOfUsr2interfSat(3)^2)));
    
    
                                % 计算用户到干扰星的距离
                                distance2InterfSat = sqrt((interfsatPosInDescartes(1)-usrPosInDescartes(1)).^2 + ...
                                                          (interfsatPosInDescartes(2)-usrPosInDescartes(2)).^2 + ...
                                                          (interfsatPosInDescartes(3)-usrPosInDescartes(3)).^2);
    
                                %% 计算下行干扰
                                interfBeamf = self.SatObj(interfSatIdx).LightBeamfoot;
                                NumOfinterfBeamf = length(interfBeamf);
                                interfUsrsOfSatOther = []; % 上行干扰用户的编号集合

                                if ~isempty(self.SatObj(interfSatIdx).LightSig)
                                %如果存在信令波束
                                    tmpOrderOfSig = self.SatObj(interfSatIdx).LightSig;
                                    if IfUsrAntennaDeGravity == 1
                                        [tmp_angle, ~, ~] = simSatSysClass.tools.getAngleOfInterfSat(usrCurPos, satInterfPos, usrCurPos, heightOfsat);
                                        G_usr_interf = antenna.getUsrAntennaServG(tmp_angle, freqOfDownLink, false);
                                    else                 
                                        G_usr_interf = antenna.getUsrAntennaServG(OffAxisAngle, freqOfDownLink, false);
                                    end
                                    % 计算业务波位的干扰
                                    for interfBfidx = 1 : NumOfinterfBeamf
                                    % 按干扰波位遍历
                                        % 计算下行干扰
                                        G_othersat_interf = self.SatObj(interfSatIdx).getAntennaServG(UsrThetaInOtherSat, UsrPhiInOtherSat, interfBfidx, freqOfDownLink); % 天线发射增益
                                        InterfWithSatDown = InterfWithSatDown + ...
                                            Pt_SAT_serv * G_othersat_interf * G_usr_interf * (lambdaDown.^2) / (((4*pi).^2)*(distance2InterfSat.^2));
                                        % 计算所有的上行干扰用户
                                        if ~isempty(self.SatObj(interfSatIdx).beamfoot)
                                            interfUsrsOfSatOther = [interfUsrsOfSatOther self.SatObj(interfSatIdx).beamfoot(dpIdx, interfBeamf(interfBfidx)).usrs];
                                        end
                                    end
                                    % 补充计算信令波位的干扰
                                    for interfIdx = 1 : length(tmpOrderOfSig)  
                                        tmpOrderOfbeam = NumOfinterfBeamf + interfIdx;
                                        G_othersat_interf = self.SatObj(interfSatIdx).getSatSigServG(UsrThetaInOtherSat, UsrPhiInOtherSat, tmpOrderOfbeam, freqOfDownLink); % 天线发射增益
                                        InterfWithSatDown = InterfWithSatDown + ...
                                            Pt_SAT_signal * G_othersat_interf * G_usr_interf * (lambdaDown.^2) / (((4*pi).^2)*(distance2InterfSat.^2));
                                    end
                                else
                                    if IfUsrAntennaDeGravity == 1
                                        [tmp_angle, ~, ~] = simSatSysClass.tools.getAngleOfInterfSat(usrCurPos, satInterfPos, usrCurPos, heightOfsat);
                                        G_usr_interf = antenna.getUsrAntennaServG(tmp_angle, freqOfDownLink, false);
                                    else                 
                                        G_usr_interf = antenna.getUsrAntennaServG(OffAxisAngle, freqOfDownLink, false);
                                    end
                                    for interfBfidx = 1 : NumOfinterfBeamf
                                    % 按干扰波位遍历
                                        % 计算下行干扰
                                        G_othersat_interf = self.SatObj(interfSatIdx).getAntennaServG(UsrThetaInOtherSat, UsrPhiInOtherSat, interfBfidx, freqOfDownLink); % 天线发射增益
                                        InterfWithSatDown = InterfWithSatDown + ...
                                            Pt_SAT_serv * G_othersat_interf * G_usr_interf * (lambdaDown.^2) / (((4*pi).^2)*(distance2InterfSat.^2));
                                        % 计算所有的上行干扰用户
                                        if ~isempty(self.SatObj(interfSatIdx).beamfoot)
                                            interfUsrsOfSatOther = [interfUsrsOfSatOther self.SatObj(interfSatIdx).beamfoot(dpIdx, interfBeamf(interfBfidx)).usrs];
                                        end
                                    end
                                end
    
                                %% 计算上行干扰，遍历所有上行干扰用户
                                NumOfinterfUsrsOther = length(interfUsrsOfSatOther);
                                for interfusrOtherIdx = 1 : NumOfinterfUsrsOther
                                    % 计算干扰用户到当前卫星的偏天线指向角
                                    
                                    usrOtherInterfPos = self.UsrsObj(find(self.OrderOfSelectedUsrs==interfUsrsOfSatOther(interfusrOtherIdx))).position; % 干扰用户坐标
                                    usrOtherInterfPosInDescartes = LngLat2Descartes(usrOtherInterfPos, 0);
                                    vectorOfcurSat2interfUsr = [ ...
                                            satPosInDescartes(1) - usrOtherInterfPosInDescartes(1), ...
                                            satPosInDescartes(2) - usrOtherInterfPosInDescartes(2), ...
                                            satPosInDescartes(3) - usrOtherInterfPosInDescartes(3) ...
                                            ];
                                    vectorOfinterfSat2interfUsr = [ ...
                                            interfsatPosInDescartes(1) - usrOtherInterfPosInDescartes(1), ...
                                            interfsatPosInDescartes(2) - usrOtherInterfPosInDescartes(2), ...
                                            interfsatPosInDescartes(3) - usrOtherInterfPosInDescartes(3) ...
                                            ];
                                    OffAxisAngleOther = acos(abs(dot(vectorOfcurSat2interfUsr, vectorOfinterfSat2interfUsr))/...
                                        (sqrt(vectorOfcurSat2interfUsr(1)^2 + vectorOfcurSat2interfUsr(2)^2 + vectorOfcurSat2interfUsr(3)^2) * ...
                                        sqrt(vectorOfinterfSat2interfUsr(1)^2 + vectorOfinterfSat2interfUsr(2)^2 + vectorOfinterfSat2interfUsr(3)^2)));
    
                                    % 计算干扰用户的发射增益
                                    if IfUsrAntennaDeGravity == 1
                                        [tmp_angle, ~, ~] = simSatSysClass.tools.getAngleOfInterfSat(usrOtherInterfPos, satCurPos, usrOtherInterfPos, heightOfsat);
                                        G_otherusr_interfUp = antenna.getUsrAntennaServG(tmp_angle, freqOfUpLink, true);
                                    else                 
                                        G_otherusr_interfUp = antenna.getUsrAntennaServG(OffAxisAngleOther, freqOfUpLink, true);
                                    end

                                    % 获得干扰用户的指向角
                                    [UsrOtherInterfTheta, UsrOtherInterfPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, usrOtherInterfPos, heightOfsat);
            
                                    % 计算干扰用户到当前卫星的距离
                                    distance_Otherinterf = sqrt((satPosInDescartes(1)-usrOtherInterfPosInDescartes(1)).^2 + ...
                                                           (satPosInDescartes(2)-usrOtherInterfPosInDescartes(2)).^2 + ...
                                                           (satPosInDescartes(3)-usrOtherInterfPosInDescartes(3)).^2);
            
                                    % 计算上行干扰
                                    G_Othersat_Up = self.SatObj(SatIdx).getAntennaServG(UsrOtherInterfTheta, UsrOtherInterfPhi, IdxInLightBeamfoot, freqOfUpLink); % 天线接收增益
                                    InterfWithSatUp = InterfWithSatUp + ...
                                        Pt_Usr * G_otherusr_interfUp * G_Othersat_Up * (lambdaUp.^2) / (((4*pi).^2)*(distance_Otherinterf.^2));
                                end                            
                            end
                        end
                        %% C/I
                        if self.Config.numOfMonteCarlo == 0
                            G_sat_down = self.SatObj(SatIdx).getAntennaServG(UsrTheta, UsrPhi, IdxInLightBeamfoot, freqOfDownLink); % 天线发射增益
                            Carrier_down = Pt_SAT_serv * G_sat_down * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
                            DataObj(IdxOfStep).InterfFromAll_Down(MethodIdx, slotIdx, UsrOrderCur, 1) = Carrier_down/(InterfWithSatDown+InterfInSatDown);
                            DataObj(IdxOfStep).InterfFromSingleSat_Down(MethodIdx, slotIdx, UsrOrderCur, 1) = Carrier_down/InterfInSatDown;
                            G_sat_up = self.SatObj(SatIdx).getAntennaServG(UsrTheta, UsrPhi, IdxInLightBeamfoot, freqOfUpLink); % 天线发射增益
                            if IfUsrAntennaDeGravity == 1
                                [tmp_angle, ~, ~] = simSatSysClass.tools.getAngleOfInterfSat(usrCurPos, satCurPos, usrCurPos, heightOfsat);
                                G_usr_up = antenna.getUsrAntennaServG(tmp_angle, freqOfUpLink, true);
                            else                 
                                G_usr_up = antenna.getUsrAntennaServG(0, freqOfUpLink, true);
                            end
                            Carrier_up = Pt_Usr * G_sat_up * G_usr_up * (lambdaUp.^2) / (((4*pi).^2)*(distance.^2));
                            DataObj(IdxOfStep).InterfFromAll_Up(MethodIdx, slotIdx, UsrOrderCur, 1) = Carrier_up/(InterfWithSatUp+InterfInSatUp);
                            DataObj(IdxOfStep).InterfFromSingleSat_Up(MethodIdx, slotIdx, UsrOrderCur, 1) = Carrier_up/InterfInSatUp;
                        else
                            G_sat_down = self.SatObj(SatIdx).getAntennaServG(UsrTheta, UsrPhi, IdxInLightBeamfoot, freqOfDownLink); % 天线发射增益
                            Carrier_down = Pt_SAT_serv * G_sat_down * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
                            DataObj((MC_idx-1)*NumOfShot+IdxOfStep).InterfFromAll_Down(MethodIdx, slotIdx, UsrOrderCur, 1) = Carrier_down/(InterfWithSatDown+InterfInSatDown);
                            DataObj((MC_idx-1)*NumOfShot+IdxOfStep).InterfFromSingleSat_Down(MethodIdx, slotIdx, UsrOrderCur, 1) = Carrier_down/InterfInSatDown;
                            G_sat_up = self.SatObj(SatIdx).getAntennaServG(UsrTheta, UsrPhi, IdxInLightBeamfoot, freqOfUpLink); % 天线发射增益
                            if IfUsrAntennaDeGravity == 1
                                [tmp_angle, ~, ~] = simSatSysClass.tools.getAngleOfInterfSat(usrCurPos, satCurPos, usrCurPos, heightOfsat);
                                G_usr_up = antenna.getUsrAntennaServG(tmp_angle, freqOfUpLink, true);
                            else                 
                                G_usr_up = antenna.getUsrAntennaServG(0, freqOfUpLink, true);
                            end
                            Carrier_up = Pt_Usr * G_sat_up * G_usr_up * (lambdaUp.^2) / (((4*pi).^2)*(distance.^2));
                            DataObj((MC_idx-1)*NumOfShot+IdxOfStep).InterfFromAll_Up(MethodIdx, slotIdx, UsrOrderCur, 1) = Carrier_up/(InterfWithSatUp+InterfInSatUp);
                            DataObj((MC_idx-1)*NumOfShot+IdxOfStep).InterfFromSingleSat_Up(MethodIdx, slotIdx, UsrOrderCur, 1) = Carrier_up/InterfInSatUp;                        
                        end
                        %% C/(I+N)
                        K = 1.38e-23;  % 玻尔兹曼常量
                        Band = self.Config.BandOfLink;  % 带宽
                        Ta_usr = self.UsrsObj(find(self.OrderOfSelectedUsrs==UsrOrderCur)).T_noise;
                        Ta_sat = self.SatObj(SatIdx).T_noise;
                        F_usr = 10.^(self.UsrsObj(find(self.OrderOfSelectedUsrs==UsrOrderCur)).F_noise/10);
                        F_sat = 10.^(self.SatObj(SatIdx).F_noise/10);
                        N_noise_usr = Band*K*(Ta_usr+(F_usr-1)*300);
                        N_noise_sat = Band*K*(Ta_sat+(F_sat-1)*300);

                        if self.Config.numOfMonteCarlo == 0
                            G_sat_down = self.SatObj(SatIdx).getAntennaServG(UsrTheta, UsrPhi, IdxInLightBeamfoot, freqOfDownLink); % 天线发射增益
                            Carrier_down = Pt_SAT_serv * G_sat_down * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
                            DataObj(IdxOfStep).InterfFromAll_Down(MethodIdx, slotIdx, UsrOrderCur, 2) = Carrier_down/(InterfWithSatDown+InterfInSatDown+N_noise_usr);
                            DataObj(IdxOfStep).InterfFromSingleSat_Down(MethodIdx, slotIdx, UsrOrderCur, 2) = Carrier_down/(InterfInSatDown+N_noise_usr);
        
                            G_sat_up = self.SatObj(SatIdx).getAntennaServG(UsrTheta, UsrPhi, IdxInLightBeamfoot, freqOfUpLink); % 天线发射增益
                            if IfUsrAntennaDeGravity == 1
                                [tmp_angle, ~, ~] = simSatSysClass.tools.getAngleOfInterfSat(usrCurPos, satCurPos, usrCurPos, heightOfsat);
                                G_usr_up = antenna.getUsrAntennaServG(tmp_angle, freqOfUpLink, true);
                            else                 
                                G_usr_up = antenna.getUsrAntennaServG(0, freqOfUpLink, true);
                            end
                            Carrier_up = Pt_Usr * G_sat_up * G_usr_up * (lambdaUp.^2) / (((4*pi).^2)*(distance.^2));
                            DataObj(IdxOfStep).InterfFromAll_Up(MethodIdx, slotIdx, UsrOrderCur, 2) = Carrier_up/(InterfWithSatUp+InterfInSatUp+N_noise_sat);
                            DataObj(IdxOfStep).InterfFromSingleSat_Up(MethodIdx, slotIdx, UsrOrderCur, 2) = Carrier_up/(InterfInSatUp+N_noise_sat);

                            DataObj(IdxOfStep).InterSat_UsrsTransPort(MethodIdx, UsrOrderCur, dpIdx) = ...
                                DataObj(IdxOfStep).InterSat_UsrsTransPort(MethodIdx, UsrOrderCur, dpIdx) + ...
                                self.timeInSlot*self.Config.BandOfLink*log2(1+Carrier_up/(InterfWithSatUp+InterfInSatUp+N_noise_sat));
                        else
                            G_sat_down = self.SatObj(SatIdx).getAntennaServG(UsrTheta, UsrPhi, IdxInLightBeamfoot, freqOfDownLink); % 天线发射增益
                            Carrier_down = Pt_SAT_serv * G_sat_down * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
                            DataObj((MC_idx-1)*NumOfShot+IdxOfStep).InterfFromAll_Down(MethodIdx, slotIdx, UsrOrderCur, 2) = Carrier_down/(InterfWithSatDown+InterfInSatDown+N_noise_usr);
                            DataObj((MC_idx-1)*NumOfShot+IdxOfStep).InterfFromSingleSat_Down(MethodIdx, slotIdx, UsrOrderCur, 2) = Carrier_down/(InterfInSatDown+N_noise_usr);
        
                            G_sat_up = self.SatObj(SatIdx).getAntennaServG(UsrTheta, UsrPhi, IdxInLightBeamfoot, freqOfUpLink); % 天线发射增益
                            if IfUsrAntennaDeGravity == 1
                                [tmp_angle, ~, ~] = simSatSysClass.tools.getAngleOfInterfSat(usrCurPos, satCurPos, usrCurPos, heightOfsat);
                                G_usr_up = antenna.getUsrAntennaServG(tmp_angle, freqOfUpLink, true);
                            else                 
                                G_usr_up = antenna.getUsrAntennaServG(0, freqOfUpLink, true);
                            end
                            Carrier_up = Pt_Usr * G_sat_up * G_usr_up * (lambdaUp.^2) / (((4*pi).^2)*(distance.^2));
                            DataObj((MC_idx-1)*NumOfShot+IdxOfStep).InterfFromAll_Up(MethodIdx, slotIdx, UsrOrderCur, 2) = Carrier_up/(InterfWithSatUp+InterfInSatUp+N_noise_sat);
                            DataObj((MC_idx-1)*NumOfShot+IdxOfStep).InterfFromSingleSat_Up(MethodIdx, slotIdx, UsrOrderCur, 2) = Carrier_up/(InterfInSatUp+N_noise_sat);
                            
                            
                        end                        
                    end
                end
            end
            if ifDebug == 1
                if self.Config.numOfMonteCarlo == 0
                    fprintf('第%d快照第%d算法干扰计算%f%%\n', IdxOfStep, MethodIdx, slotIdx*100/NumOfSlotPerShot); 
                else
                    fprintf('蒙特卡洛第%d次第%d快照第%d算法干扰计算%f%%\n', MC_idx, IdxOfStep, MethodIdx, frmIdx*100/NumOfSlotPerShot); 
                end
            end
        end
    end
end

function PosInDescartes = LngLat2Descartes(CurPos, h)
    tmpPhi = CurPos(1) * pi / 180;
    if tmpPhi < 0
        tmpPhi = tmpPhi + 2*pi;
    end
    tmpTheta = (90 - CurPos(2)) * pi / 180;
    R = 6371.393e3; % 地球半径
    tmpX = (R+h) * sin(tmpTheta) * cos(tmpPhi);
    tmpY = (R+h) * sin(tmpTheta) * sin(tmpPhi);
    tmpZ = (R+h) * cos(tmpTheta); 
    PosInDescartes = [tmpX, tmpY, tmpZ];    
end

