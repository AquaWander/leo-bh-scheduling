function BHST_Method3(interface)
% 轮询
%% 预配置
Debug = 1;
OrderOfServSatCur = interface.OrderOfServSatCur;    % 服务卫星的列表
NumOfServSatCur = length(OrderOfServSatCur);    % 服务卫星的数量
NumOfServBeam = interface.numOfServbeam;    % 业务波束数量
Num_scheme = interface.ScheInShot;  % 快照的调度周期数
Num_slot = interface.SlotInSche;    % 调度周期的slot数量
RequiredTraffic = interface.UsrsTraffic(:, 1);  % 请求的业务量列表
TransportedTraffic = zeros(interface.NumOfInvesUsrs, Num_scheme);   % 传输的业务量列表
%% 算法运行     
    %% 遍历所有卫星
    for idxOfSat = 1 : NumOfServSatCur
        UsrsIndex = interface.SatObj(idxOfSat).servUsr; % 星下用户编号列表
        RequiredTraffic_in_Sat = RequiredTraffic(UsrsIndex);    % 星下用户剩余请求业务
        TransportedTraffic_in_Sat = zeros(interface.SatObj(idxOfSat).numOfusrs, Num_scheme);   % 星下用户传输业务
        interface.tmpSat(idxOfSat).BHST = zeros(NumOfServBeam, Num_slot*Num_scheme);
        %% 遍历每个调度周期
        for idxOfSche = 1 : Num_scheme 
%             TransportedTrafficOfBF = zeros(NumOfBeamfoot, 1); % 调度周期的波位业务传输量表格
%             if idxOfSche == 1
%                 RequiredTraffic_in_Sat = RequiredTraffic_in_Sat + ...
%                                 interface.UsrsTraffic(UsrsIndex, idxOfSche+1);  % 第一调度周期的待调度业务为初始业务+第一周期生成的业务
%             else
%                 RequiredTraffic_in_Sat = RequiredTraffic_in_Sat + ...
%                                 interface.UsrsTraffic(UsrsIndex, idxOfSche+1) - ...
%                                 TransportedTraffic_in_Sat(:, idxOfSche-1);  % 第n调度周期的待调度业务为初始业务+第n周期生成的业务-第n-1周期传输的业务
%             end
%             RequiredTraffic_in_Sat(RequiredTraffic_in_Sat<0) = 0;   % 剩余业务量小于0记为0
% 
             NumOfBeamfoot = interface.tmpSat(idxOfSat).NumOfBeamFoot(idxOfSche);    % 波位总数
%                     
             ExecutiveBHST = zeros(NumOfBeamfoot, Num_slot); % 决策计划表
% 
%             RequiredTrafficOfBF = zeros(NumOfBeamfoot, 1); 
%             for tmpk = 1 : NumOfBeamfoot
%                 [~, tmp_idx, ~] = intersect(UsrsIndex, interface.tmpSat(idxOfSat).beamfoot(idxOfSche, tmpk).usrs);
%                 RequiredTrafficOfBF(tmpk) = sum(RequiredTraffic_in_Sat(UsrsIndex(tmp_idx))); % 波位在当前调度周期请求业务
%             end
% 
%             standard_ExecutiveBHST = zeros(NumOfBeamfoot, 1);
%             standard_ExecutiveBHST(1) = 1;
%             standard_TransportedTrafficOfBF = calculateTraffic(idxOfSat, idxOfSche, 1, standard_ExecutiveBHST, interface, Debug);
%             standard_TransportedTrafficOfBF = standard_TransportedTrafficOfBF(1); % 计算无干扰情况下，用户的标准每slot业务传输量
% 
% 
%             Distance = zeros(NumOfBeamfoot, NumOfBeamfoot);  % 记录波位距离的邻接矩阵
%             OrderOfBf = interface.tmpSat(idxOfSat).beamfoot(idxOfSche, 1:NumOfBeamfoot);
%             for idxOfB_1 = 1 : NumOfBeamfoot-1
%                 for idxOfB_2 = idxOfB_1+1 : NumOfBeamfoot
%                     Distance(idxOfB_1, idxOfB_2) = tools.LatLngCoordi2Length( ...
%                                                             OrderOfBf(idxOfB_1).position, ...
%                                                             OrderOfBf(idxOfB_2).position, ...
%                                                             6371.393e3);
%                     Distance(idxOfB_2, idxOfB_1) = Distance(idxOfB_1, idxOfB_2);
%                 end
%             end
% 
%             Distance_R = zeros(NumOfBeamfoot, 1);
%             satCurPos = interface.SatObj(idxOfSat).position; % 当前卫星星下点坐标
%             for idxOfB_3 = 1 : NumOfBeamfoot
%                 Distance_R(idxOfB_3) = tools.LatLngCoordi2Length( ...
%                                                 OrderOfBf(idxOfB_3).position, ...
%                                                 satCurPos, ...
%                                                 6371.393e3);
%             end
% 
%             tmp_RequiredTrafficOfBF = RequiredTrafficOfBF;
            tL = ceil(NumOfBeamfoot/NumOfServBeam);
            for idxOfSlot = 1 : Num_slot
%                 if idxOfSlot < Num_slot
%                     idxOfSlot_tmp = idxOfSlot
%                 end
                
                if mod(idxOfSlot, tL) == 0
                    tI = tL;
                else
                    tI = mod(idxOfSlot, tL);
                end
                
                if tI*NumOfServBeam <= NumOfBeamfoot
                    ExecutiveBHST((tI-1)*NumOfServBeam+1:tI*NumOfServBeam, idxOfSlot) = 1;
                   
                else
                    ExecutiveBHST((tI-1)*NumOfServBeam+1:NumOfBeamfoot, idxOfSlot) = 1;
%                     ExecutiveBHST(1:tI*NumOfServBeam-NumOfBeamfoot, idxOfSlot) = 1;
%                     if idxOfSlot < Num_slot
%                         idxOfSlot_tmp = 1;
%                     end
                end
                
%                 selectedBF = zeros(NumOfServBeam, 1);
%                 for idxOfBeam = 1 : NumOfServBeam
%                     if idxOfBeam == 1
%                         Score = (Distance_R.^2).*tmp_RequiredTrafficOfBF;
%                         idxOfBF = find(Score == max(Score), 1);
%                         selectedBF(idxOfBeam) = idxOfBF;
%                         ExecutiveBHST(idxOfBF, idxOfSlot)= 1;
%                         tmp_RequiredTrafficOfBF(idxOfBF) = tmp_RequiredTrafficOfBF(idxOfBF) - standard_TransportedTrafficOfBF;
%                     else
%                         for idx = 1 : idxOfBeam-1
%                             if idx == 1
%                                 tmp_Distance = Distance(:, selectedBF(idx));
%                             else
%                                 tmp_Distance = tmp_Distance.*Distance(:, selectedBF(idx));
%                             end
%                         end
%                         
%                         idxOfBF = find(tmp_Distance == max(tmp_Distance), 1);
%                         selectedBF(idxOfBeam) = idxOfBF;
%                         ExecutiveBHST(idxOfBF, idxOfSlot)= 1;
%                         tmp_RequiredTrafficOfBF(idxOfBF) = tmp_RequiredTrafficOfBF(idxOfBF) - standard_TransportedTrafficOfBF;
%                     end
%                 end
            end

            TransportedTrafficOfBF = calculateTraffic(idxOfSat, idxOfSche, Num_slot, ExecutiveBHST, interface, Debug); % 计算当前决策的各波位传输业务量   
            
            for tmpk = 1 : NumOfBeamfoot
                usrs = interface.tmpSat(idxOfSat).beamfoot(idxOfSche, tmpk).usrs;
                NofU = length(usrs);
                r_traffic = RequiredTraffic_in_Sat(usrs);
                [~, tmp_idx, ~] = intersect(UsrsIndex, usrs);
                for idx = 1 : NofU
                    TransportedTraffic_in_Sat(tmp_idx(idx), idxOfSche) = sum(TransportedTrafficOfBF(tmpk)).*(r_traffic(idx)./sum(r_traffic));
                end
            end 
            for idx_BHST = 1 : Num_slot
                if length(find(ExecutiveBHST(:,idx_BHST)==1)) < NumOfServBeam
                    interface.tmpSat(idxOfSat).BHST(:, (idxOfSche-1)*Num_slot+idx_BHST) = ...
                            [find(ExecutiveBHST(:,idx_BHST)==1);zeros(NumOfServBeam-length(find(ExecutiveBHST(:,idx_BHST)==1)), 1)];
                else
                    interface.tmpSat(idxOfSat).BHST(:, (idxOfSche-1)*Num_slot+idx_BHST) = ...
                            find(ExecutiveBHST(:,idx_BHST)==1);
                end
            end
        end
        TransportedTraffic(UsrsIndex, :) = TransportedTraffic_in_Sat;
        
    end
    interface.tmp_UsrsTransPort = TransportedTraffic;
end

%% 计算吞吐量
function TransportedTrafficOfBF = calculateTraffic(idxOfSat, idxOfSche, Num_slot, ExecutiveBHST, interface, Debug)
    numOfbeamfoot = length(ExecutiveBHST(:,1));
    TransportedTrafficOfBF = zeros(numOfbeamfoot, 1);
    for idxOfSlot = 1 : Num_slot
        lightedBf = find(ExecutiveBHST(:, idxOfSlot)==1);
        NumOfLightBeamfoot = length(lightedBf);
        PosOfBeam = zeros(NumOfLightBeamfoot, 2);    % 点亮波位中心三角形坐标       
        for bidx = 1 : NumOfLightBeamfoot
            PosOfBeam(bidx, :) = interface.tmpSat(idxOfSat).beamfoot(idxOfSche, lightedBf(bidx)).position; 
        end
        BeamPoint = zeros(NumOfLightBeamfoot, 2); % varphi(俯仰，偏离x轴),vartheta(方向，偏离xOy平面),天线在zOy平面(右手系)
        for j = 1 : NumOfLightBeamfoot
            [outputTheta, outputPhi] = tools.getPointAngleOfUsr(...
                interface.SatObj(idxOfSat).position, interface.SatObj(idxOfSat).nextpos, PosOfBeam(j, :), interface.height);
            BeamPoint(j,1) = outputPhi;
            BeamPoint(j,2) = outputTheta;
        end
%         NumOfExpressedGene = NumOfLightBeamfoot;
%         ExpressedGene = LightBeamfoot;
        SINR_Gene = zeros(NumOfLightBeamfoot, 1);
        for tmpI = 1 : NumOfLightBeamfoot
%             [SINR_Gene(tmpI), ~] = CaculateR(...
            [~, SINR_Gene(tmpI)] = CaculateR(...
                idxOfSat, idxOfSche, ...
                ExecutiveBHST(:, idxOfSlot),...
                lightedBf(tmpI), BeamPoint, interface);
        end
        for idxOfBf = 1 : NumOfLightBeamfoot
            TransportedTrafficOfBF(lightedBf(idxOfBf)) = TransportedTrafficOfBF(lightedBf(idxOfBf)) + ...
                interface.timeInSlot*interface.BandOfLink*1e6*log2(1+SINR_Gene(idxOfBf));
        end
    end          
end
%% 计算碱基的SINR值和SNR值
function [SINR, SNR] = CaculateR(SatIdx, ScheIdx, Gene, i, BeamPoint, interface)
    % 基因上第i个碱基所受到的干扰
    Pt = (10.^((interface.SatObj(SatIdx).Pt_dBm_serv)./10))./1e3./interface.numOfServbeam;   % W
    UsrIdx = interface.tmpSat(SatIdx).beamfoot(ScheIdx, i).usrs;
    T_noise = interface.UsrsObj(UsrIdx(1)).T_noise;
    F_noise_dB = interface.UsrsObj(UsrIdx(1)).F_noise;
    F_noise = 10.^(F_noise_dB./10);
    N0_noise = 1.380649e-23*(T_noise + (F_noise-1)*300);

%     BW = interface.BandOfLink*1e6; % 带宽，单位是Hz
%     T = 300;%开尔文温度，单位是k
%     k = 1.38e-23;%玻尔兹曼常数
%     N0 = k*T*BW;%噪声
    Bandwidth = interface.BandOfLink*1e6;
    ExpressedGene = find(Gene == 1);
    % 计算当前波位中心的指向角 
    usrCurPos = interface.tmpSat(SatIdx).beamfoot(ScheIdx, i).position; % 当前用户坐标    
    satCurPos = interface.SatObj(SatIdx).position; % 当前卫星星下点坐标
    satCurnextPos = interface.SatObj(SatIdx).nextpos; % 当前卫星星下点下一step坐标
    [UsrTheta, UsrPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, usrCurPos, interface.height);%计算方位角和仰角
    % 计算用户接收增益
    G_usrDown = antenna.getUsrAntennaServG(0, interface.freqOfDownLink, false);
    % 计算当前卫星到当前用户的距离
    usrPosInDescartes = LngLat2Descartes(usrCurPos, 0);
    satPosInDescartes = LngLat2Descartes(satCurPos, interface.height);
    distance = sqrt((satPosInDescartes(1)-usrPosInDescartes(1)).^2 + ...
                    (satPosInDescartes(2)-usrPosInDescartes(2)).^2 + ...
                    (satPosInDescartes(3)-usrPosInDescartes(3)).^2);  
    InterfInSatDown = 0;
    lambdaDown = 3e8/interface.freqOfDownLink;
    for bfIdx = 1 : length(ExpressedGene)
        if bfIdx ~= find(ExpressedGene == i)
            poiBeta = BeamPoint(bfIdx,1);
            poiAlpha = BeamPoint(bfIdx,2);
            AgleOfInv = [UsrTheta, UsrPhi];
            AgleOfPoi = [poiAlpha, poiBeta];
            G_sat_interfDown = antenna.getSatAntennaServG(AgleOfInv, AgleOfPoi, interface.freqOfDownLink);
            InterfInSatDown = InterfInSatDown + ...
                Pt * G_sat_interfDown * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
        end
    end
    %%%%%%%%%%%%%%%%%%%%%
    bfIdx = find(ExpressedGene == i);
    poiBeta = BeamPoint(bfIdx,1);
    poiAlpha = BeamPoint(bfIdx,2);
    AgleOfInv = [UsrTheta, UsrPhi];
    AgleOfPoi = [poiAlpha, poiBeta];
    G_sat_down = antenna.getSatAntennaServG(AgleOfInv, AgleOfPoi, interface.freqOfDownLink);
    %%%%%%%%%%%%%%%%%%%%%
    Carrier_down = Pt * G_sat_down * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
    SINR = Carrier_down./(InterfInSatDown + Bandwidth*N0_noise);
    SNR = Carrier_down./(Bandwidth*N0_noise);
end
%%
function PosInDescartes = LngLat2Descartes(CurPos, h)
    tmpPhi = CurPos(1) * pi / 180;
    if tmpPhi < 0
        tmpPhi = tmpPhi + 2*pi;
    end
    tmpTheta = (90 - CurPos(2)) * pi / 180;
    R = 6371.393e3; % 地球半径
    tmpX = (R+h) * sin(tmpTheta) * cos(tmpPhi);
    tmpY = (R+h) * sin(tmpTheta) * sin(tmpPhi);
    tmpZ = (R+h) * cos(tmpTheta); 
    PosInDescartes = [tmpX, tmpY, tmpZ];    
end

