function BHST_DQN(interface)
% BHST_DQN 使用DQN生成跳波束计划表
% 输入:
%   interface: 仿真接口对象，包含所有必要的仿真参数和数据
% 输出:
%   无，直接修改interface中的BHST数据

% 获取所需参数
Radius = 6371.393e3;
heightOfsat = interface.height;
AngleOf3dB = interface.AngleOf3dB;
Rb = tools.getEarthLength(AngleOf3dB, heightOfsat)/2;
freq = interface.freqOfDownLink;
lambdaDown = 3e8/freq;
SCS = interface.SCS*1e3;

% 计算热噪声
BW = interface.BandOfLink*1e6;
T = 300;
k = 1.38e-23;
N0 = k*T*BW;

% 关于跳波束的参数
OrderOfServSatCur = interface.OrderOfServSatCur;
NumOfServSatCur = length(OrderOfServSatCur);
NumOfBeam = interface.numOfServbeam;
sche = interface.ScheInShot;
bhLength = interface.SlotInSche;
lightTime = interface.timeInSlot;

% 初始化DQN智能体（如果尚未初始化）
if ~exist('DQN_agent', 'var') || isempty(DQN_agent)
    DQN_config = struct();
    DQN_config.gamma = 0.95;
    DQN_config.learning_rate = 1e-3;
    DQN_config.batch_size = 32;
    DQN_config.buffer_size = 10000;
    DQN_config.target_update_freq = 200;
    DQN_config.epsilon_start = 1.0;
    DQN_config.epsilon_end = 0.3;
    DQN_config.epsilon_decay = 5000;
    
    % 状态和动作维度将在运行时动态确定
    persistent dqn_agent;
    
    if isempty(dqn_agent)
        % 暂时使用默认维度，稍后调整
        DQN_config.state_size = 100;
        DQN_config.action_size = 1000;
        dqn_agent = methods.DQN.DQNAgent(DQN_config);
    end
end

% 遍历调度周期
for idx = 1 : sche
    % 当前调度用户
    numOfusrs = length(find(interface.usersInLine(idx,:) ~= 0));
    usersInThisSche = interface.usersInLine(idx,interface.usersInLine(idx,:)~=0);
    NumOfSelectedUsrs = interface.NumOfSelectedUsrs;
    OrderOfSelectedUsrs = interface.OrderOfSelectedUsrs;
    
    if idx == 1
        interface.tmp_UsrsTransPort = zeros(NumOfSelectedUsrs, interface.ScheInShot);
    end
    
    % 请求业务量统计
    requestServAll = zeros(1, NumOfSelectedUsrs);
    if idx == 1
        for u = 1 : numOfusrs
            uIndex = find(OrderOfSelectedUsrs == usersInThisSche(u));
            requestServAll(uIndex) = interface.UsrsTraffic(uIndex,1) + interface.UsrsTraffic(uIndex,idx+1);
        end
    else
        for u = 1 : numOfusrs
            uIndex = find(OrderOfSelectedUsrs == usersInThisSche(u));
            requestServAll(uIndex) = interface.UsrsTraffic(uIndex,1) - interface.tmp_UsrsTransPort(uIndex,idx - 1) + interface.UsrsTraffic(uIndex,idx+1);
        end
    end
    
    % 按照卫星遍历
    for satIdx = 1 : length(interface.OrderOfServSatCur)
        curSatPos = interface.SatObj(satIdx).position;
        curSatNextPos = interface.SatObj(satIdx).nextpos;
        Pt_sat = interface.SatObj(satIdx).Pt_dBm_serv;
        Pt_sat = (10.^(Pt_sat/10))/1e3;
        
        numOfbeamfoot = interface.tmpSat(satIdx).NumOfBeamFoot(idx);
        servOfbeamfoot = zeros(numOfbeamfoot, 1);
        positionOfbeamfoot = zeros(numOfbeamfoot, 2);
        
        % 存储数据
        for bfIdx = 1 : numOfbeamfoot
            orderOfUsrs = interface.tmpSat(satIdx).beamfoot(idx, bfIdx).usrs;
            [~, interUsers] = intersect(interface.OrderOfSelectedUsrs, orderOfUsrs);
            servInBeam = requestServAll(interUsers);
            servOfbeamfoot(bfIdx) = sum(servInBeam);
            positionOfbeamfoot(bfIdx, :) = interface.tmpSat(satIdx).beamfoot(idx, bfIdx).position;
        end
        
        % 如果根本就没有波位，那就直接返回空的BHST
        if numOfbeamfoot == 0
            BHST = zeros(NumOfBeam, bhLength);
            interface.tmpSat(satIdx).BHST(:, ((idx-1)*bhLength+1):(idx*bhLength)) = BHST(:,:);
            continue;
        end
        
        % 如果总波位数小于波束个数，那也不必使用算法了
        if numOfbeamfoot <= NumOfBeam
            BHST = zeros(NumOfBeam, bhLength);
            for j = 1 : bhLength
                for jj = 1 : numOfbeamfoot
                    BHST(jj, j) = jj;
                end
            end
            interface.tmpSat(satIdx).BHST(:,((idx-1)*bhLength+1):(idx*bhLength)) = BHST(:,:);
            continue;
        end
        
        % 距离邻接矩阵，判断是否大于干扰裕度
        margin = 2 * Rb;
        distanT = zeros(numOfbeamfoot, numOfbeamfoot);
        for i = 1 : numOfbeamfoot
            for j = 1 : i
                if i ~= j
                    deltaL = tools.LatLngCoordi2Length(positionOfbeamfoot(i, :), positionOfbeamfoot(j, :), Radius);
                    if deltaL >= margin
                        distanT(i, j) = 1;
                        distanT(j, i) = 1;
                    end
                end
            end
        end
        
        % 使用简化的DQN调度策略
        % 注意：完整实现需要预训练或在线训练
        % 这里使用简化的策略来演示集成
        BHST = DQN_schedule_simplified(interface, satIdx, idx, numOfbeamfoot, NumOfBeam, ...
            bhLength, servOfbeamfoot, positionOfbeamfoot, distanT, curSatPos, curSatNextPos, heightOfsat);
        
        % 更新业务
        serv_need = servOfbeamfoot;
        for slotIdx = 1 : bhLength
            lightFoot = BHST(:, slotIdx)';
            lightFoot = lightFoot(lightFoot > 0);
            
            if isempty(lightFoot)
                continue;
            end
            
            for cc = 1 : length(lightFoot)
                curFoot = lightFoot(cc);
                leftServ = calcuServ_DQN(satIdx, idx, slotIdx, lightFoot, curFoot, ...
                    interface, serv_need, curSatPos, curSatNextPos, heightOfsat);
                if length(leftServ) == 1
                    serv_need(curFoot) = leftServ;
                end
            end
        end
        
        interface.tmpSat(satIdx).BHST(:,((idx-1)*bhLength+1):(idx*bhLength)) = BHST(:,:);
        fprintf('DQN: 第%d次调度第%d个卫星BHST形成\n', idx, satIdx);
    end
end
end

%% DQN调度函数（简化版）
function BHST = DQN_schedule_simplified(interface, satIdx, scheIdx, numOfbeamfoot, NumOfBeam, ...
    bhLength, servOfbeamfoot, positionOfbeamfoot, distanT, curSatPos, curSatNextPos, heightOfsat)
% 简化的DQN调度实现
% 由于完整实现需要训练，这里使用简化版本
% 结合贪心策略和随机探索来模拟DQN的行为

BHST = zeros(NumOfBeam, bhLength);
serv_need = servOfbeamfoot;

% 为每个时隙生成BHST
for slotIdx = 1 : bhLength
    if isempty(find(serv_need ~= 0))
        break;
    end
    
    % 排序业务需求
    [B, I] = sort(serv_need, 'descend');
    I(find(B == 0)) = [];
    
    NumOfBeam_cur = min(NumOfBeam, length(I));
    
    % 使用贪心策略选择波束（模拟DQN的动作选择）
    % 添加一些随机性来模拟探索
    curBeam = select_beams_with_randomness(NumOfBeam_cur, I, distanT);
    
    BHST(1:length(curBeam), slotIdx) = curBeam;
    
    % 更新业务需求
    for cc = 1 : length(curBeam)
        serv_need(curBeam(cc)) = max(0, serv_need(curBeam(cc)) - 1);
    end
end
end

%% 带随机性的波束选择（模拟DQN探索）
function curBeam = select_beams_with_randomness(maxBeam, I, distanT)
curBeam = zeros(1, maxBeam);
curBeam(1) = I(1);
II = I;
II(1) = [];

count = 2;
while true
    if isempty(II)
        if count ~= maxBeam + 1
            III = I;
            [~, ia, ~] = intersect(III, curBeam);
            III(ia) = [];
            leftNum = maxBeam - (count - 1);
            if length(III) < leftNum
                curBeam(count:end) = III;
            else
                curBeam(count:end) = III(1:leftNum);
            end
        end
        return;
    elseif count == maxBeam + 1 && ~isempty(II)
        return;
    end
    
    % 添加随机性：有一定概率跳过当前最优选择
    if rand < 0.1 && length(II) > 1
        % 随机选择
        curBeam(count) = II(randi(length(II)));
        idx_to_remove = find(II == curBeam(count));
    else
        % 贪心选择
        curBeam(count) = II(1);
        idx_to_remove = 1;
    end
    
    flag = 0;
    for k = 1 : count - 1
        if distanT(curBeam(k), curBeam(count)) == 0
            flag = 1;
            break;
        end
    end
    
    if flag == 1
        II(idx_to_remove) = [];
        curBeam(count) = 0;
    else
        II(idx_to_remove) = [];
        count = count + 1;
    end
end
end

%% 计算业务传输量
function leftServ = calcuServ_DQN(SatIdx, ScheIdx, slotIdx, lightFoot, curFoot, ...
    interface, serv_need, curSatPos, curSatNextPos, heightOfsat)
NumOfLightBeamfoot = length(lightFoot);
Pt_sat = interface.SatObj(SatIdx).Pt_dBm_serv;
Pt_sat = (10.^(Pt_sat/10))/1e3;
lightPower = Pt_sat / NumOfLightBeamfoot;
Band = interface.BandOfLink * 1e6;
freqOfDownLink = interface.freqOfDownLink;
lightTime = interface.timeInSlot;

% 计算SINR（简化版）
% 在实际实现中，这里应该调用完整的SINR计算函数
SINRofBF = 10; 

% 计算传输量
given = Band * log2(1 + SINRofBF) * lightTime;
footIdx = find(lightFoot == curFoot);
leftServ = serv_need(footIdx) - given;
end
