%% 需求偏斜实验脚本
% 对比不同流量分布模式下的算法性能
% 
% 实验设计:
%   - Uniform: 所有用户需求相同
%   - Light Skew: 需求差异2倍
%   - Heavy Skew: 需求差异5倍
%   - Pareto (80/20): 20%用户占80%需求
%
% 作者: 2025-03-04
% 版本: 1.0

clear; clc; close all;

addpath(genpath('.'));

fprintf('========================================\n');
fprintf('   需求偏斜实验\n');
fprintf('========================================\n\n');

%% 实验配置
traffic_modes = {'uniform', 'light_skew', 'heavy_skew', 'pareto'};
num_modes = length(traffic_modes);
num_runs = 2;  % 每组实验运行次数
save_results = true;

%% 初始化结果存储
results = struct();
for i = 1:num_modes
    results.(traffic_modes{i}) = [];
end

%% 运行实验
for mode_idx = 1:num_modes
    traffic_mode = traffic_modes{mode_idx};
    
    fprintf('====================================\n');
    fprintf('实验: %s 流量分布\n', traffic_mode);
    fprintf('====================================\n\n');
    
    for run = 1:num_runs
        fprintf('  运行第 %d/%d 次...\n', run, num_runs);
        
        % 清除工作区
        clearvars -except traffic_modes num_modes num_runs save_results results traffic_mode mode_idx run
        addpath(genpath('.'));
        
        % 加载并修改配置
        setConfig;
        Config.enable_SA = true;
        Config.L_tabu_mode = 'adaptive';
        Config.traffic_mode = traffic_mode;
        
        switch traffic_mode
            case 'uniform'
                Config.traffic_skew_factor = 1;
            case 'light_skew'
                Config.traffic_skew_factor = 2;
            case 'heavy_skew'
                Config.traffic_skew_factor = 5;
            case 'pareto'
                Config.pareto_alpha = 1.5;
        end
        
        tic;
        try
            % 运行仿真
            controller = simSatSysClass.simController(Config, 1, 1, 0);
            DataObj = controller.run();
            
            elapsed_time = toc;
            
            % 计算性能指标
            throughput = calcuThroughput(DataObj);
            satisfaction = calcuSatis(DataObj);
            
            metrics = struct();
            metrics.throughput = throughput;
            metrics.satisfaction = satisfaction;
            metrics.time = elapsed_time;
            
            results.(traffic_mode) = [results.(traffic_mode); metrics];
            
            fprintf('    - 吞吐量: %.2f Mbps\n', throughput/1e6);
            fprintf('    - 满足率: %.2f%%\n', satisfaction*100);
            fprintf('    - 耗时: %.2f 秒\n\n', elapsed_time);
            
        catch ME
            fprintf('    ERROR: %s\n\n', ME.message);
            results.(traffic_mode) = [results.(traffic_mode); struct('throughput', NaN, 'satisfaction', NaN, 'time', NaN)];
        end
    end
end

%% 统计分析
fprintf('========================================\n');
fprintf('          实验结果汇总\n');
fprintf('========================================\n\n');

fprintf('%-15s %15s %15s\n', '流量模式', '吞吐量(Mbps)', '满足率(%)');
fprintf('%-15s %15s %15s\n', '---------------', '---------------', '---------------');

avg_results = struct();
for mode_idx = 1:num_modes
    traffic_mode = traffic_modes{mode_idx};
    
    valid_data = results.(traffic_mode);
    if ~isempty(valid_data) && any(~isnan([valid_data.throughput]))
        avg_throughput = mean([valid_data.throughput], 'omitnan');
        avg_satisfaction = mean([valid_data.satisfaction], 'omitnan');
        
        avg_results.(traffic_mode) = struct('throughput', avg_throughput, 'satisfaction', avg_satisfaction);
        
        fprintf('%-15s %12.2f Mbps %14.2f%%\n', traffic_mode, avg_throughput/1e6, avg_satisfaction*100);
    else
        fprintf('%-15s %15s %15s\n', traffic_mode, 'N/A', 'N/A');
    end
end

fprintf('\n');

%% 生成对比图表
fprintf('[5] 生成对比图表...\n');

figure('Position', [100, 100, 1000, 400]);

% 子图1: 吞吐量对比
subplot(1, 2, 1);
throughput_data = zeros(1, num_modes);
for mode_idx = 1:num_modes
    traffic_mode = traffic_modes{mode_idx};
    if isfield(avg_results, traffic_mode)
        throughput_data(mode_idx) = avg_results.(traffic_mode).throughput / 1e6;
    else
        throughput_data(mode_idx) = NaN;
    end
end

bar(throughput_data, 'FaceColor', [0.3, 0.6, 0.9]);
set(gca, 'XTick', 1:num_modes, 'XTickLabel', {'Uniform', 'Light Skew', 'Heavy Skew', 'Pareto'}, 'FontSize', 10);
ylabel('吞吐量 (Mbps)', 'FontSize', 11);
title('不同流量分布下的吞吐量', 'FontSize', 12);
grid on;

% 添加数值标签
for i = 1:num_modes
    if ~isnan(throughput_data(i))
        text(i, throughput_data(i)*1.02, sprintf('%.2f', throughput_data(i)), 'HorizontalAlignment', 'center', 'FontSize', 9);
    end
end

% 子图2: 服务满足率对比
subplot(1, 2, 2);
satisfaction_data = zeros(1, num_modes);
for mode_idx = 1:num_modes
    traffic_mode = traffic_modes{mode_idx};
    if isfield(avg_results, traffic_mode)
        satisfaction_data(mode_idx) = avg_results.(traffic_mode).satisfaction * 100;
    else
        satisfaction_data(mode_idx) = NaN;
    end
end

bar(satisfaction_data, 'FaceColor', [0.9, 0.5, 0.3]);
set(gca, 'XTick', 1:num_modes, 'XTickLabel', {'Uniform', 'Light Skew', 'Heavy Skew', 'Pareto'}, 'FontSize', 10);
ylabel('服务满足率 (%)', 'FontSize', 11);
title('不同流量分布下的服务满足率', 'FontSize', 12);
grid on;

% 添加数值标签
for i = 1:num_modes
    if ~isnan(satisfaction_data(i))
        text(i, satisfaction_data(i)*1.02, sprintf('%.2f%%', satisfaction_data(i)), 'HorizontalAlignment', 'center', 'FontSize', 9);
    end
end

% 保存图表
if save_results
    if ~exist('results', 'dir')
        mkdir('results');
    end
    timestamp = datestr(now, 'yyyy-mm-dd_HH-MM-SS');
    saveas(gcf, sprintf('results/traffic_skew_experiment_%s.png', timestamp));
    fprintf('   OK 图表已保存\n');
    
    % 保存结果数据
    save(sprintf('results/traffic_skew_experiment_%s.mat', timestamp), 'results', 'avg_results', 'traffic_modes');
    fprintf('   OK 结果已保存\n');
end

fprintf('\n========================================\n');
fprintf('   需求偏斜实验完成！\n');
fprintf('========================================\n\n');

fprintf('注意: 完整实验结果已保存，可导入论文Table IV\n');
