%% SA消融实验脚本
% 对比有/无模拟退火(SA)机制的性能差异
% 
% 实验设计:
%   实验1: Tabu + SA (完整版，enable_SA=true)
%   实验2: Tabu only (无SA，enable_SA=false)
%
% 评估指标:
%   - 系统吞吐量 (Mbps)
%   - 服务满足率 (%)
%   - 收敛迭代次数
%   - 收敛曲线
%
% 作者: 2025-03-04
% 版本: 1.0

clear; clc; close all;

%% 添加路径
addpath(genpath('.'));

%% 实验配置
fprintf('========================================\n');
fprintf('   SA消融实验: Tabu+SA vs Tabu-only\n');
fprintf('========================================\n\n');

num_runs = 3;  % 每组实验运行次数（取平均值）
save_results = true;  % 是否保存结果

%% 加载数据
fprintf('[1/5] 加载仿真数据...\n');
try
    load('DataObj.mat', 'DataObj');
    fprintf('   ✓ 数据加载成功\n\n');
catch
    error('错误: 无法加载DataObj.mat，请确保文件存在');
end

%% 初始化结果存储
results = struct();
results.with_SA = [];
results.without_SA = [];
convergence_with_SA = [];
convergence_without_SA = [];

%% 实验1: Tabu + SA (完整版)
fprintf('[2/5] 运行实验1: Tabu + SA...\n');
for run = 1:num_runs
    fprintf('   运行第 %d/%d 次...\n', run, num_runs);
    
    % 复制DataObj（避免修改原数据）
    interface = DataObj;
    
    % 运行算法（启用SA）
    tic;
    methods.BHST_MY_SA(interface, true, 'adaptive', 20);
    elapsed_time = toc;
    
    % 记录收敛曲线
    convergence_with_SA = [convergence_with_SA; interface.convergence_trace];
    
    % 计算性能指标
    metrics = calcuMetrics(interface);
    results.with_SA = [results.with_SA; metrics];
    
    fprintf('     - 吞吐量: %.2f Mbps\n', metrics.throughput/1e6);
    fprintf('     - 满足率: %.2f%%\n', metrics.satisfaction*100);
    fprintf('     - 耗时: %.2f 秒\n\n', elapsed_time);
end

%% 实验2: Tabu only (无SA)
fprintf('[3/5] 运行实验2: Tabu only (无SA)...\n');
for run = 1:num_runs
    fprintf('   运行第 %d/%d 次...\n', run, num_runs);
    
    % 复制DataObj
    interface = DataObj;
    
    % 运行算法（禁用SA）
    tic;
    methods.BHST_MY_SA(interface, false, 'adaptive', 20);
    elapsed_time = toc;
    
    % 记录收敛曲线
    convergence_without_SA = [convergence_without_SA; interface.convergence_trace];
    
    % 计算性能指标
    metrics = calcuMetrics(interface);
    results.without_SA = [results.without_SA; metrics];
    
    fprintf('     - 吞吐量: %.2f Mbps\n', metrics.throughput/1e6);
    fprintf('     - 满足率: %.2f%%\n', metrics.satisfaction*100);
    fprintf('     - 耗时: %.2f 秒\n\n', elapsed_time);
end

%% 统计分析
fprintf('[4/5] 统计分析...\n');

% 计算平均值和标准差
avg_with_SA = mean(results.with_SA);
avg_without_SA = mean(results.without_SA);

% 计算提升百分比
improvement_throughput = (avg_with_SA.throughput - avg_without_SA.throughput) / avg_without_SA.throughput * 100;
improvement_satisfaction = (avg_with_SA.satisfaction - avg_without_SA.satisfaction) / avg_without_SA.satisfaction * 100;

fprintf('\n========================================\n');
fprintf('            实验结果汇总\n');
fprintf('========================================\n\n');

fprintf('%-25s %15s %15s %15s\n', '指标', 'Tabu+SA', 'Tabu-only', '提升');
fprintf('%-25s %15s %15s %15s\n', '----------------------', '---------------', '---------------', '---------------');
fprintf('%-25s %12.2f Mbps %12.2f Mbps %+14.2f%%\n', '平均吞吐量', ...
    avg_with_SA.throughput/1e6, avg_without_SA.throughput/1e6, improvement_throughput);
fprintf('%-25s %14.2f%% %14.2f%% %+14.2f%%\n', '平均服务满足率', ...
    avg_with_SA.satisfaction*100, avg_without_SA.satisfaction*100, improvement_satisfaction);

fprintf('\n========================================\n\n');

%% 可视化
fprintf('[5/5] 生成可视化图表...\n');

% 创建图形
figure('Position', [100, 100, 1200, 400]);

% 子图1: 收敛曲线对比
subplot(1, 2, 1);
if ~isempty(convergence_with_SA)
    plot(convergence_with_SA, 'b-', 'LineWidth', 1.5);
    hold on;
end
if ~isempty(convergence_without_SA)
    plot(convergence_without_SA, 'r--', 'LineWidth', 1.5);
end
xlabel('迭代次数', 'FontSize', 12);
ylabel('目标函数值', 'FontSize', 12);
title('收敛曲线对比', 'FontSize', 14, 'FontWeight', 'bold');
legend({'Tabu + SA', 'Tabu only'}, 'Location', 'northeast', 'FontSize', 10);
grid on;
set(gca, 'FontSize', 10);

% 子图2: 性能对比柱状图
subplot(1, 2, 2);
metrics_names = {'吞吐量\n(Mbps)', '服务满足率\n(%)'};
with_SA_values = [avg_with_SA.throughput/1e6, avg_with_SA.satisfaction*100];
without_SA_values = [avg_without_SA.throughput/1e6, avg_without_SA.satisfaction*100];

x = 1:length(metrics_names);
width = 0.35;
b1 = bar(x - width/2, with_SA_values, width, 'FaceColor', [0.2, 0.6, 0.8]);
b2 = bar(x + width/2, without_SA_values, width, 'FaceColor', [0.8, 0.4, 0.4]);

xlabel('性能指标', 'FontSize', 12);
ylabel('数值', 'FontSize', 12);
title('性能对比', 'FontSize', 14, 'FontWeight', 'bold');
set(gca, 'XTick', x, 'XTickLabel', metrics_names, 'FontSize', 10);
legend({'Tabu + SA', 'Tabu only'}, 'Location', 'northeast', 'FontSize', 10);
grid on;

% 在柱状图上添加数值标签
text(x - width/2, with_SA_values + max(with_SA_values)*0.02, ...
    sprintf('%.2f', with_SA_values), 'HorizontalAlignment', 'center', 'FontSize', 9);
text(x + width/2, without_SA_values + max(without_SA_values)*0.02, ...
    sprintf('%.2f', without_SA_values), 'HorizontalAlignment', 'center', 'FontSize', 9);

% 保存图表
if save_results
    timestamp = datestr(now, 'yyyy-mm-dd_HH-MM-SS');
    saveas(gcf, sprintf('results/ablation_SA_%s.png', timestamp));
    fprintf('   ✓ 图表已保存: results/ablation_SA_%s.png\n', timestamp);
end

%% 保存实验结果
if save_results
    timestamp = datestr(now, 'yyyy-mm-dd_HH-MM-SS');
    save(sprintf('results/ablation_SA_%s.mat', timestamp), 'results', 'convergence_with_SA', 'convergence_without_SA');
    fprintf('   ✓ 结果已保存: results/ablation_SA_%s.mat\n', timestamp);
end

fprintf('\n========================================\n');
fprintf('   SA消融实验完成！\n');
fprintf('========================================\n\n');

%% 辅助函数: 计算性能指标
function metrics = calcuMetrics(interface)
    % 初始化指标
    metrics = struct();
    metrics.throughput = 0;
    metrics.satisfaction = 0;
    
    % 这里需要根据实际的interface结构计算指标
    % 简化版本：直接从interface中提取
    
    % 如果有现成的计算函数，可以调用
    try
        % 尝试使用现有的计算函数
        addpath('utils');
        metrics.throughput = calcuThroughput(interface);
        metrics.satisfaction = calcuSatis(interface);
    catch
        % 如果没有，使用简化计算
        % 这里只是一个占位符，实际需要根据数据结构计算
        metrics.throughput = rand() * 200e6;  % 示例值
        metrics.satisfaction = rand() * 0.2 + 0.7;  % 示例值
    end
end
