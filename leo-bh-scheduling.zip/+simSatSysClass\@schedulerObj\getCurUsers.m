function getCurUsers(self, sche)
% 获取sche调度周期下的用户，生成待服务用户的序列usersInLine

if sche == 1
    % 在第一个调度周期下，根据激活比例随机选用户
    self.interface.usersInLine = zeros(self.interface.ScheInShot, self.interface.NumOfSelectedUsrs);
    userNum = floor(self.interface.Config.activePercent * self.interface.NumOfSelectedUsrs);    
    userInLineIndex = randperm(self.interface.NumOfSelectedUsrs, userNum);%这个的编号就是对应着userObj的编号!!!
    userInLine = self.interface.OrderOfSelectedUsrs(userInLineIndex);%最后还是用了OrderOfSelectedUsrs里的编号
    self.interface.usersInLine(sche, 1:length(userInLine)) = userInLine;    

    % 重新为satobj获得用户
    user2sat = zeros(userNum,2);
    for i = 1 : userNum
        userId = userInLine(i);
        user2sat(i, 1) = userId;
        user2sat(i, 2) = self.interface.UsrsObj(find(self.interface.OrderOfSelectedUsrs == userId)).homeSat;
    end
    OrderOfServSatCur = self.interface.OrderOfServSatCur;
    for satId = 1 : length(OrderOfServSatCur)
        self.interface.SatObj(satId).servUsr = [];
        self.interface.SatObj(satId).numOfusrs = [];

        curSatId = OrderOfServSatCur(satId);
        temp = find(user2sat(:,2) == curSatId);
        self.interface.SatObj(satId).servUsr(sche,1:length(temp)) = sort(userInLine(temp));
        self.interface.SatObj(satId).numOfusrs(sche) = length(temp);
    end

else
    if self.interface.Config.numOfSigbeam == 2
        userInLine = self.interface.usersInLine(sche - 1, self.interface.usersInLine(sche - 1, : )~=0);
    
        % 非第一个调度周期时，新接入用户 + 已传输完毕用户
        OrderOfServSatCur = self.interface.OrderOfServSatCur;
        for satId = 1 : length(OrderOfServSatCur)
            SignalBeamfoot = self.interface.SatObj(satId).SignalBeamfoot;
    
            % 当前的时间线
            curTime = self.interface.SlotInSche * (sche - 1);
        
            % 统计在当前时间线是不是有已经出现三次的信令波位
            tb1 = tabulate(self.interface.SatObj(satId).TableOfSig(1,1:curTime));
            tb2 = tabulate(self.interface.SatObj(satId).TableOfSig(2,1:curTime));
            already3 = find(tb1(:,2) >= 3);
            temp = find(tb2(:,2) >= 3);
            already3 = [already3;temp];
        
            %从这些波位里的未选择用户里接入新用户
            newUsers = [];
            if ~isempty(already3)
                for i = 1 : length(already3)
                    curSig = already3(i,1);
                    userInThisSig = SignalBeamfoot(curSig).usrs;%这个是在OrderOfSelectedUsrs里的编号
                    diff = setdiff(userInThisSig ,userInLine);%矩阵A减矩阵B的差集
                    diff = intersect(diff, self.interface.OrderOfSelectedUsrs);
                    if ~isempty(diff)
                        randChoose = randperm(length(diff),1);
                        newUsers = [newUsers diff(randChoose)];
                    end
                end
            end
            userInLine = [userInLine newUsers];
        end
    
        self.interface.usersInLine(sche, 1 : length(userInLine)) = userInLine;
    
        % 重新为satobj获得用户
        userNum = length(userInLine);
        user2sat = zeros(userNum,2);
        for i = 1 : userNum
            userId = userInLine(i);
            user2sat(i, 1) = userId;
    %         if isempty(find(self.interface.OrderOfSelectedUsrs == userId))
    %             fprintf('aaa');
    %         end
            user2sat(i, 2) = self.interface.UsrsObj(find(self.interface.OrderOfSelectedUsrs == userId)).homeSat;
        end
        OrderOfServSatCur = self.interface.OrderOfServSatCur;
        for satId = 1 : length(OrderOfServSatCur)
            curSatId = OrderOfServSatCur(satId);
            temp = find(user2sat(:,2) == curSatId);
            self.interface.SatObj(satId).servUsr(sche,1:length(temp)) = sort(userInLine(temp)); % 在servUsr里存的是OrderOfSelectedUsrs编号
            self.interface.SatObj(satId).numOfusrs(sche) = length(temp);
        end
    elseif self.interface.Config.numOfSigbeam == 0
        %没有新用户，保持一样就行
        userInLine = self.interface.usersInLine(sche - 1, :);
        self.interface.usersInLine(sche, 1 : length(userInLine)) = userInLine;
    
        % 重新为satobj获得用户
        OrderOfServSatCur = self.interface.OrderOfServSatCur;
        for satId = 1 : length(OrderOfServSatCur)
            lastServ = self.interface.SatObj(satId).servUsr(sche - 1,:);
            self.interface.SatObj(satId).servUsr(sche,1:length(lastServ)) = lastServ;
            self.interface.SatObj(satId).numOfusrs(sche) = self.interface.SatObj(satId).numOfusrs(sche - 1);
        end

    end

end

end