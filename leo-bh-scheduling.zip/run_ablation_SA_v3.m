%% SA消融实验脚本 - 完整版
% 对比有/无模拟退火(SA)机制的性能差异
%
% 使用方法:
%   1. 直接运行此脚本
%   2. 脚本会自动修改Config并运行仿真
%   3. 结果保存在results目录
%
% 作者: 2025-03-04
% 版本: 3.0

clear; clc; close all;

addpath(genpath('.'));

fprintf('========================================\n');
fprintf('   SA消融实验: Tabu+SA vs Tabu-only\n');
fprintf('========================================\n\n');

%% 实验配置
num_runs = 2;  % 每组实验运行次数（建议2-5次）
save_results = true;

%% 实验1: Tabu + SA
fprintf('====================================\n');
fprintf('实验1: Tabu + SA (启用模拟退火)\n');
fprintf('====================================\n\n');

results_with_SA = [];
times_with_SA = [];

for run = 1:num_runs
    fprintf('运行第 %d/%d 次...\n', run, num_runs);
    
    % 清除工作区
    clearvars -except num_runs save_results results_with_SA times_with_SA results_without_SA times_without_SA
    addpath(genpath('.'));
    
    % 加载并修改配置
    setConfig;
    Config.enable_SA = true;        % 启用SA
    Config.L_tabu_mode = 'adaptive'; % 自适应禁忌长度
    
    tic;
    try
        % 运行仿真
        controller = simSatSysClass.simController(Config, 1, 1, 0);
        DataObj = controller.run();
        
        elapsed_time = toc;
        
        % 计算性能指标
        throughput = calcuThroughput(DataObj);
        satisfaction = calcuSatis(DataObj);
        
        results_with_SA = [results_with_SA; struct('throughput', throughput, 'satisfaction', satisfaction, 'time', elapsed_time)];
        times_with_SA = [times_with_SA; elapsed_time];
        
        fprintf('  OK 完成\n');
        fprintf('    - 吞吐量: %.2f Mbps\n', throughput/1e6);
        fprintf('    - 满足率: %.2f%%\n', satisfaction*100);
        fprintf('    - 耗时: %.2f 秒\n\n', elapsed_time);
        
    catch ME
        fprintf('  ERROR: %s\n\n', ME.message);
        results_with_SA = [results_with_SA; struct('throughput', NaN, 'satisfaction', NaN, 'time', NaN)];
        times_with_SA = [times_with_SA; NaN];
    end
end

%% 实验2: Tabu only (无SA)
fprintf('====================================\n');
fprintf('实验2: Tabu only (无模拟退火)\n');
fprintf('====================================\n\n');

results_without_SA = [];
times_without_SA = [];

for run = 1:num_runs
    fprintf('运行第 %d/%d 次...\n', run, num_runs);
    
    % 清除工作区
    clearvars -except num_runs save_results results_with_SA times_with_SA results_without_SA times_without_SA
    addpath(genpath('.'));
    
    % 加载并修改配置
    setConfig;
    Config.enable_SA = false;       % 禁用SA
    Config.L_tabu_mode = 'adaptive'; % 自适应禁忌长度
    
    tic;
    try
        % 运行仿真
        controller = simSatSysClass.simController(Config, 1, 1, 0);
        DataObj = controller.run();
        
        elapsed_time = toc;
        
        % 计算性能指标
        throughput = calcuThroughput(DataObj);
        satisfaction = calcuSatis(DataObj);
        
        results_without_SA = [results_without_SA; struct('throughput', throughput, 'satisfaction', satisfaction, 'time', elapsed_time)];
        times_without_SA = [times_without_SA; elapsed_time];
        
        fprintf('  OK 完成\n');
        fprintf('    - 吞吐量: %.2f Mbps\n', throughput/1e6);
        fprintf('    - 满足率: %.2f%%\n', satisfaction*100);
        fprintf('    - 耗时: %.2f 秒\n\n', elapsed_time);
        
    catch ME
        fprintf('  ERROR: %s\n\n', ME.message);
        results_without_SA = [results_without_SA; struct('throughput', NaN, 'satisfaction', NaN, 'time', NaN)];
        times_without_SA = [times_without_SA; NaN];
    end
end

%% 统计分析
fprintf('========================================\n');
fprintf('          实验结果汇总\n');
fprintf('========================================\n\n');

% 过滤有效数据
valid_with_SA = ~isnan([results_with_SA.throughput]);
valid_without_SA = ~isnan([results_without_SA.throughput]);

if sum(valid_with_SA) > 0 && sum(valid_without_SA) > 0
    avg_throughput_with_SA = mean([results_with_SA(valid_with_SA).throughput]);
    avg_throughput_without_SA = mean([results_without_SA(valid_without_SA).throughput]);
    avg_satisfaction_with_SA = mean([results_with_SA(valid_with_SA).satisfaction]);
    avg_satisfaction_without_SA = mean([results_without_SA(valid_without_SA).satisfaction]);
    
    improvement_throughput = (avg_throughput_with_SA - avg_throughput_without_SA) / avg_throughput_without_SA * 100;
    improvement_satisfaction = (avg_satisfaction_with_SA - avg_satisfaction_without_SA) / avg_satisfaction_without_SA * 100;
    
    fprintf('%-25s %15s %15s %15s\n', '指标', 'Tabu+SA', 'Tabu-only', '提升');
    fprintf('%-25s %15s %15s %15s\n', '----------------------', '---------------', '---------------', '---------------');
    fprintf('%-25s %12.2f Mbps %12.2f Mbps %+14.2f%%\n', '平均吞吐量', ...
        avg_throughput_with_SA/1e6, avg_throughput_without_SA/1e6, improvement_throughput);
    fprintf('%-25s %14.2f%% %14.2f%% %+14.2f%%\n', '平均服务满足率', ...
        avg_satisfaction_with_SA*100, avg_satisfaction_without_SA*100, improvement_satisfaction);
    fprintf('\n');
    
    % 生成对比图
    figure('Position', [100, 100, 1000, 400]);
    
    subplot(1, 2, 1);
    bar([avg_throughput_with_SA/1e6, avg_throughput_without_SA/1e6]);
    set(gca, 'XTickLabel', {'Tabu + SA', 'Tabu only'});
    ylabel('吞吐量 (Mbps)');
    title('吞吐量对比');
    grid on;
    text(1, avg_throughput_with_SA/1e6*1.02, sprintf('%.2f', avg_throughput_with_SA/1e6), 'HorizontalAlignment', 'center');
    text(2, avg_throughput_without_SA/1e6*1.02, sprintf('%.2f', avg_throughput_without_SA/1e6), 'HorizontalAlignment', 'center');
    
    subplot(1, 2, 2);
    bar([avg_satisfaction_with_SA*100, avg_satisfaction_without_SA*100], 'FaceColor', [0.8, 0.4, 0.4]);
    set(gca, 'XTickLabel', {'Tabu + SA', 'Tabu only'});
    ylabel('服务满足率 (%)');
    title('服务满足率对比');
    grid on;
    text(1, avg_satisfaction_with_SA*100*1.02, sprintf('%.2f%%', avg_satisfaction_with_SA*100), 'HorizontalAlignment', 'center');
    text(2, avg_satisfaction_without_SA*100*1.02, sprintf('%.2f%%', avg_satisfaction_without_SA*100), 'HorizontalAlignment', 'center');
    
    % 保存图片
    if save_results
        timestamp = datestr(now, 'yyyy-mm-dd_HH-MM-SS');
        saveas(gcf, sprintf('results/ablation_SA_%s.png', timestamp));
        fprintf('图表已保存: results/ablation_SA_%s.png\n', timestamp);
    end
else
    fprintf('[警告] 实验数据不完整，无法进行统计分析\n');
end

%% 保存结果
if save_results
    timestamp = datestr(now, 'yyyy-mm-dd_HH-MM-SS');
    results_filename = sprintf('results/ablation_SA_%s.mat', timestamp);
    save(results_filename, 'results_with_SA', 'results_without_SA', 'times_with_SA', 'times_without_SA');
    fprintf('\n结果已保存: %s\n', results_filename);
end

fprintf('\n========================================\n');
fprintf('   SA消融实验完成！\n');
fprintf('========================================\n');
