% utils/perform_statistics.m
% 综合统计分析：对比禁忌搜索和DQN的性能
% 生成详细的统计报告和对比表格

clear; clc;

fprintf('========================================================\n');
fprintf('  综合统计分析：禁忌搜索 vs DQN\n');
fprintf('========================================================\n\n');

% 加载结果文件
try
    load('results/results_TabuSearch.mat');
    fprintf('[✓] 禁忌搜索结果已加载\n');
catch
    fprintf('[✗] 禁忌搜索结果文件不存在\n');
    fprintf('    请先运行 run_TabuSearch.m\n');
    return;
end

try
    load('results/results_DQN.mat');
    fprintf('[✓] DQN结果已加载\n');
catch
    fprintf('[✗] DQN结果文件不存在\n');
    fprintf('    请先运行 run_DQN.m\n');
    return;
end

fprintf('\n');

% 统计有效数据
valid_Tabu = ~isnan(throughputs_Tabu) & ~isnan(satisfactions_Tabu);
valid_DQN = ~isnan(throughputs_DQN) & ~isnan(satisfactions_DQN);

num_valid_Tabu = sum(valid_Tabu);
num_valid_DQN = sum(valid_DQN);

fprintf('有效数据统计:\n');
fprintf('  - 禁忌搜索: %d/%d\n', num_valid_Tabu, length(throughputs_Tabu));
fprintf('  - DQN: %d/%d\n\n', num_valid_DQN, length(throughputs_DQN));

if num_valid_Tabu == 0 || num_valid_DQN == 0
    fprintf('[✗] 有效数据不足，无法进行统计分析\n');
    return;
end

%% 1. 吞吐量分析
fprintf('========================================================\n');
fprintf('  1. 系统吞吐量分析\n');
fprintf('========================================================\n\n');

mean_Thr_Tabu = mean(throughputs_Tabu(valid_Tabu));
std_Thr_Tabu = std(throughputs_Tabu(valid_Tabu));
ci_Thr_Tabu = 1.96 * std_Thr_Tabu / sqrt(num_valid_Tabu);
min_Thr_Tabu = min(throughputs_Tabu(valid_Tabu));
max_Thr_Tabu = max(throughputs_Tabu(valid_Tabu));

mean_Thr_DQN = mean(throughputs_DQN(valid_DQN));
std_Thr_DQN = std(throughputs_DQN(valid_DQN));
ci_Thr_DQN = 1.96 * std_Thr_DQN / sqrt(num_valid_DQN);
min_Thr_DQN = min(throughputs_DQN(valid_DQN));
max_Thr_DQN = max(throughputs_DQN(valid_DQN));

% 提升计算
improvement_Thr = (mean_Thr_Tabu - mean_Thr_DQN) / mean_Thr_DQN * 100;
ci_improvement_Thr = improvement_Thr * sqrt((std_Thr_Tabu/mean_Thr_Tabu)^2 + (std_Thr_DQN/mean_Thr_DQN)^2);

fprintf('禁忌搜索:\n');
fprintf('  平均值: %.2f ± %.2f Mbps\n', mean_Thr_Tabu, std_Thr_Tabu);
fprintf('  95%% CI: [%.2f, %.2f] Mbps\n', mean_Thr_Tabu - ci_Thr_Tabu, mean_Thr_Tabu + ci_Thr_Tabu);
fprintf('  范围: [%.2f, %.2f] Mbps\n\n', min_Thr_Tabu, max_Thr_Tabu);

fprintf('DQN:\n');
fprintf('  平均值: %.2f ± %.2f Mbps\n', mean_Thr_DQN, std_Thr_DQN);
fprintf('  95%% CI: [%.2f, %.2f] Mbps\n', mean_Thr_DQN - ci_Thr_DQN, mean_Thr_DQN + ci_Thr_DQN);
fprintf('  范围: [%.2f, %.2f] Mbps\n\n', min_Thr_DQN, max_Thr_DQN);

fprintf('对比:\n');
fprintf('  绝对提升: %.2f ± %.2f Mbps\n', mean_Thr_Tabu - mean_Thr_DQN, sqrt(std_Thr_Tabu^2 + std_Thr_DQN^2));
fprintf('  相对提升: %.2f ± %.2f%%\n', improvement_Thr, ci_improvement_Thr);

% t检验
[h_Thr, p_Thr] = ttest2(throughputs_Tabu(valid_Tabu), throughputs_DQN(valid_DQN));
fprintf('  t检验: h=%d, p=%.4f\n', h_Thr, p_Thr);
if p_Thr < 0.01
    fprintf('  结论: 差异极其显著 (p < 0.01) ✓\n');
elseif p_Thr < 0.05
    fprintf('  结论: 差异显著 (p < 0.05) ✓\n');
else
    fprintf('  结论: 差异不显著 (p >= 0.05)\n');
end
fprintf('\n');

%% 2. 业务满足率分析
fprintf('========================================================\n');
fprintf('  2. 业务满足率分析\n');
fprintf('========================================================\n\n');

mean_Sat_Tabu = mean(satisfactions_Tabu(valid_Tabu));
std_Sat_Tabu = std(satisfactions_Tabu(valid_Tabu));
ci_Sat_Tabu = 1.96 * std_Sat_Tabu / sqrt(num_valid_Tabu);

mean_Sat_DQN = mean(satisfactions_DQN(valid_DQN));
std_Sat_DQN = std(satisfactions_DQN(valid_DQN));
ci_Sat_DQN = 1.96 * std_Sat_DQN / sqrt(num_valid_DQN);

improvement_Sat = (mean_Sat_Tabu - mean_Sat_DQN) / mean_Sat_DQN * 100;

fprintf('禁忌搜索:\n');
fprintf('  平均值: %.2f ± %.2f%%\n', mean_Sat_Tabu * 100, std_Sat_Tabu * 100);
fprintf('  95%% CI: [%.2f%%, %.2f%%]\n\n', (mean_Sat_Tabu - ci_Sat_Tabu) * 100, (mean_Sat_Tabu + ci_Sat_Tabu) * 100);

fprintf('DQN:\n');
fprintf('  平均值: %.2f ± %.2f%%\n', mean_Sat_DQN * 100, std_Sat_DQN * 100);
fprintf('  95%% CI: [%.2f%%, %.2f%%]\n\n', (mean_Sat_DQN - ci_Sat_DQN) * 100, (mean_Sat_DQN + ci_Sat_DQN) * 100);

fprintf('对比:\n');
fprintf('  相对提升: %.2f%%\n', improvement_Sat);

% t检验
[h_Sat, p_Sat] = ttest2(satisfactions_Tabu(valid_Tabu), satisfactions_DQN(valid_DQN));
fprintf('  t检验: h=%d, p=%.4f\n', h_Sat, p_Sat);
if p_Sat < 0.01
    fprintf('  结论: 差异极其显著 (p < 0.01) ✓\n');
elseif p_Sat < 0.05
    fprintf('  结论: 差异显著 (p < 0.05) ✓\n');
else
    fprintf('  结论: 差异不显著 (p >= 0.05)\n');
end
fprintf('\n');

%% 3. 运行时间分析
fprintf('========================================================\n');
fprintf('  3. 运行时间分析\n');
fprintf('========================================================\n\n');

mean_Time_Tabu = mean(times_Tabu(valid_Tabu));
std_Time_Tabu = std(times_Tabu(valid_Tabu));

mean_Time_DQN = mean(times_DQN(valid_DQN));
std_Time_DQN = std(times_DQN(valid_DQN));

speedup = mean_Time_DQN / mean_Time_Tabu;

fprintf('禁忌搜索:\n');
fprintf('  平均时间: %.2f ± %.2f 秒\n\n', mean_Time_Tabu, std_Time_Tabu);

fprintf('DQN:\n');
fprintf('  平均时间: %.2f ± %.2f 秒\n\n', mean_Time_DQN, std_Time_DQN);

fprintf('对比:\n');
fprintf('  速度比: %.2fx\n', speedup);
if speedup > 1
    fprintf('  禁忌搜索快 %.2fx\n', speedup);
else
    fprintf('  DQN快 %.2fx\n', 1/speedup);
end
fprintf('\n');

%% 4. 稳定性分析（变异系数）
fprintf('========================================================\n');
fprintf('  4. 稳定性分析（变异系数）\n');
fprintf('========================================================\n\n');

cv_Thr_Tabu = std_Thr_Tabu / mean_Thr_Tabu * 100;
cv_Thr_DQN = std_Thr_DQN / mean_Thr_DQN * 100;
cv_Sat_Tabu = std_Sat_Tabu / mean_Sat_Tabu * 100;
cv_Sat_DQN = std_Sat_DQN / mean_Sat_DQN * 100;

fprintf('吞吐量变异系数:\n');
fprintf('  禁忌搜索: %.2f%%\n', cv_Thr_Tabu);
fprintf('  DQN: %.2f%%\n', cv_Thr_DQN);
fprintf('  禁忌搜索更稳定: %.2fx\n', cv_Thr_DQN / cv_Thr_Tabu);
fprintf('\n');

fprintf('满足率变异系数:\n');
fprintf('  禁忌搜索: %.2f%%\n', cv_Sat_Tabu);
fprintf('  DQN: %.2f%%\n', cv_Sat_DQN);
fprintf('  禁忌搜索更稳定: %.2fx\n', cv_Sat_DQN / cv_Sat_Tabu);
fprintf('\n');

%% 5. 生成对比表格
fprintf('========================================================\n');
fprintf('  5. 详细对比表格\n');
fprintf('========================================================\n\n');

fprintf('%-20s %-15s %-15s %-15s\n', '指标', '禁忌搜索', 'DQN', '提升');
fprintf('%-20s %-15s %-15s %-15s\n', repmat('-', 1, 20), repmat('-', 1, 15), repmat('-', 1, 15), repmat('-', 1, 15));
fprintf('%-20s %-15s %-15s %-15s\n', '吞吐量 (Mbps)', ...
    sprintf('%.2f±%.2f', mean_Thr_Tabu, std_Thr_Tabu), ...
    sprintf('%.2f±%.2f', mean_Thr_DQN, std_Thr_DQN), ...
    sprintf('+%.2f%%', improvement_Thr));
fprintf('%-20s %-15s %-15s %-15s\n', '满足率 (%)', ...
    sprintf('%.1f±%.1f', mean_Sat_Tabu*100, std_Sat_Tabu*100), ...
    sprintf('%.1f±%.1f', mean_Sat_DQN*100, std_Sat_DQN*100), ...
    sprintf('+%.2f%%', improvement_Sat));
fprintf('%-20s %-15s %-15s %-15s\n', '运行时间 (s)', ...
    sprintf('%.2f±%.2f', mean_Time_Tabu, std_Time_Tabu), ...
    sprintf('%.2f±%.2f', mean_Time_DQN, std_Time_DQN), ...
    sprintf('%.2fx', speedup));
fprintf('\n');

%% 6. 保存综合报告
fprintf('========================================================\n');
fprintf('  6. 保存综合报告\n');
fprintf('========================================================\n\n');

report = struct();
report.TabuSearch = struct(...
    'num_runs', num_valid_Tabu, ...
    'throughput', struct('mean', mean_Thr_Tabu, 'std', std_Thr_Tabu, 'ci', ci_Thr_Tabu), ...
    'satisfaction', struct('mean', mean_Sat_Tabu, 'std', std_Sat_Tabu, 'ci', ci_Sat_Tabu), ...
    'time', struct('mean', mean_Time_Tabu, 'std', std_Time_Tabu), ...
    'cv', struct('throughput', cv_Thr_Tabu, 'satisfaction', cv_Sat_Tabu));

report.DQN = struct(...
    'num_runs', num_valid_DQN, ...
    'throughput', struct('mean', mean_Thr_DQN, 'std', std_Thr_DQN, 'ci', ci_Thr_DQN), ...
    'satisfaction', struct('mean', mean_Sat_DQN, 'std', std_Sat_DQN, 'ci', ci_Sat_DQN), ...
    'time', struct('mean', mean_Time_DQN, 'std', std_Time_DQN), ...
    'cv', struct('throughput', cv_Thr_DQN, 'satisfaction', cv_Sat_DQN));

report.Comparison = struct(...
    'throughput_improvement', improvement_Thr, ...
    'satisfaction_improvement', improvement_Sat, ...
    'speedup', speedup, ...
    'ttest_throughput', struct('h', h_Thr, 'p', p_Thr), ...
    'ttest_satisfaction', struct('h', h_Sat, 'p', p_Sat), ...
    'stability_ratio', struct('throughput', cv_Thr_DQN/cv_Thr_Tabu, 'satisfaction', cv_Sat_DQN/cv_Sat_Tabu));

dateStr = datestr(now, 'yyyy-mm-dd_HH-MM-SS');
report_filename = sprintf('results/Statistics_Report_%s.mat', dateStr);

try
    save(report_filename, 'report', '-v7.3');
    fprintf('[✓] 综合报告已保存: %s\n', report_filename);
catch ME
    fprintf('[✗] 报告保存失败: %s\n', ME.message);
end

fprintf('\n========================================================\n');
fprintf('  统计分析完成\n');
fprintf('========================================================\n');
