%% proposed
function BHST_Method1(interface)
tic
%% 预配置
Debug = 1;
OrderOfServSatCur = interface.OrderOfServSatCur;    % 服务卫星的列表
NumOfServSatCur = length(OrderOfServSatCur);    % 服务卫星的数量
NumOfServBeam = interface.numOfServbeam;    % 业务波束数量
Num_scheme = interface.ScheInShot;  % 快照的调度周期数
Num_slot = interface.SlotInSche;    % 调度周期的slot数量
RequiredTraffic = interface.UsrsTraffic(:, 1);  % 请求的业务量列表
TransportedTraffic = zeros(interface.NumOfSelectedUsrs, Num_scheme);   % 传输的业务量列表
AngleOf3dB = interface.AngleOf3dB;% 天线3dB张角
Rb = tools.getEarthLength(AngleOf3dB, interface.height)/2; % 计算波位半径
%% 设置遗传算法参数
if_directional_mutation = true; % 是否定向突变
convergence_ratio = 0.01;       % 收敛时最大适应值差分波动比例
interf_isolate_factor = 3;      % 干扰隔离因子，控制干扰隔离距离为几倍波位半径
factorOfProbabilityChange = 0.1;% 概率变化因子，范围为0~1，交叉概率为0.5+factorOfProbabilityChange*(rand()-0.5)
Num_population = 200;   % 种群数量
Length_chromosome = 10;  % 染色体长度
Num_decision = ceil(Num_slot/Length_chromosome);    % 调度周期的决策次数
Probability_mutation = 0.01;    % 染色体发生突变的概率
Num_mutation = 4;   % 基因突变的碱基数量
Num_iteration = 100; % 迭代次数
%% 算法运行     
    %% 遍历所有卫星
%     NumOfIteration = zeros(NumOfServSatCur, Num_scheme, Num_decision); % 储存所有决策的迭代次数
    for idxOfSat = 1 : NumOfServSatCur
        UsrsIndex = interface.SatObj(idxOfSat).servUsr; % 星下用户编号列表
        [~,NewUsrsIdx,~] = intersect(interface.OrderOfSelectedUsrs, UsrsIndex);
        RequiredTraffic_in_Sat = RequiredTraffic(NewUsrsIdx);    % 星下用户剩余请求业务
        TransportedTraffic_in_Sat = zeros(interface.SatObj(idxOfSat).numOfusrs, Num_scheme);   % 星下用户传输业务
        interface.tmpSat(idxOfSat).BHST = zeros(NumOfServBeam, Num_slot*Num_scheme);
        %% 遍历每个调度周期
        for idxOfSche = 1 : Num_scheme 
            if idxOfSche == 1
                RequiredTraffic_in_Sat = RequiredTraffic_in_Sat + ...
                                interface.UsrsTraffic(NewUsrsIdx, idxOfSche+1);  % 第一调度周期的待调度业务为初始业务+第一周期生成的业务
            else
                RequiredTraffic_in_Sat = RequiredTraffic_in_Sat + ...
                                interface.UsrsTraffic(NewUsrsIdx, idxOfSche+1) - ...
                                TransportedTraffic_in_Sat(:, idxOfSche-1);  % 第n调度周期的待调度业务为初始业务+第n周期生成的业务-第n-1周期传输的业务
            end
            RequiredTraffic_in_Sat(RequiredTraffic_in_Sat<0) = 0;   % 剩余业务量小于0记为0

            NumOfBeamfoot = interface.tmpSat(idxOfSat).NumOfBeamFoot(idxOfSche);    % 波位总数
                    
            ExecutiveBHST = zeros(NumOfBeamfoot, Num_slot); % 决策计划表

            RequiredTrafficOfBF = zeros(NumOfBeamfoot, 1); 
            for tmpk = 1 : NumOfBeamfoot
                [~, tmp_idx, ~] = intersect(UsrsIndex, interface.tmpSat(idxOfSat).beamfoot(idxOfSche, tmpk).usrs);% tmp_idx是星下用户里的第几个
                RequiredTrafficOfBF(tmpk) = sum(RequiredTraffic_in_Sat(tmp_idx)); % 波位在当前调度周期请求业务
            end      
            %% 进行多次决策
            TransportedTrafficOfBF = zeros(Num_decision, NumOfBeamfoot); % 多次决策的波位业务传输量表格
            % 先计算无干扰情况下，用户的标准每slot业务传输量
            standard_ExecutiveBHST = zeros(NumOfBeamfoot, 1);
            standard_ExecutiveBHST(1) = 1;
            standard_TransportedTrafficOfBF = calculateTraffic(interface.OrderOfSelectedUsrs, idxOfSat, idxOfSche, 1, 1, standard_ExecutiveBHST, interface, Debug);
            standard_TransportedTrafficOfBF = standard_TransportedTrafficOfBF(1);

            Distance = zeros(NumOfBeamfoot, NumOfBeamfoot);  % 记录波位距离的邻接矩阵，用于设置点亮波位间隔
            OrderOfBf = interface.tmpSat(idxOfSat).beamfoot(idxOfSche, 1:NumOfBeamfoot);
            for idxOfB_1 = 1 : NumOfBeamfoot-1
                for idxOfB_2 = idxOfB_1+1 : NumOfBeamfoot
                    Distance(idxOfB_1, idxOfB_2) = tools.LatLngCoordi2Length( ...
                                                        OrderOfBf(idxOfB_1).position, ...
                                                        OrderOfBf(idxOfB_2).position, ...
                                                        6371.393e3);
                    Distance(idxOfB_2, idxOfB_1) = Distance(idxOfB_1, idxOfB_2);
                end
            end

            for idxOfDeci = 1 : Num_decision
                % 用户在当前决策剩余请求业务
                if idxOfDeci ~= 1
                    RequiredTrafficOfBF = RequiredTrafficOfBF - TransportedTrafficOfBF(idxOfDeci-1, :).';
                end
                RequiredTrafficOfBF(RequiredTrafficOfBF<0)=0;
                % 统计按标准传输量，用户剩余业务量能传几个slot
                NumOfSlot_RequiredTrafficOfBF = zeros(NumOfBeamfoot, 1);
                for idx_tmp = 1 : NumOfBeamfoot
                    NumOfSlot_RequiredTrafficOfBF(idx_tmp) = ceil(RequiredTrafficOfBF(idx_tmp)./standard_TransportedTrafficOfBF);
                end
                have_assigned_slot = (idxOfDeci-1)*Length_chromosome;
                UsrIdx = interface.tmpSat(idxOfSat).beamfoot(idxOfSche, 1).usrs;
                T_noise = interface.UsrsObj(find(interface.OrderOfSelectedUsrs==UsrIdx(1))).T_noise;
                F_noise_dB = interface.UsrsObj(find(interface.OrderOfSelectedUsrs==UsrIdx(1))).F_noise;
                F_noise = 10.^(F_noise_dB./10);
                N0_noise = 1.380649e-23*(T_noise + (F_noise-1)*300);

                functionOfgetPointAngle = @(BeamLightSeq)getPointAngle(BeamLightSeq, interface, idxOfSat, idxOfSche);                
                functionOfgetCarrierP = @(alpha, beta, angleOfusr, distance)getCarrierP(alpha, beta, angleOfusr, distance, interface);
                functionOfgetInterfP = @(alpha, beta, angleOfusr, distance)getInterfP(alpha, beta, angleOfusr, distance, interface);

                ExecutiveBHST(:, (idxOfDeci-1)*Length_chromosome+1:idxOfDeci*Length_chromosome) = ...
                    Evolution(...
                        Num_population, ...
                        Length_chromosome, ...
                        Probability_mutation, ...
                        if_directional_mutation, ...
                        Num_mutation, ...
                        Num_iteration, ...
                        convergence_ratio, ...
                        interf_isolate_factor, ...
                        Rb, ...
                        NumOfBeamfoot, ...
                        NumOfServBeam, ...
                        NumOfSlot_RequiredTrafficOfBF, ...
                        Distance, ...
                        factorOfProbabilityChange, ...
                        have_assigned_slot, ...
                        ExecutiveBHST, ...
                        RequiredTrafficOfBF, ...
                        N0_noise, ...
                        interface.BandOfLink*1e6, ...
                        functionOfgetPointAngle, ...
                        functionOfgetCarrierP, ...
                        functionOfgetInterfP ...
                        );

                TransportedTrafficOfBF(idxOfDeci, :) = calculateTraffic(interface.OrderOfSelectedUsrs, idxOfSat, idxOfSche, idxOfDeci, Length_chromosome, ExecutiveBHST, interface, Debug); % 计算当前决策的各波位传输业务量   
                if Debug == 1
                    fprintf('第%d卫星 第%d调度 第%d决策 业务量计算完成\n', idxOfSat, idxOfSche, idxOfDeci); 
                end            
            end % 遍历决策
            %%
            for tmpk = 1 : NumOfBeamfoot
                usrs = interface.tmpSat(idxOfSat).beamfoot(idxOfSche, tmpk).usrs;
                NofU = length(usrs);
                [~,tmp_UsrsIndex,~] = intersect(UsrsIndex, usrs);
                r_traffic = RequiredTraffic_in_Sat(tmp_UsrsIndex);
                for idx = 1 : NofU
                    TransportedTraffic_in_Sat(tmp_UsrsIndex(idx), idxOfSche) = TransportedTraffic_in_Sat(tmp_UsrsIndex(idx), idxOfSche) + ...
                        sum(TransportedTrafficOfBF(:,tmpk)).*(r_traffic(idx)./sum(r_traffic));
                end
            end 
            for idx_BHST = 1 : Num_slot
                if length(find(ExecutiveBHST(:,idx_BHST)==1)) < NumOfServBeam
                    interface.tmpSat(idxOfSat).BHST(:, (idxOfSche-1)*Num_slot+idx_BHST) = ...
                            [find(ExecutiveBHST(:,idx_BHST)==1);zeros(NumOfServBeam-length(find(ExecutiveBHST(:,idx_BHST)==1)), 1)];
                else
                    interface.tmpSat(idxOfSat).BHST(:, (idxOfSche-1)*Num_slot+idx_BHST) = ...
                            find(ExecutiveBHST(:,idx_BHST)==1);
                end
            end
        end % 遍历调度周期
        TransportedTraffic(NewUsrsIdx, :) = TransportedTraffic(NewUsrsIdx, :) + ...
            TransportedTraffic_in_Sat;
    end % 遍历卫星 
    interface.tmp_UsrsTransPort = TransportedTraffic;
    toc;
    fprintf(['遗传算法:',num2str(toc),'\n']); 
end

%% 计算吞吐量
function TransportedTrafficOfBF = calculateTraffic(OrderOfSelectedUsrs,idxOfSat, idxOfSche, idxOfDeci, Length_chromosome, ExecutiveBHST, interface, Debug)
    numOfbeamfoot = length(ExecutiveBHST(:,1));
    TransportedTrafficOfBF = zeros(numOfbeamfoot, 1);
    for idxOfSlot = 1 : Length_chromosome
        lightedBf = find(ExecutiveBHST(:, (idxOfDeci-1)*Length_chromosome+idxOfSlot)==1);
        NumOfLightBeamfoot = length(lightedBf);
        PosOfBeam = zeros(NumOfLightBeamfoot, 2);    % 点亮波位中心三角形坐标       
        for bidx = 1 : NumOfLightBeamfoot
            PosOfBeam(bidx, :) = interface.tmpSat(idxOfSat).beamfoot(idxOfSche, lightedBf(bidx)).position; 
        end
        BeamPoint = zeros(NumOfLightBeamfoot, 2); % varphi(俯仰，偏离x轴),vartheta(方向，偏离xOy平面),天线在zOy平面(右手系)
        for j = 1 : NumOfLightBeamfoot
            [outputTheta, outputPhi] = tools.getPointAngleOfUsr(...
                interface.SatObj(idxOfSat).position, interface.SatObj(idxOfSat).nextpos, PosOfBeam(j, :), interface.height);
            BeamPoint(j,1) = outputPhi;
            BeamPoint(j,2) = outputTheta;
        end
        SINR_Gene = zeros(NumOfLightBeamfoot, 1);
        for tmpI = 1 : NumOfLightBeamfoot
            [SINR_Gene(tmpI), ~] = CaculateR(...
                OrderOfSelectedUsrs, ...
                idxOfSat, idxOfSche, ...
                ExecutiveBHST(:, (idxOfDeci-1)*Length_chromosome+idxOfSlot),...
                lightedBf(tmpI), BeamPoint, interface);
        end
        for idxOfBf = 1 : NumOfLightBeamfoot
            TransportedTrafficOfBF(lightedBf(idxOfBf)) = TransportedTrafficOfBF(lightedBf(idxOfBf)) + ...
                fix(interface.timeInSlot*interface.BandOfLink*1e6*log2(1+SINR_Gene(idxOfBf)));
        end
    end          
end
%% 计算碱基的SINR值和SNR值
function [SINR, SNR] = CaculateR(OrderOfSelectedUsrs, SatIdx, ScheIdx, Gene, i, BeamPoint, interface)
    % 基因上第i个碱基所受到的干扰
    Pt = (10.^((interface.SatObj(SatIdx).Pt_dBm_serv)./10))./1e3./interface.numOfServbeam;   % W
    UsrIdx = interface.tmpSat(SatIdx).beamfoot(ScheIdx, i).usrs;
    T_noise = interface.UsrsObj(find(OrderOfSelectedUsrs==UsrIdx(1))).T_noise;
    F_noise_dB = interface.UsrsObj(find(OrderOfSelectedUsrs==UsrIdx(1))).F_noise;
    F_noise = 10.^(F_noise_dB./10);
    N0_noise = 1.380649e-23*(T_noise + (F_noise-1)*300);
    Bandwidth = interface.BandOfLink*1e6;
    ExpressedGene = find(Gene == 1);
    % 计算当前波位中心的指向角 
    usrCurPos = interface.tmpSat(SatIdx).beamfoot(ScheIdx, i).position; % 当前用户坐标    
    satCurPos = interface.SatObj(SatIdx).position; % 当前卫星星下点坐标
    satCurnextPos = interface.SatObj(SatIdx).nextpos; % 当前卫星星下点下一step坐标
    [UsrTheta, UsrPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, usrCurPos, interface.height);%计算方位角和仰角
    % 计算用户接收增益
    G_usrDown = antenna.getUsrAntennaServG(0, interface.freqOfDownLink, false);
    % 计算当前卫星到当前用户的距离
    usrPosInDescartes = LngLat2Descartes(usrCurPos, 0);
    satPosInDescartes = LngLat2Descartes(satCurPos, interface.height);
    distance = sqrt((satPosInDescartes(1)-usrPosInDescartes(1)).^2 + ...
                    (satPosInDescartes(2)-usrPosInDescartes(2)).^2 + ...
                    (satPosInDescartes(3)-usrPosInDescartes(3)).^2);  
    InterfInSatDown = 0;
    lambdaDown = 3e8/interface.freqOfDownLink;
    for bfIdx = 1 : length(ExpressedGene)
        if bfIdx ~= find(ExpressedGene == i)
            poiBeta = BeamPoint(bfIdx,1);
            poiAlpha = BeamPoint(bfIdx,2);
            AgleOfInv = [UsrTheta, UsrPhi];
            AgleOfPoi = [poiAlpha, poiBeta];
            G_sat_interfDown = antenna.getSatAntennaServG(AgleOfInv, AgleOfPoi, interface.freqOfDownLink);
            InterfInSatDown = InterfInSatDown + ...
                Pt * G_sat_interfDown * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
        end
    end
    %%%%%%%%%%%%%%%%%%%%%
    bfIdx = find(ExpressedGene == i);
    poiBeta = BeamPoint(bfIdx,1);
    poiAlpha = BeamPoint(bfIdx,2);
    AgleOfInv = [UsrTheta, UsrPhi];
    AgleOfPoi = [poiAlpha, poiBeta];
    G_sat_down = antenna.getSatAntennaServG(AgleOfInv, AgleOfPoi, interface.freqOfDownLink);
    %%%%%%%%%%%%%%%%%%%%%
    Carrier_down = Pt * G_sat_down * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance.^2));
    SINR = Carrier_down./(InterfInSatDown + Bandwidth*N0_noise);
    SNR = Carrier_down./(Bandwidth*N0_noise);
end

%% 函数参数
% functionOfgetPointAngle = @getPointAngle;
% functionOfgetCarrierP = @getCarrierP;
% functionOfgetInterfP = @getInterfP
function [alpha, beta, angleOfusr, distance] = getPointAngle( ...
    BeamLightSeq, ...
    interface, ...
    idxOfSat, ...
    idxOfSche ...
    )
    UsrAntennaConfig = antenna.initialUsrAntenna();
    IfUsrAntennaDeGravity = UsrAntennaConfig.ifDeGravity;
    LightBeamfoot = find(BeamLightSeq == 1); % 点亮的波位编号
    NumOfLightBeamfoot = length(LightBeamfoot);
    PosOfBeam = zeros(NumOfLightBeamfoot, 2);    % 点亮波位中心三角形坐标            
    for bidx = 1 : NumOfLightBeamfoot
        if ~isempty(interface.SatObj(SatIdx).beamfoot)
            PosOfBeam(bidx, :) = self.tmpSat(idxOfSat).beamfoot(idxOfSche, LightBeamfoot(bidx)).position; 
        end
    end
    alpha = zeros(NumOfLightBeamfoot, 1);
    beta = zeros(NumOfLightBeamfoot, 1);
    for idx = 1 : NumOfLightBeamfoot
        [alpha(idx), beta(idx)] = tools.getPointAngleOfUsr(...
            interface.SatObj(idxOfSat).position, interface.SatObj(idxOfSat).nextpos, PosOfBeam(idx, :), interface.height);
    end
    distance = zeros(NumOfLightBeamfoot, 1);
    angleOfusr = zeros(NumOfLightBeamfoot, 1);
    if IfUsrAntennaDeGravity == 1
        for idx_usr = 1 : NumOfLightBeamfoot
            UsrIdx = interface.tmpSat(idxOfSat).beamfoot(idxOfSche, LightBeamfoot(idx_usr)).usrs;
            usrCurPos = interface.UsrsObj(find(interface.OrderOfSelectedUsrs==UsrIdx(1))).position;
            satCurPos = interface.SatObj(idxOfSat).position;
            [angleOfusr(idx_usr), ~, ~] = ...
                simSatSysClass.tools.getAngleOfInterfSat(usrCurPos, satCurPos, usrCurPos, interface.height);
            usrPosInDescartes = LngLat2Descartes(usrCurPos, 0);
            satPosInDescartes = LngLat2Descartes(satCurPos, interface.height);
            distance(idx_usr) = sqrt((satPosInDescartes(1)-usrPosInDescartes(1)).^2 + ...
                            (satPosInDescartes(2)-usrPosInDescartes(2)).^2 + ...
                            (satPosInDescartes(3)-usrPosInDescartes(3)).^2);
        end
    else
        for idx_usr = 1 : NumOfLightBeamfoot
            UsrIdx = interface.tmpSat(idxOfSat).beamfoot(idxOfSche, LightBeamfoot(idx_usr)).usrs;
            usrCurPos = interface.UsrsObj(find(interface.OrderOfSelectedUsrs==UsrIdx(1))).position;
            satCurPos = interface.SatObj(idxOfSat).position;
            usrPosInDescartes = LngLat2Descartes(usrCurPos, 0);
            satPosInDescartes = LngLat2Descartes(satCurPos, interface.height);
            distance(idx_usr) = sqrt((satPosInDescartes(1)-usrPosInDescartes(1)).^2 + ...
                            (satPosInDescartes(2)-usrPosInDescartes(2)).^2 + ...
                            (satPosInDescartes(3)-usrPosInDescartes(3)).^2);
        end
    end
end
function CarrierP = getCarrierP(alpha, beta, angleOfusr, distance, interface)
    freqOfDownLink = interface.freqOfDownLink;
    CarrierP = zeros(length(alpha),1);
    Pt_SAT_dBm_serv = interface.SatObj(SatIdx).Pt_dBm_serv;
    %%%%%%%%%%%%%%%%% 业务波束功率均分 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Pt_SAT_serv = (10.^(Pt_SAT_dBm_serv/10))/1e3/interface.numOfServbeam; % W
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    lambdaDown = 3e8/freqOfDownLink;
    for idx = 1 : length(alpha)
        % 计算用户接收增益    
        G_usrDown = antenna.getUsrAntennaServG(angleOfusr(idx), freqOfDownLink, false);
        % 计算计算卫星发射增益
        G_sat_down = antenna.getSatAntennaServG([alpha(idx), beta(idx)], [alpha(idx), beta(idx)], freqOfDownLink);
  
        CarrierP(idx) = Pt_SAT_serv * G_sat_down * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance(idx).^2));
    end
end
function InterfP = getInterfP(alpha, beta, angleOfusr, distance, interface)
    freqOfDownLink = interface.freqOfDownLink;
    InterfP = zeros(length(alpha),1);
    Pt_SAT_dBm_serv = interface.SatObj(SatIdx).Pt_dBm_serv;
    %%%%%%%%%%%%%%%%% 业务波束功率均分 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Pt_SAT_serv = (10.^(Pt_SAT_dBm_serv/10))/1e3/interface.numOfServbeam; % W
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    lambdaDown = 3e8/freqOfDownLink;
    for idx = 1 : length(alpha)
        G_usrDown = antenna.getUsrAntennaServG(angleOfusr(idx), freqOfDownLink, false);
        for idx_interf = 1 : length(alpha)
            G_sat_interfDown = antenna.getSatAntennaServG([alpha(idx), beta(idx)], [alpha(idx_interf), beta(idx_interf)], freqOfDownLink);
            if idx_interf ~= idx
                InterfP(idx) = InterfP(idx) + ...
                    Pt_SAT_serv * G_sat_interfDown * G_usrDown * (lambdaDown.^2) / (((4*pi).^2)*(distance(idx).^2));
            end
        end
    end
end
%% 由经纬度转化为笛卡尔坐标
function PosInDescartes = LngLat2Descartes(CurPos, h)
    tmpPhi = CurPos(1) * pi / 180;
    if tmpPhi < 0
        tmpPhi = tmpPhi + 2*pi;
    end
    tmpTheta = (90 - CurPos(2)) * pi / 180;
    R = 6371.393e3; % 地球半径
    tmpX = (R+h) * sin(tmpTheta) * cos(tmpPhi);
    tmpY = (R+h) * sin(tmpTheta) * sin(tmpPhi);
    tmpZ = (R+h) * cos(tmpTheta); 
    PosInDescartes = [tmpX, tmpY, tmpZ];    
end