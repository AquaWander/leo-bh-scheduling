% 2023/03/07stepOfSimuMove
% 仿真平台的测试参数配置
%% 平台参数
durationOfTotalSimu = 1;   % (s)整体仿真长度
                            % 注意：该项参数的值不应当小于stepOfSimuMove

stepOfSimuMove = 1;    % (s)卫星星座空间状态变化的时间间隔。
                        % 注意：该项参数的值不应当小于durationOfSimuStep

durationOfSimuStep = 40e-3;     % (s)在某卫星星座空间状态下进行波束仿真的时长。
                                % 注意：该项参数的值不应当大于stepOfSimuMove

rangeOfInves = [102, 108; ...  
                 26, 30];   % [经度，经度；纬度，纬度]
                            % 用户撒点的考查区域
                            % 注意：北纬和东经是正值，南纬和西经是负值。经度范围是高纬边的经度范围

factorOfDiscr = 110;    % 区域离散因子
                        % 说明：考查区域被分成许多小三角形。因子OfDiscr表示一个纬度可以划分成多少行三角形。

layerOfinterf = 1;      % 干扰计算因子
                        % 说明：在计算星间干扰时，计算多少层相邻卫星

numOfMonteCarlo = 0;    % 蒙特卡洛次数

ifAscendUp = 1;         % 1: 平台考察北向行驶卫星
                        % 2: 平台考察南向行驶卫星
                        
ifWrapAround = 0;       % 是否考虑仿真边界效应，开启wrapWround

WrapAroundLayer = 0;    % WrapAround的卫星层数（只可设置为0或1）

WrapExtendValue = 6;   % WrapAround区域扩大的经纬度数 


%% 调度参数
BhDispCycle = 40e-3;    % (s)跳波束调度周期长度
                        % 注意：该项参数的值不应当大于durationOfSimuStep，并其最好是BhDispCycle的整数倍

SubCarrierSpace = 30e3;  % (Hz)子载波间隔
% SubCarrierSpace = 120e3;  % (Hz)子载波间隔
                         % 说明：该项参数影响slot长度、带宽到PRBS的映射

% maxUsrPerBeam = 1;      % 业务波位的最大用户数量

ifFixedUsrsNum = true;  % 是否固定用户数量
                        % 说明：如果固定，则在考察区域内，生成固定数量和位置的用户；如果不固定，则每隔若干空间状态都重新用SPPP生成用户

meanUsrsNum = 800;  % 考察区域的平均用户数量
                    % 说明：固定数量撒点时，该参数即撒点数量；不固定撒点时，该参数为泊松过程的均值。

intervalStep = 10;      % 每隔intervalStep个卫星空间状态更新step，重新生成用户

%-------新增--------%
activePercent = 1;   % 用户的激活率

ifAdjustBHST = 0; % 是否进行星间干扰抑制

%% 卫星参数
heightOfSat = 508e3;    % (m)星座高度

numOfServbeam = 10;     % 最大业务波束数量 

Pt_dBm_serv = 10*log10(300e3);      % (dBm)业务波束总发射功率

rangeOfbeam = [45*pi/180, 33*pi/180];  % 波束扫描范围

% angleOfbeam = 6;%波束张角

% IsoAgl_Serv = 3*pi/180; % 业务波束隔离角

numOfSigbeam = 0;       % 信令波束数量

% ScheOfSig = 20e-3;     % 信令波束扫描周期

% LightTimeOfSig = 1e-3;   % 信令注视时长

Pt_dBm_signal = 10*log10(50e3);     % (dBm)信令波束总发射功率

% SpaceOfSigbeam = 40e3;  % 正方形信令波位区域的间距

% IsoAgl_Sig = 11*pi/180; % 信令波束隔离角
% 
% IsoAgl_ServAndSig = 10*pi/180; % 业务波束与信令波束隔离角


%% 通信条件
% BandOfLink = 40e6; % (Hz) 载波带宽

% freqOfDownLink = 3620e6; % (Hz) 卫星的下行链路中心频点
% freqOfDownLink_ascend_DOWN = 3660e6; % (Hz) 轨道南向行驶卫星的下行链路中心频点
% freqOfUpLink = 5190e6; % (Hz) 卫星的上行链路中心频点
% freqOfUpLink_ascend_DOWN = 5230e6; % (Hz) 轨道南向行驶卫星的上行链路中心频点

% 华为论文频段
% BandOfLink = 30e6; % (Hz) 载波带宽
% freqOfDownLink = 2e9; % (Hz) 卫星的下行链路中心频点
% freqOfUpLink = 1995e6; % (Hz) 卫星的上行链路中心频点

%S频段
BandOfLink = 40e6; % (Hz) 载波带宽
freqOfDownLink = 3620e6; % (Hz) 卫星的下行链路中心频点
freqOfUpLink = 1995e6; % (Hz) 卫星的上行链路中心频点
%Ka频段
% BandOfLink = 200e6; % (Hz) 载波带宽
% freqOfDownLink = 20e9; % (Hz) 卫星的下行链路中心频点
% freqOfUpLink = 30e9; % (Hz) 卫星的上行链路中心频点

SAT_T_noise = 0;  % 卫星天线的噪声温度（K）
Usr_T_noise = 150; % 用户天线的噪声温度（K）
SAT_F_noise = 0;    % 卫星接收机的噪声系数（dB）
Usr_F_noise = 7;    % 用户接收机的噪声系数（dB）

Pt_dBm_Usr = 23;    % 用户天线发射功率

%% 场景参数
ifattenuation = 0;% 是否考虑各种衰减模型
scenario=0;    %0：郊区和农村
               %1：城市
               %2：密集城市

ifSatAndGround = 0;% 是否星地干扰
Pt_dBm_BS = 38;    % 基站天线发射功率
TerrestrialDuplexing = 1;   % 地面网络双工方式，1是FDD，0是TDD
Userdense = 1000;  % 地面用户密度/平方公里

% 业务
diffTrafficUserRatio = [1; 0; 0]; % 不同类型业务用户占总用户的比例，
                                      % diffTrafficUserRatio(1)中为FTP用户比例
                                      % diffTrafficUserRatio(2)中为视频流用户比例
                                      % diffTrafficUserRatio(3)中为VoIP用户比例

%% 算法配置（用于消融实验）
enable_SA = true;         % 是否启用模拟退火(SA)机制
L_tabu_mode = 'adaptive'; % 禁忌长度模式: 'adaptive' 或 'fixed'
fixed_L_tabu = 20;        % 固定禁忌长度（仅当L_tabu_mode='fixed'时使用）

%% 流量分布配置（用于场景扩展实验）
traffic_mode = 'uniform';    % 流量分布模式: 'uniform', 'light_skew', 'heavy_skew', 'pareto'
traffic_skew_factor = 2;     % 偏斜因子（用于'light_skew'和'heavy_skew'模式）
pareto_alpha = 1.5;          % Pareto分布参数（用于'pareto'模式，80/20规则时约1.36）

%% 构建结构体
Config = struct( ....
    'ifAdjustBHST', ifAdjustBHST, ...
    'intervalStep', intervalStep, ...
    'activePercent', activePercent, ...
    'ifWrapAround',     ifWrapAround, ...
    'WrapAroundLayer',  WrapAroundLayer, ...
    'WrapExtendValue',  WrapExtendValue, ...
    'height',   heightOfSat, ...
    'step',     stepOfSimuMove, ...
    'duration', durationOfSimuStep, ...
    'time',     durationOfTotalSimu, ...
    'rangeOfInves',     rangeOfInves, ...
    'factorOfDiscr',    factorOfDiscr, ...
    'layerOfinterf',    layerOfinterf, ...
    'numOfMonteCarlo',  numOfMonteCarlo, ...
    'ifFixedUsrsNum',  ifFixedUsrsNum, ...
    'scenario',    scenario,...
    'meanUsrsNum',  meanUsrsNum, ...
    'SCS',      SubCarrierSpace, ...
    'bhTime',   BhDispCycle, ...
    'Pt_dBm_serv',    Pt_dBm_serv, ... ...
    'numOfServbeam',    numOfServbeam, ...
    'Pt_dBm_signal',    Pt_dBm_signal, ...
    'numOfSigbeam',     numOfSigbeam, ...
    'rangeOfBeam',      rangeOfbeam, ...
    'BandOfLink',   BandOfLink, ...
    'ifAscendUp',   ifAscendUp, ...
    'freqOfDownLink',     freqOfDownLink, ...
    'freqOfUpLink',       freqOfUpLink, ...
    'SAT_T_noise',      SAT_T_noise, ...
    'Usr_T_noise',      Usr_T_noise, ...
    'SAT_F_noise',      SAT_F_noise, ...
    'Usr_F_noise',      Usr_F_noise, ...
    'Pt_dBm_Usr',   Pt_dBm_Usr, ...
    'Pt_dBm_BS',   Pt_dBm_BS, ...
    'TerrestrialDuplexing',   TerrestrialDuplexing, ...
    'Userdense',   Userdense, ...
    'diffTrafficUserRatio',   diffTrafficUserRatio, ...
    'ifattenuation', ifattenuation, ...
    'ifSatAndGround', ifSatAndGround, ...
    'enable_SA', enable_SA, ...
    'L_tabu_mode', L_tabu_mode, ...
    'fixed_L_tabu', fixed_L_tabu, ...
    'traffic_mode', traffic_mode, ...
    'traffic_skew_factor', traffic_skew_factor, ...
    'pareto_alpha', pareto_alpha ...
    );