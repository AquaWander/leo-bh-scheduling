% 2023/03/16
% 储存仿真数据的Class
%%
classdef (HandleCompatible = false) dataObj
    properties (Access = public)  
        %% 仿真结果统计
        %---------------------------------------------------------------------- 
        % 格式：调度方法总数×每快照时隙数×NumOfInvesUsrs×2
        InterfFromAll_Down  % 下行干扰C/I和C/(I+N)，考虑考察区域内全部卫星、波束
        InterfFromAll_Up    % 上行干扰C/I和C/(I+N)，考虑考察区域内全部卫星、波束
        % 格式：调度方法总数×每快照时隙数×NumOfInvesUsrs×2
        InterfFromSingleSat_Down    % 下行干扰C/I和C/(I+N)，只考虑提供服务的卫星的波束
        InterfFromSingleSat_Up      % 上行干扰C/I和C/(I+N)，只考虑提供服务的卫星的波束
        % 格式：调度方法总数×每快照时隙数×NumOfInvesUsrs×3
        Interf1 % 基站对卫星UE接收干扰C/(I+N),I和C/I
        Interf4 % 地面UE对卫星UE接收干扰C/(I+N),I和C/I
        Interf6 % 基站+地面UE对卫星UE接收干扰C/(I+N),I和C/I
        % 格式：调度方法总数×每快照时隙数×服务卫星数x工作波束数量×3
        Interf2 % 地面UE对卫星接收干扰C/(I+N),I和C/I
        Interf3 % 基站对卫星接收干扰C/(I+N),I和C/I
        Interf5 % 基站+地面UE对卫星接收干扰C/(I+N),I和C/I
        
        %---------------------------------------------------------------------- 
        UsrsTraffic % 矩阵，格式为“NumOfSelectedUsrs × (scheInShot+1)”
                    % UsrsTraffic(k, 1)为初始随机业务量
                    % UsrsTraffic(k, 2)~UsrsTraffic(k,scheInShot+1)为每次调度周期开始时的新增业务量
        %----------------------------------------------------------------------            
        UsrsTransPort   % 矩阵，格式为“NumOfSelectedUsrs × scheInShot”
                        % UsrsTransPort(idxOfMethod, k, p)为编号k用户在第p个调度周期的传输业务量
        %----------------------------------------------------------------------
        InterSat_UsrsTransPort  % 矩阵，格式为“NumOfSelectedUsrs × scheInShot”
                                % InterSat_UsrsTransPort(idxOfMethod, k, p)为编号k用户在第p个调度周期的传输业务量
        %----------------------------------------------------------------------
        NumOfInvesUsrs  % 考察区域用户的数量
        %----------------------------------------------------------------------
        OrderOfSelectedUsrs % 向量，长度为NumOfSelectedUsrs,储存removeSat后的用户序列，前NumOfInvesUsrs是考察区域用户
        %----------------------------------------------------------------------
        UsrsObj   % 用户的类实例,实例数组，来自self.run(),长度为NumOfSelectedUsrs，前NumOfInvesUsrs是考察区域用户
        %----------------------------------------------------------------------
        ServSatOfDiscrAreaCur   % 来自self.calcuSatServArea()
                                % 当前step考察区域中各三角形的归属卫星编号，即储存卫星的服务范围
                                % 矩阵，格式为"DiscrArea行数×DiscrArea列数"
                                % ServSatOfDiscrAreaCur(i, j)表示第i行第j列三角形的归属卫星编号                   
        %----------------------------------------------------------------------                        
        OrderOfServSatCur     % 当前step提供服务的卫星编号
        %----------------------------------------------------------------------
        SatObj   % 卫星的类实例
        %----------------------------------------------------------------------
        Usr2SatCur      % 来自self.calcuSatServArea()    
                        % Usr2SatCur(OrderOfSelectedUsrs(k),)表示UsrsObj编号k用户的归属卫星编号\
        %-----------------------------
        TerrestrialDuplexing
        %% 画图要用的
        forPlot 
%                 CoordiTri
%                 factorOfDiscr
%                 rangeOfInves
%                 ifWrapAround
%                 wrapRange
%                 numOfMethods_BeamGenerate
%                 numOfMethods_BeamHopping
%                 NumOfSchePerShot
%                 stepOfSimuMove
         forWeb    
         % heightOfSat
         % intervalOfStep
         % totalSeconds
         % SatPosition
         % halfCone
         % userPostion 用户数*2

    end
    
    methods (Access = public)  
        % 构造函数
        function self = dataObj()

        end
        % 方法签名

    end
end

