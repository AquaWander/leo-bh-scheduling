%% 综合实验运行脚本
% 包含：基线对比 + 消融实验 + 结果可视化
% 
% 实验内容:
%   1. 基线对比实验: Tabu+SA, Greedy, DQN, GA
%   2. SA消融实验: Tabu+SA vs Tabu-only
%   3. L_tabu消融实验: 固定 vs 自适应
%   4. 生成所有对比图表
%   5. 保存所有实验结果
%
% 作者: 2025-03-04
% 版本: 1.0

clear; clc; close all;

%% 添加路径
addpath(genpath('.'));

%% 实验配置
fprintf('========================================\n');
fprintf('   LEO卫星波束跳变调度 - 综合实验\n');
fprintf('========================================\n\n');

config = struct();
config.num_runs = 3;  % 每组实验运行次数
config.save_results = true;  % 是否保存结果
config.run_baseline = true;  % 是否运行基线对比
config.run_ablation_SA = true;  % 是否运行SA消融
config.run_ablation_Ltabu = true;  % 是否运行L_tabu消融

%% 加载数据
fprintf('[步骤 1/6] 加载仿真数据...\n');
try
    load('DataObj.mat', 'DataObj');
    fprintf('   ✓ 数据加载成功\n');
    fprintf('   - 用户数: %d\n', DataObj.NumOfSelectedUsrs);
    fprintf('   - 调度周期数: %d\n', DataObj.ScheInShot);
    fprintf('   - 每周期时隙数: %d\n\n', DataObj.SlotInSche);
catch
    error('错误: 无法加载DataObj.mat，请确保文件存在');
end

%% 初始化结果存储
all_results = struct();
all_timestamp = datestr(now, 'yyyy-mm-dd_HH-MM-SS');

%% 基线对比实验
if config.run_baseline
    fprintf('[步骤 2/6] 运行基线对比实验...\n');
    fprintf('========================================\n');
    
    methods_list = {'TabuSA', 'Greedy'};
    num_methods = length(methods_list);
    
    baseline_results = cell(num_methods, 1);
    baseline_KPIs = cell(num_methods, 1);
    baseline_times = zeros(num_methods, config.num_runs);
    
    for method_idx = 1:num_methods
        method_name = methods_list{method_idx};
        fprintf('\n方法 %d/%d: %s\n', method_idx, num_methods, method_name);
        fprintf('----------------------------------------\n');
        
        baseline_results{method_idx} = [];
        
        for run = 1:config.num_runs
            fprintf('  运行第 %d/%d 次...\n', run, config.num_runs);
            
            % 复制数据
            interface = DataObj;
            
            % 运行对应方法
            tic;
            switch method_name
                case 'TabuSA'
                    methods.BHST_MY_SA(interface, true, 'adaptive', 20);
                case 'Greedy'
                    methods.BHST_greedyAndDist(interface);
                case 'DQN'
                    methods.BHST_DQN(interface);
                otherwise
                    warning('未知方法: %s，跳过', method_name);
                    continue;
            end
            elapsed_time = toc;
            baseline_times(method_idx, run) = elapsed_time;
            
            % 计算KPIs
            KPIs = calcuUserKPIs(interface);
            baseline_results{method_idx} = [baseline_results{method_idx}; KPIs];
            
            fprintf('    - 平均吞吐量: %.2f Mbps\n', KPIs.avg_throughput/1e6);
            fprintf('    - 平均SINR: %.2f dB\n', KPIs.avg_SINR);
            fprintf('    - 中断率: %.2f%%\n', KPIs.outage_rate*100);
            fprintf('    - 平均满足率: %.2f%%\n', KPIs.SS_avg*100);
            fprintf('    - 耗时: %.2f 秒\n', elapsed_time);
        end
        
        % 计算平均KPIs
        baseline_KPIs{method_idx} = averageKPIs(baseline_results{method_idx});
    end
    
    % 保存基线对比结果
    all_results.baseline = struct(...
        'methods', methods_list, ...
        'results', baseline_results, ...
        'KPIs', baseline_KPIs, ...
        'times', baseline_times ...
    );
    
    fprintf('\n基线对比实验完成！\n\n');
else
    fprintf('[步骤 2/6] 跳过基线对比实验\n\n');
end

%% SA消融实验
if config.run_ablation_SA
    fprintf('[步骤 3/6] 运行SA消融实验...\n');
    fprintf('========================================\n');
    
    SA_configs = {'with_SA', 'without_SA'};
    num_SA_configs = length(SA_configs);
    
    SA_results = cell(num_SA_configs, 1);
    SA_KPIs = cell(num_SA_configs, 1);
    SA_times = zeros(num_SA_configs, config.num_runs);
    
    for config_idx = 1:num_SA_configs
        config_name = SA_configs{config_idx};
        fprintf('\n配置 %d/%d: %s\n', config_idx, num_SA_configs, config_name);
        fprintf('----------------------------------------\n');
        
        SA_results{config_idx} = [];
        
        for run = 1:config.num_runs
            fprintf('  运行第 %d/%d 次...\n', run, config.num_runs);
            
            interface = DataObj;
            
            tic;
            if strcmp(config_name, 'with_SA')
                methods.BHST_MY_SA(interface, true, 'adaptive', 20);
            else
                methods.BHST_MY_SA(interface, false, 'adaptive', 20);
            end
            elapsed_time = toc;
            SA_times(config_idx, run) = elapsed_time;
            
            KPIs = calcuUserKPIs(interface);
            SA_results{config_idx} = [SA_results{config_idx}; KPIs];
            
            fprintf('    - 平均吞吐量: %.2f Mbps\n', KPIs.avg_throughput/1e6);
            fprintf('    - 平均满足率: %.2f%%\n', KPIs.SS_avg*100);
            fprintf('    - 耗时: %.2f 秒\n', elapsed_time);
        end
        
        SA_KPIs{config_idx} = averageKPIs(SA_results{config_idx});
    end
    
    % 保存SA消融结果
    all_results.SA_ablation = struct(...
        'configs', SA_configs, ...
        'results', SA_results, ...
        'KPIs', SA_KPIs, ...
        'times', SA_times ...
    );
    
    fprintf('\nSA消融实验完成！\n\n');
else
    fprintf('[步骤 3/6] 跳过SA消融实验\n\n');
end

%% L_tabu消融实验
if config.run_ablation_Ltabu
    fprintf('[步骤 4/6] 运行L_tabu消融实验...\n');
    fprintf('========================================\n');
    
    Ltabu_configs = {
        struct('mode', 'fixed', 'value', 10, 'label', 'Fixed L=10');
        struct('mode', 'fixed', 'value', 20, 'label', 'Fixed L=20');
        struct('mode', 'fixed', 'value', 30, 'label', 'Fixed L=30');
        struct('mode', 'adaptive', 'value', 0, 'label', 'Adaptive L');
    };
    num_Ltabu_configs = length(Ltabu_configs);
    
    Ltabu_results = cell(num_Ltabu_configs, 1);
    Ltabu_KPIs = cell(num_Ltabu_configs, 1);
    Ltabu_times = zeros(num_Ltabu_configs, config.num_runs);
    
    for config_idx = 1:num_Ltabu_configs
        config_struct = Ltabu_configs{config_idx};
        fprintf('\n配置 %d/%d: %s\n', config_idx, num_Ltabu_configs, config_struct.label);
        fprintf('----------------------------------------\n');
        
        Ltabu_results{config_idx} = [];
        
        for run = 1:config.num_runs
            fprintf('  运行第 %d/%d 次...\n', run, config.num_runs);
            
            interface = DataObj;
            
            tic;
            if strcmp(config_struct.mode, 'fixed')
                methods.BHST_MY_SA(interface, true, 'fixed', config_struct.value);
            else
                methods.BHST_MY_SA(interface, true, 'adaptive', 20);
            end
            elapsed_time = toc;
            Ltabu_times(config_idx, run) = elapsed_time;
            
            KPIs = calcuUserKPIs(interface);
            Ltabu_results{config_idx} = [Ltabu_results{config_idx}; KPIs];
            
            fprintf('    - 平均吞吐量: %.2f Mbps\n', KPIs.avg_throughput/1e6);
            fprintf('    - 平均满足率: %.2f%%\n', KPIs.SS_avg*100);
            fprintf('    - 耗时: %.2f 秒\n', elapsed_time);
        end
        
        Ltabu_KPIs{config_idx} = averageKPIs(Ltabu_results{config_idx});
    end
    
    % 保存L_tabu消融结果
    all_results.Ltabu_ablation = struct(...
        'configs', Ltabu_configs, ...
        'results', Ltabu_results, ...
        'KPIs', Ltabu_KPIs, ...
        'times', Ltabu_times ...
    );
    
    fprintf('\nL_tabu消融实验完成！\n\n');
else
    fprintf('[步骤 4/6] 跳过L_tabu消融实验\n\n');
end

%% 生成汇总报告
fprintf('[步骤 5/6] 生成汇总报告...\n');
fprintf('========================================\n\n');

fprintf('==================== 综合实验结果汇总 ====================\n\n');

if config.run_baseline
    fprintf('【基线对比结果】\n');
    fprintf('%-15s %12s %12s %12s %12s\n', '方法', '吞吐量(Mbps)', 'SINR(dB)', '中断率(%)', '满足率(%)');
    fprintf('%-15s %12s %12s %12s %12s\n', '---------------', '------------', '------------', '------------', '------------');
    for i = 1:length(baseline_KPIs)
        kpi = baseline_KPIs{i};
        fprintf('%-15s %12.2f %12.2f %12.2f %12.2f\n', ...
            methods_list{i}, kpi.avg_throughput/1e6, kpi.avg_SINR, kpi.outage_rate*100, kpi.SS_avg*100);
    end
    fprintf('\n');
end

if config.run_ablation_SA
    fprintf('【SA消融结果】\n');
    fprintf('%-15s %12s %12s\n', '配置', '吞吐量(Mbps)', '满足率(%)');
    fprintf('%-15s %12s %12s\n', '---------------', '------------', '------------');
    for i = 1:length(SA_KPIs)
        kpi = SA_KPIs{i};
        fprintf('%-15s %12.2f %12.2f\n', SA_configs{i}, kpi.avg_throughput/1e6, kpi.SS_avg*100);
    end
    fprintf('\n');
end

if config.run_ablation_Ltabu
    fprintf('【L_tabu消融结果】\n');
    fprintf('%-15s %12s %12s\n', '配置', '吞吐量(Mbps)', '满足率(%)');
    fprintf('%-15s %12s %12s\n', '---------------', '------------', '------------');
    for i = 1:length(Ltabu_KPIs)
        kpi = Ltabu_KPIs{i};
        fprintf('%-15s %12.2f %12.2f\n', Ltabu_configs{i}.label, kpi.avg_throughput/1e6, kpi.SS_avg*100);
    end
    fprintf('\n');
end

fprintf('==========================================================\n\n');

%% 保存所有结果
if config.save_results
    fprintf('[步骤 6/6] 保存实验结果...\n');
    
    % 创建结果目录（如果不存在）
    if ~exist('results', 'dir')
        mkdir('results');
    end
    
    % 保存MAT文件
    save_filename = sprintf('results/all_experiments_%s.mat', all_timestamp);
    save(save_filename, 'all_results', 'config', 'all_timestamp');
    fprintf('   ✓ 结果已保存: %s\n', save_filename);
end

fprintf('\n========================================\n');
fprintf('   综合实验完成！\n');
fprintf('========================================\n\n');

%% 辅助函数: 计算平均KPIs
function avg_KPIs = averageKPIs(KPIs_cell)
    % 将多个KPIs结构体取平均
    
    if isempty(KPIs_cell)
        avg_KPIs = struct();
        return;
    end
    
    % 获取所有字段名
    field_names = fieldnames(KPIs_cell(1));
    
    % 初始化平均KPIs
    avg_KPIs = struct();
    
    % 对每个字段取平均
    for i = 1:length(field_names)
        field = field_names{i};
        values = [KPIs_cell.(field)];
        
        % 过滤掉NaN值
        valid_values = values(~isnan(values));
        
        if ~isempty(valid_values)
            avg_KPIs.(field) = mean(valid_values);
        else
            avg_KPIs.(field) = NaN;
        end
    end
end
