function BeamFoot_Method0(interface)
%用密度聚类方法去画波位
%改进：将每个点的密度排序，然后改变MinPts直到所有的点被划分完毕

%获取一些参数
Radius =  6371.393e3;
%算波位半径
AngleOf3dB = interface.AngleOf3dB;% 天线3dB张角
Rb = tools.getEarthLength(AngleOf3dB, interface.height)/2;

hOfDiscr = tools.LatLngCoordi2Length([0 0], [0 1], Radius)/interface.factorOfDiscr;%离散三角行的行高
NofRaw = 2 * ceil(Rb/(2*hOfDiscr/sqrt(3))); % 一个波位占用的离散三角行数

NumOfSat = length(interface.OrderOfServSatCur);%卫星数量

referDist = 2 * Rb; % 参考距离

%卫星天线
Pt_satAll = interface.SatObj(1).Pt_dBm_serv; % 卫星天线总的发射功率
Pt_satAll = (10.^(Pt_satAll/10))/1e3; %单位是W
Pt_sat = Pt_satAll/interface.numOfServbeam;
% P = 30;
% freq = mean(controller.Communication.freqOfServ(2,:));%频率
freq1 = interface.Config.freqOfDownLink - interface.Config.BandOfLink/2;
heightOfsat = interface.Config.height;

%用户天线
%用户接收增益
type = 0;
%调度周期总数
sche = interface.ScheInShot; 

%噪声功率
BWDown = interface.Config.BandOfLink; % 带宽，单位是Hz
T = 300;%开尔文温度，单位是k
k = 1.38e-23;%玻尔兹曼常数
% N0 = k*T*BWDown;%热噪声

%% 按照调度周期遍历
for idx = 1 : sche
%% 按卫星遍历
for i = 1 : NumOfSat
    %卫星信息
    satCurPos = interface.SatObj(i).position; % 当前卫星星下点坐标
    satCurnextPos = interface.SatObj(i).nextpos; % 当前卫星星下点下一step坐标
    %获得当前卫星下的用户信息
    numOfUsrs = interface.SatObj(i).numOfusrs(idx); 
    UsrsOrder = interface.SatObj(i).servUsr(idx,:); %卫星服务用户的编号

    if numOfUsrs == 0
        interface.tmpSat(i).NumOfBeamFoot(idx) = 0;
        continue;
    end

    % 该星下用户的坐标
    UsrsPosition = zeros(numOfUsrs, 2);
    for ii = 1 : numOfUsrs
        curUser = interface.SatObj(i).servUsr(ii);
        tmp = find(interface.OrderOfSelectedUsrs == curUser);
        UsrsPosition(ii, :) = interface.UsrsObj(tmp).position;    
    end

    %获得一个每用户与其他用户的距离矩阵，距离超过referDist的话就置0
    %注： 如果考虑波束变形的话，那么这个相邻关系就用两个用户与卫星之间的夹角和波束3dB角的大小关系判定
    bfT = zeros(numOfUsrs, numOfUsrs);
        for s = 1 : numOfUsrs
            for q = 1 : s
                if s ~= q%同一个用户的相邻关系置0
                    deltaL = tools.LatLngCoordi2Length(UsrsPosition(s, :), UsrsPosition(q, :), Radius);
                    if deltaL <= referDist  %相邻的标准是半径，因为不调整波位中心坐标
                        bfT(s, q) = 1;
                        bfT(q, s) = 1;
                    end
                else
                    bfT(s, q) = 0;
                end
            end
        end

    %划分情况
    sorted = zeros(1, numOfUsrs);%非0表示已划分，具体数字为划分进去的波位编号
    beamId = 1;% 波位的编号

    %预分配内存
    centerPos = zeros(numOfUsrs,2);%波位数最多和用户数一样
    cetrTri = zeros(1,numOfUsrs);
    orderOfcetr = zeros(numOfUsrs,3);%order和ifUp
    userInBeam = zeros(numOfUsrs,numOfUsrs-1);% 波位内用户编号，没有最大用户数约束了

    %以下开始运行方法
    adjOfUser = sum(bfT');
    MinPts = max(adjOfUser);
    while true 
        %结束条件：如果每个点都没有相邻了
        if MinPts == 0
            break;
        end

        %获得核心点的编号
        Pts = find(adjOfUser == MinPts);
        sortedList = find(sorted);
        Pts = setdiff(Pts,sortedList);%去掉已划分的
        if isempty(Pts)
            MinPts = MinPts - 1;
            continue;
        end
        %遍历核心点
        for Pt = Pts
            if sorted(Pt)
                continue;
            end
            %先以核心点为中心画圆
            center = UsrsPosition(Pt,:);
            curUsrInBeam = Pt;
            %获得当前波位的用户
            for uu = 1 : numOfUsrs
                tempD = tools.LatLngCoordi2Length(UsrsPosition(uu, :), center, Radius);
                if tempD <= Rb && sorted(uu)==0 && uu ~= Pt
                    curUsrInBeam = [curUsrInBeam uu];
                end
            end
            %获得当前Ci
            Ci = 0;
            %计算波束指向
            [outputTheta, outputPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, center, heightOfsat);
            BeamPoint(1) = outputPhi;
            BeamPoint(2) = outputTheta;
            for uuu = 1 : length(curUsrInBeam)
                uu = curUsrInBeam(uuu);
                %更改功率的计算方式
                P = Pt_sat / length(curUsrInBeam);
                BW = BWDown/length(curUsrInBeam);
                f = freq1 + (uuu-1)*BW + BW/2;
                lambdaDown = 3e8/f;

                
                [UsrTheta, UsrPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, UsrsPosition(uu, :), heightOfsat);
                G_sat = antenna.getSatAntennaServG([UsrTheta, UsrPhi], BeamPoint, f); % 天线发射增益
                % 计算当前卫星到当前用户的距离
                usrPosInDescartes = LngLat2Descartes(UsrsPosition(uu, :), 0);
                satPosInDescartes = LngLat2Descartes(satCurPos, heightOfsat);
                distance = sqrt((satPosInDescartes(1)-usrPosInDescartes(1)).^2 + ...
                                (satPosInDescartes(2)-usrPosInDescartes(2)).^2 + ...
                                (satPosInDescartes(3)-usrPosInDescartes(3)).^2);
                %用户天线增益
                G_usr = antenna.getUsrAntennaServG(0, f, type); 
                %计算传输速率（好像不需要带宽）
                N0 = k*T*BW;
                Ci = Ci + BW*log2(1 + (P * G_sat * G_usr * (lambdaDown.^2)/(4*pi*distance).^2)/N0);
            end
%             Ci =  Ci/length(curUsrInBeam);
            lastUsrInBeam = curUsrInBeam;
           

            %更改
            count=0;
            while true
                newCenter(1) = mean(UsrsPosition(curUsrInBeam,1));
                newCenter(2) = mean(UsrsPosition(curUsrInBeam,2));
            
                newCurUsrInBeam = [];
            
                %获得当前波位的用户                
                for uu = 1 : numOfUsrs
                    tempD = tools.LatLngCoordi2Length(UsrsPosition(uu, :), newCenter, Radius);
                    if tempD <= Rb && sorted(uu) == 0
                        newCurUsrInBeam = [newCurUsrInBeam uu];
                    end
                end

                if isempty(newCurUsrInBeam)%如果更改之后空了，就不保留（会变空吗？？
                    break;
                end
            
                %获得当前Ci
                newCi = 0;
                %计算波束指向
                [outputTheta, outputPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, newCenter, heightOfsat);
                BeamPoint(1) = outputPhi;
                BeamPoint(2) = outputTheta;
                for uuu = 1:length(newCurUsrInBeam)
                    uu = newCurUsrInBeam(uuu);
                    %更改功率的计算方式
                    P = Pt_sat / length(newCurUsrInBeam);
                    BW = BWDown/length(newCurUsrInBeam);
                    f = freq1 + (uuu-1)*BW + BW/2;
                    lambdaDown = 3e8/f;
                    
                    [UsrTheta, UsrPhi] = tools.getPointAngleOfUsr(satCurPos, satCurnextPos, UsrsPosition(uu, :), heightOfsat);
                    G_sat = antenna.getSatAntennaServG([UsrTheta, UsrPhi], BeamPoint, f); % 天线发射增益
                    % 计算当前卫星到当前用户的距离
                    usrPosInDescartes = LngLat2Descartes(UsrsPosition(uu, :), 0);
                    satPosInDescartes = LngLat2Descartes(satCurPos, heightOfsat);
                    distance = sqrt((satPosInDescartes(1)-usrPosInDescartes(1)).^2 + ...
                                    (satPosInDescartes(2)-usrPosInDescartes(2)).^2 + ...
                                    (satPosInDescartes(3)-usrPosInDescartes(3)).^2);
                    %用户天线增益
                    G_usr = antenna.getUsrAntennaServG(0, f, type);
                    %计算传输速率（好像不需要带宽）
                    N0 = k*T*BW;
                    newCi = newCi + BW*log2(1 + (P * G_sat * G_usr * (lambdaDown.^2)/(4*pi*distance).^2)/N0);
                end
%                 newCi =  newCi/length(newCurUsrInBeam);
            
                %进入判断
                if newCi > Ci
                    %如果有进步，保留新的
                    Ci = newCi;
                    curUsrInBeam = newCurUsrInBeam;
                    center = newCenter;
                else%如果没有进步，就继续
%                     if isequal(newCurUsrInBeam,lastUsrInBeam)
                        break;
%                     else
%                         count = count + 1;
%                     end
%                     %
%                     if count == 10
%                         break;
%                     end
                end
                lastUsrInBeam = newCurUsrInBeam;
             
            end
            %找完当前pt的波位了，保存已划分
            sorted(curUsrInBeam) = beamId;

            userInBeam(beamId,1:length(curUsrInBeam)) = UsrsOrder(curUsrInBeam);
            centerPos(beamId,:) = center;
            [orderOfcetr(beamId,1),orderOfcetr(beamId,2), orderOfcetr(beamId,3)] = tools.findPointXY(interface, center(2), center(1));
            cetrTri(beamId) = simSatSysClass.tools.ij2Seq(orderOfcetr(beamId,1),orderOfcetr(beamId,2), interface.rowNum, interface.colNum);            

            beamId = beamId + 1;
            %更新bfT
            for uu = curUsrInBeam
                temp = setdiff(curUsrInBeam,uu);
                bfT(uu,temp) = 0;
            end
        end
        MinPts = MinPts - 1;
    end

%     %没被划分过的就单独在一个波位
    left = find(sorted == 0);
    for uu = left
        userInBeam(beamId,1) = UsrsOrder(uu); 

        centerPos(beamId,1) = (UsrsPosition(uu,1));
        centerPos(beamId,2) = (UsrsPosition(uu,2));

        [orderOfcetr(beamId,1),orderOfcetr(beamId,2), orderOfcetr(beamId,3)] = tools.findPointXY(interface, centerPos(beamId,2),centerPos(beamId,1));
        cetrTri(beamId) = simSatSysClass.tools.ij2Seq(orderOfcetr(beamId,1),orderOfcetr(beamId,2), interface.rowNum, interface.colNum);
        
        beamId = beamId + 1;
    end

    %% 以下为存数据
        if ~isempty(cetrTri)
            %计算波位总数
            if cetrTri(length(cetrTri)) ~= 0 
                NumOfBeam = length(cetrTri(:,1));
            else
                NumOfBeam = min(find(cetrTri == 0)) - 1;
            end    
            interface.tmpSat(i).NumOfBeamFoot(idx) = NumOfBeam;

            for j = 1 : NumOfBeam
                interface.tmpSat(i).beamfoot(idx, j).position = centerPos(j,:);
                usr = userInBeam(j,userInBeam(j,:)~=0);
                interface.tmpSat(i).beamfoot(idx, j).usrs = usr;
    
                [orderOfcetr(1),orderOfcetr(2), orderOfcetr(3)] = tools.findPointXY(interface, centerPos(j,2),centerPos(j,1));
                interface.tmpSat(i).beamfoot(idx, j).servTri = ...
                        simSatSysClass.tools.setBeamFoot(orderOfcetr(1:2), orderOfcetr(3), NofRaw, interface.rowNum, interface.colNum); 
    
            end

        else
            NumOfBeam = 0;
            interface.tmpSat(i).NumOfBeamFoot(idx) = NumOfBeam;
            %没有波位
            
        end    
    fprintf('第%d次调度第%d个卫星波位形成\n',idx,i); 
end
end
end


%%
function PosInDescartes = LngLat2Descartes(CurPos, h)
    tmpPhi = CurPos(1) * pi / 180;
    if tmpPhi < 0
        tmpPhi = tmpPhi + 2*pi;
    end
    tmpTheta = (90 - CurPos(2)) * pi / 180;
    R = 6371.393e3; % 地球半径
    tmpX = (R+h) * sin(tmpTheta) * cos(tmpPhi);
    tmpY = (R+h) * sin(tmpTheta) * sin(tmpPhi);
    tmpZ = (R+h) * cos(tmpTheta); 
    PosInDescartes = [tmpX, tmpY, tmpZ];    
end
%% 全向天线
function G = getGofUsr(Gmax_dBi, l, lambda, theta)
    F = antenna.SymmetricalDipole(l, lambda, theta);
    G = (10.^(Gmax_dBi/10))*(F.^2);
end


