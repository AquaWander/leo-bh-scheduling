classdef DQNNetwork < handle
    % DQNNetwork DQN神经网络
    % 用于估计状态-动作值函数（Q值）
    
    properties (Access = public)
        net             % 神经网络
        input_size      % 输入维度
        output_size     % 输出维度
        learning_rate   % 学习率
    end
    
    methods
        function obj = DQNNetwork(input_size, output_size, learning_rate)
            % 构造函数
            %   input_size: 输入状态维度
            %   output_size: 输出动作维度
            %   learning_rate: 学习率（默认1e-3）
            
            if nargin == 0
                input_size = 100;
                output_size = 1000;
                learning_rate = 1e-3;
            end
            
            obj.input_size = input_size;
            obj.output_size = output_size;
            obj.learning_rate = learning_rate;
            
            % 创建网络（简单结构）
            % 使用全连接层
            layers = [
                featureInputLayer(input_size, 'Name', 'state', 'Normalization', 'none')
                fullyConnectedLayer(256, 'Name', 'fc1')
                leakyReluLayer(0.01, 'Name', 'lrelu1')
                dropoutLayer(0.1, 'Name', 'dropout1')
                fullyConnectedLayer(128, 'Name', 'fc2')
                leakyReluLayer(0.01, 'Name', 'lrelu2')
                dropoutLayer(0.1, 'Name', 'dropout2')
                fullyConnectedLayer(output_size, 'Name', 'output')
            ];
            
            % 创建网络
            try
                obj.net = dlnetwork(layers);
                fprintf('[✓] DQN网络创建成功\n');
                fprintf('    输入维度: %d\n', input_size);
                fprintf('    输出维度: %d\n', output_size);
                fprintf('    学习率: %.4f\n', learning_rate);
            catch ME
                error('[✗] DQN网络创建失败: %s', ME.message);
            end
        end
        
        function q_values = predict(obj, state)
            % 前向传播，返回Q值
            %   state: 输入状态（可以是单个状态或批次）
            %   q_values: 对应的Q值
            
            try
                q_values = predict(obj.net, state);
            catch ME
                warning('预测失败: %s', ME.message);
                q_values = zeros(obj.output_size, 1);
            end
        end
        
        function loss = compute_loss(obj, states, actions, rewards, next_states, dones, gamma, target_net)
            % 计算DQN损失（TD误差）
            %   states: 当前状态批次
            %   actions: 动作批次
            %   rewards: 奖励批次
            %   next_states: 下一状态批次
            %   dones: 是否结束批次
            %   gamma: 折扣因子
            %   target_net: 目标网络
            %   loss: 平均TD误差
            
            % 计算当前Q值
            current_q_values = obj.predict(states);
            
            % 计算目标Q值
            next_q_values = target_net.predict(next_states);
            max_next_q = max(next_q_values, [], 1);
            target_q = rewards + gamma * (1 - dones) .* max_next_q;
            
            % 提取对应动作的Q值
            batch_size = length(actions);
            indices = sub2ind(size(current_q_values), actions, 1:batch_size);
            current_q = current_q_values(indices);
            
            % 计算损失（MSE）
            loss = mean((current_q - target_q).^2);
        end
        
        function update(obj, batch, gamma, target_net)
            % 使用梯度下降更新网络（简化版）
            % 注意：这里使用了简化的实现
            % 实际应用中应该使用更完善的训练循环
            
            if isempty(batch)
                return;
            end
            
            % 从批次中提取数据
            states = cat(2, batch.state);
            actions = cat(2, batch.action);
            rewards = cat(2, batch.reward);
            next_states = cat(2, batch.next_state);
            dones = cat(2, batch.done);
            
            % 计算梯度并更新（简化版）
            % 实际应用中应该使用trainNetwork或自动微分
            try
                % 这里使用简化的更新方式
                % 实际应该使用完整的训练循环
                
                % 暂时只打印信息
                % 实际训练应该在DQNAgent中进行
                
            catch ME
                warning('网络更新失败: %s', ME.message);
            end
        end
        
        function save_model(obj, filename)
            % 保存模型
            %   filename: 保存文件名
            
            try
                save(filename, 'obj.net', 'obj.input_size', 'obj.output_size', 'obj.learning_rate', '-v7.3');
                fprintf('[✓] 模型已保存到: %s\n', filename);
            catch ME
                error('[✗] 模型保存失败: %s', ME.message);
            end
        end
        
        function load_model(obj, filename)
            % 加载模型
            %   filename: 模型文件名
            
            try
                data = load(filename);
                obj.net = data.obj.net;
                obj.input_size = data.obj.input_size;
                obj.output_size = data.obj.output_size;
                obj.learning_rate = data.obj.learning_rate;
                fprintf('[✓] 模型已从: %s 加载\n', filename);
            catch ME
                error('[✗] 模型加载失败: %s', ME.message);
            end
        end
    end
end
