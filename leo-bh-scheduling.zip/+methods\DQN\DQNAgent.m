classdef DQNAgent < handle
    % DQNAgent DQN智能体
    % 实现深度Q网络算法，用于卫星波束调度
    
    properties (Access = public)
        q_network          % Q网络
        target_network     % 目标网络
        replay_buffer      % 经验回放缓冲区
        gamma             % 折扣因子
        epsilon           % 当前探索率
        epsilon_start     % 初始探索率
        epsilon_end       % 结束探索率
        epsilon_decay     % 探索率衰减步数
        learning_rate     % 学习率
        batch_size       % 批次大小
        target_update_freq % 目标网络更新频率
        update_step      % 更新步数
        total_steps      % 总步数
    end
    
    methods
        function obj = DQNAgent(config)
            % 构造函数
            %   config: 配置结构体，包含以下字段：
            %       - state_size: 状态维度
            %       - action_size: 动作维度
            %       - gamma: 折扣因子（默认0.95）
            %       - epsilon_start: 初始探索率（默认1.0）
            %       - epsilon_end: 结束探索率（默认0.1）
            %       - epsilon_decay: 探索率衰减步数（默认10000）
            %       - learning_rate: 学习率（默认1e-3）
            %       - batch_size: 批次大小（默认32）
            %       - buffer_size: 经验池容量（默认10000）
            %       - target_update_freq: 目标网络更新频率（默认200）
            
            % 设置默认参数
            if nargin == 0
                config = struct();
            end
            
            if ~isfield(config, 'gamma')
                config.gamma = 0.95;
            end
            if ~isfield(config, 'epsilon_start')
                config.epsilon_start = 1.0;
            end
            if ~isfield(config, 'epsilon_end')
                config.epsilon_end = 0.3;
            end
            if ~isfield(config, 'epsilon_decay')
                config.epsilon_decay = 5000;
            end
            if ~isfield(config, 'learning_rate')
                config.learning_rate = 1e-3;
            end
            if ~isfield(config, 'batch_size')
                config.batch_size = 32;
            end
            if ~isfield(config, 'buffer_size')
                config.buffer_size = 10000;
            end
            if ~isfield(config, 'target_update_freq')
                config.target_update_freq = 200;
            end
            if ~isfield(config, 'state_size')
                config.state_size = 100;
            end
            if ~isfield(config, 'action_size')
                config.action_size = 1000;
            end
            
            % 初始化属性
            obj.gamma = config.gamma;
            obj.epsilon_start = config.epsilon_start;
            obj.epsilon_end = config.epsilon_end;
            obj.epsilon_decay = config.epsilon_decay;
            obj.learning_rate = config.learning_rate;
            obj.batch_size = config.batch_size;
            obj.target_update_freq = config.target_update_freq;
            obj.epsilon = obj.epsilon_start;
            obj.update_step = 0;
            obj.total_steps = 0;
            
            % 创建网络
            obj.q_network = methods.DQN.DQNNetwork(...
                config.state_size, config.action_size, obj.learning_rate);
            obj.target_network = methods.DQN.DQNNetwork(...
                config.state_size, config.action_size, obj.learning_rate);
            
            % 创建经验回放
            obj.replay_buffer = methods.DQN.ReplayBuffer(config.buffer_size);
            
            % 初始化目标网络
            obj.update_target();
            
            fprintf('[✓] DQN智能体创建成功\n');
            fprintf('    折扣因子: %.2f\n', obj.gamma);
            fprintf('    学习率: %.4f\n', obj.learning_rate);
            fprintf('    批次大小: %d\n', obj.batch_size);
            fprintf('    探索率: %.2f -> %.2f (%d步)\n', ...
                obj.epsilon_start, obj.epsilon_end, obj.epsilon_decay);
        end
        
        function action = select_action(obj, state, action_mask)
            % 使用ε-greedy策略选择动作
            %   state: 当前状态
            %   action_mask: 动作掩码（可选，逻辑数组，1表示有效动作）
            %   action: 选择的动作
            
            if nargin < 3
                action_mask = [];
            end
            
            if rand < obj.epsilon
                % 随机探索
                if ~isempty(action_mask)
                    valid_actions = find(action_mask);
                    if isempty(valid_actions)
                        action = randi(obj.q_network.output_size);
                    else
                        action = valid_actions(randi(length(valid_actions)));
                    end
                else
                    action = randi(obj.q_network.output_size);
                end
            else
                % 贪心利用
                q_values = obj.q_network.predict(state);
                
                if ~isempty(action_mask)
                    q_values(~action_mask) = -inf;
                end
                
                [~, action] = max(q_values);
            end
        end
        
        function train_step(obj)
            % 训练一步（从经验池采样并更新网络）
            
            if obj.replay_buffer.get_size < obj.batch_size
                return;
            end
            
            % 采样小批次
            batch = obj.replay_buffer.sample(obj.batch_size);
            
            if isempty(batch)
                return;
            end
            
            % 更新Q网络
            % 注意：这里使用简化的实现
            % 实际应用中应该使用梯度下降
            obj.q_network.update(batch, obj.gamma, obj.target_network);
            
            % 更新探索率
            obj.epsilon = max(obj.epsilon_end, ...
                obj.epsilon_start - (obj.epsilon_start - obj.epsilon_end) * ...
                obj.update_step / obj.epsilon_decay);
            obj.update_step = obj.update_step + 1;
            obj.total_steps = obj.total_steps + 1;
            
            % 定期更新目标网络
            if mod(obj.update_step, obj.target_update_freq) == 0
                obj.update_target();
            end
        end
        
        function update_target(obj)
            % 更新目标网络（软更新或硬更新）
            % 这里使用硬更新
            obj.target_network.net = obj.q_network.net;
        end
        
        function store_experience(obj, state, action, reward, next_state, done)
            % 存储经验到回放缓冲区
            %   state: 当前状态
            %   action: 采取的动作
            %   reward: 获得的奖励
            %   next_state: 下一个状态
            %   done: 是否结束
            
            obj.replay_buffer.add(state, action, reward, next_state, done);
        end
        
        function save_agent(obj, filename)
            % 保存智能体
            %   filename: 保存文件名
            
            save(filename, 'obj', '-v7.3');
            fprintf('[✓] 智能体已保存到: %s\n', filename);
        end
        
        function load_agent(obj, filename)
            % 加载智能体
            %   filename: 智能体文件名
            
            try
                data = load(filename);
                obj = data.obj;
                fprintf('[✓] 智能体已从: %s 加载\n', filename);
            catch ME
                error('[✗] 智能体加载失败: %s', ME.message);
            end
        end
        
        function display_info(obj)
            % 显示智能体信息
            fprintf('=== DQNAgent 信息 ===\n');
            fprintf('总步数: %d\n', obj.total_steps);
            fprintf('更新步数: %d\n', obj.update_step);
            fprintf('当前探索率: %.4f\n', obj.epsilon);
            fprintf('经验池大小: %d/%d\n', ...
                obj.replay_buffer.get_size, obj.replay_buffer.capacity);
        end
    end
end
